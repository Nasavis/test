import json
import copy
from nexla.log_config import log
from datetime import datetime, timedelta


class DataSet(object):

    @staticmethod
    def get_all(auth, access_role=None):
        """
        Get all datasets.
        :Params
            auth (string): auth token
            access_role (string): access role of the user
        :Returns
            list: list of all dataset objects

        """
        dsets = []

        if access_role:
            resp = auth.call_url_return_json("data_sets?expand=1&access_role=%s" % access_role)
        else:
            resp = auth.call_url_return_json("data_sets?expand=1")
        for r in resp:
            obj = DataSet(auth, payload=r)
            dsets.append(obj)
        return dsets

    @staticmethod
    def activate(auth, id):
        """
        Activate a dataset
        :Params
            id (int): dataset id
        :Returns
            bool: The return value is True if the dataset gets activated, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sets/%d/activate" % id, method="PUT")
        if resp["status"]:
            if resp["status"] != "ACTIVE":
                log.error("Activation failed")
                raise Exception("Nexset not activated")
            else:
                return True
        return False

    @staticmethod
    def pause(auth, id):
        """
        Pause a dataset
        :Params
            id (int): dataset id
        :Returns
            bool: The return value is True if the dataset gets paused, False otherwise.

        """
        resp = auth.call_url_return_json("/data_sets/%d/pause" % id, method="PUT")
        if resp["status"]:
            if resp["status"] != "PAUSED":
                log.error("Failed to pause")
                raise Exception("Nexset not paused")
            else:
                return True
        return False

    def __init__(self, auth, **kwargs):
        """
        Dataset initializer.
        :Params
            auth (string): auth token
            payload (string): request body having dataset details
            dsid (int): dataset id
        :Returns
            None

        """
        self.auth = auth
        if "payload" in kwargs:
            self._init_from_payload(payload=kwargs["payload"])
        elif "dsid" in kwargs:
            self._init_from_id(auth, dsid=kwargs["dsid"])
        else:
            raise Exception("Unsupported Initialization of Nexset Object")

    def _init_from_id(self, auth_obj, dsid):
        """
        Dataset initializer.
        :Params
            auth_obj (string): auth token
            dsid (int): dataset id
        :Returns
            None

        """
        self.id = dsid
        resp = auth_obj.call_url_return_json("/data_sets/%d?expand=1" % dsid)
        self._init_from_payload(payload=resp)

    def _init_from_payload(self, payload=None):
        """
        Dataset initializer.
        :Params
            payload (string): request body having dataset details
        :Returns
            None

        """
        if payload == None:
            raise Exception("Missing payload to initialize Source")
        try:
            self.attributes = {}
            self.raw = self.attributes["raw"] = payload
            self.id = self.attributes["id"] = int(payload.get("id", ""))
            if payload.get("owner"):
                self.attributes["owner_name"] = payload.get("owner", {}).get("full_name")
            self.attributes["name"] = payload.get("name", "")
            self.attributes["status"] = payload.get("status", "")
            self.attributes["data_source_id"] = payload.get("data_source_id", "")
            self.attributes["description"] = payload.get("description", "")
            if payload.get("data_source_id") is not None and payload.get("data_source_id") != "":
                self.attributes["data_source"] = payload.get("data_source", "")
                self.attributes["source_schema_properties"] = payload.get("source_schema").get("properties")
                self.attributes["status"] = self.attributes["data_source"].get("status", "")
            self.attributes["parent_data_sets"] = payload.get("parent_data_sets")
            self.attributes["transform"] = payload.get("transform")
            self.attributes["has_custom_transform"] = payload.get("has_custom_transform", "False")
            self.attributes["transform_id"] = payload.get("transform_id")
            self.attributes["properties"] = payload.get("output_schema", {}).get("properties", {})
            self.attributes["created_at"] = payload.get("created_at", "").replace('.000Z', '')
            self.attributes["updated_at"] = payload.get("updated_at", "").replace('.000Z', '')
        except:
            log.debug(json.dumps(payload, indent=4))
            raise Exception("Unable to initialize Source")

    @staticmethod
    def createDatasetfromDataset(auth, ds_id, has_custom_transform=False, name=None, transform=None):
        """
        Create dataset from another dataset
        :Params
            auth (string): auth token
            ds_id (int): dataset id
            has_custom_transform (boolean): True if the dataset has a custom transform, False otherwise
            name (string): name of the dataset to be created
            transform (string): custom transform
        :Returns
            DataSet: object of newly created dataset

        """
        try:
            datasetobj = DataSet(auth, dsid=ds_id)
            if (datasetobj.get("id") != ds_id):
                raise Exception("Did not find dataset with id %d. Please check if this is a vaid dataset ID." % ds_id)
            dataset_payload = copy.deepcopy(dataset_create_template)
            if (name == ""):
                dataset_payload["name"] = "Derived dataset of " + datasetobj.get("name")
            else:
                dataset_payload["name"] = name
            dataset_payload["parent_data_set_id"] = ds_id
            if (has_custom_transform.lower() == "true"):
                dataset_payload["has_custom_transform"] = True
            else:
                dataset_payload["has_custom_transform"] = False
            dataset_payload["transform"]["version"] = 1
            dataset_payload["transform"]["data_maps"] = []

            print("Building transformation definition ...")
            if (has_custom_transform.lower() == "true" and transform != ""):
                dataset_payload["transform"]["transforms"] = transform
                log.info("Creating new derived dataset...")
                log.debug(
                    "Calling Create dataset with payload: \n%s \n\n" % json.dumps(dataset_payload, indent=4).replace(
                        "'", "\\'"))
                return DataSet.create(auth, dataset_payload)

            else:
                ##Map all source fields to target
                print("Using default mappping of 1:1")
                dataset_payload["transform"]["transforms"] = [{"operation": "shift", "spec": {}}]
                t = dataset_payload["transform"]["transforms"][0]["spec"]
                # for x in resp["output_schema"]["properties"]:
                #     t[x] = x
                for x in datasetobj.get("properties"):
                    t[x] = x

                log.info(
                    "Calling Create dataset with payload: \n%s \n\n" % json.dumps(dataset_payload, indent=4).replace(
                        "'", "\\'"))
                log.info("Creating new derived dataset...")
                return DataSet.create(auth, dataset_payload)

        except:
            raise Exception("Error creating derived dataset")

    #for access_roles
    @staticmethod
    def add_accessors(auth, payload, dsid):
        """
        Create dataset accessors using payload.
        :Params
            auth (string): auth token
            dsid (string): dataset id
            payload (string): request body having dataset accessors details
        """
        try:
            resp = auth.call_url_return_json("/data_sets/%s/accessors" %dsid, 'POST', payload)
        except:
            raise Exception("Error Creating accessors")

    @staticmethod
    def get_accessors(auth, dsid):
        """
        Get dataset accessors details.
        :Params
            auth (string): auth token
            dsid (string): transform id
        :Returns
            Accessors: returns dataset accessors details
        """
        try:
            resp = auth.call_url_return_json("/data_sets/%s/accessors" %dsid, 'GET')
            return resp
        except:
            raise Exception("Error while getting accessors")

    @staticmethod
    def create(auth, payload):
        """
        Create dataset using payload
        :Params
            auth (string): auth token
            payload (string): request body having dataset details
        :Returns
            DataSet: returns dataset object

        """
        try:
            datasetobj = DataSet(auth, payload=auth.call_url_return_json("/data_sets?expand=1", method="POST",
                                                                         payload=payload))
            if (datasetobj.get("id") == None):
                raise Exception("Error Creating derived dataset")
            return datasetobj
        except:
            raise Exception("Error Creating derived dataset")

    @staticmethod
    def delete(auth, dsid):
        """
        Delete dataset
        :Params
            auth (string): auth token
            dsid (int): id of dataset to be deleted
        :Returns
            int: returns response status

        """
        try:
            resp = auth.call_url_return_status("/data_sets/%d?expand=1" % dsid, method="DELETE")
            return resp
        except:
            raise Exception("Error in deleting dataset")

    def update(self, payload=None):
        """
        Update dataset
        :Params
            payload (string): details of dataset to be updated
        :Returns
            int: returns response status

        """
        if payload == None:
            raise Exception("Missing payload to update Dataset")
        try:
            resp = self.auth.call_url_return_status("/data_sets/%d?expand=1" % self.id, method="PUT", payload=payload)
            return resp
        except:
            raise Exception("Error in updating dataset")

    def export(self):
        """
        Get templatized dataset details.
        :Returns
            Dict: returns templatized dataset details

        """
        dataset_export_tmplt = copy.deepcopy(dataset_create_template)
        dataset_export_tmplt["name"] = self.get("name")
        dataset_export_tmplt["description"] = self.get("description")
        dataset_export_tmplt["data_source_id"] = self.get("data_source_id")
        if self.get("parent_data_sets"):
            dataset_export_tmplt["parent_data_set_id"] = "<" + str(self.get("parent_data_sets")[0]["id"]) + ": " + str(
                self.get("parent_data_sets")[0]["name"]) + ">"
        dataset_export_tmplt["transform"] = self.get("transform")
        dataset_export_tmplt["has_custom_transform"] = self.get("has_custom_transform")
        return dataset_export_tmplt

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def get_export(self):
        """
        Get transformation of the dataset.
        :Returns
            string: returns transform of the dataset

        """
        return self.raw["transform"]["transforms"]

    def get_transform(self, transform):
        dataset_transform_tmplt = copy.deepcopy(dataset_transform_template)
        if transform:
            dataset_transform_tmplt["transform"] = self.get("transform")
            return dataset_transform_tmplt

    @staticmethod
    def get_samples(auth, id, count=10, show_metadata=False, transform=True, show_inputs=False):
        """
        Get samples of the dataset.
        :Params
            count (int): number of samples required
            show_metadata (boolean): True if metadata is required, False otherwise
            transform (boolean): True if transform is required, False otherwise
            show_inputs (boolean): True if input is required, False otherwise
        :Returns
            list: list of samples

        """
        if count > 100:
            print("count value is huge, please provide a  count value <= 100")
            exit()
        samples_url = "/data_sets/%d/samples?count=%d" % (id, count)
        if show_metadata:
            samples_url += "&include_metadata=1"
        if not show_inputs:
            samples_url += "&output_only=1"
        resp = auth.call_url_return_json(samples_url)
        if show_inputs and not transform:
            inputs = []
            try:
                for r in resp:
                    inputs.append(r["input"])
                return inputs
            except KeyError:
                return resp
        else:
            return resp

    @staticmethod
    def get_quarantine_samples(auth, id, count):
        """
        Get qurantine samples for a dataset
        :Params
            id (int): dataset id
        :Returns
            string: quarantine samples

        """
        p = {"event_count": count, "latest": True}
        resp = auth.call_url_return_json("data_sets/%d/probe/quarantine/sample" % id, method="POST", payload=p)
        return resp

    @staticmethod
    def get_quarantine_files(auth, id, count):
        """
        Get qurantine files for a dataset
        :Params
            id (int): dataset id
        :Returns
            string: quarantine files

        """
        p = {"access_role": "collaborator","page": 1, "size": count, "orderby": "created_at", "sortorder": "desc", "status": ''}
        resp = auth.call_url_return_json("data_sets/%d/metrics/quarantine_files" % id, method="GET", payload=p)
        return resp

    @staticmethod
    def get_aggregate_metrics(auth, id, days=7, start_time=None, end_time=None):
        """
        Get aggregate metics of given dataset id
        :param auth: auth object
        :param id: source id
        :param days: no of days ago
        :param start_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :param end_time: date time in '%Y-%m-%dT%H:%M:%S' format
        :return: list of dictionaries
        """
        if end_time and not start_time:
            raise Exception("Required start time")
        elif not end_time:
            current_datetime = datetime.utcnow()
            end_time = current_datetime.strftime("%Y-%m-%dT%H:%M:%S")
            if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%d")
            try:
                if not start_time: start_time = (current_datetime - timedelta(days=days)).strftime("%Y-%m-%d")
            except OverflowError:
                print("OverflowError: Days value is huge")
                exit()
        resp = auth.call_url_return_json("data_sets/%d/metrics?from=%s&to=%s&aggregate=1" % (id, start_time, end_time))
        return resp["metrics"]

    def get_output_validation_schema(self):
        custom_config = {}
        output_validation_schema = {}
        temp_output_validation_schema = {}
        if self.raw.get("output_schema_validation_enabled"):
            temp_output_validation_schema["output_schema_validation_enabled"] = True
            if self.raw.get("output_validation_schema").get("required") != None:
                output_validation_schema["required"] = self.raw.get("output_validation_schema").get("required")
            output_validation_schema["properties"] = self.raw.get("output_validation_schema").get("properties")
            temp_output_validation_schema["output_validation_schema"] = output_validation_schema
            # custom_config["outputValidations"] = self.raw.get("custom_config").get("outputValidations")
            custom_config["custom_config"] = custom_config
        else:
            temp_output_validation_schema["output_validation_schema"] = output_validation_schema
            temp_output_validation_schema["output_schema_validation_enabled"] = False
        return temp_output_validation_schema

    def has_filter(self):
        """
        Check if dataset has filter.
        :Returns
            Boolean: True if dataset has a filter, False otherwise

        """
        parent_dataset = self.get("parent_data_sets")
        for parent in parent_dataset:
            if parent.get("transform") and parent.get("transform").get("transforms"):
                for trans in parent.get("transform").get("transforms"):
                    if trans["operation"].find("filter") != -1:
                        return True
        if self.get("transform") and self.get("transform").get("transforms"):
            for trans in self.get("transform").get("transforms"):
                if trans["operation"].find("filter") != -1:
                    return True
        return False

    def __str__(self):
        return ("ID: %d, Name: %s" % (self.attributes.get("id", ""), self.attributes.get("name", "")))

    def sync(self, payload=None):
        """
        Sync dataset.
        :Params
            payload (string): details required for sync call to dataset
        :Returns
            dict: response of sync call

        """
        if payload == None:
            raise Exception("Missing payload to sync dataset")
        resp = self.auth.call_url_return_json("/sync/sync/%d" % self.attributes["id"], method="POST", payload=payload,
                                              isAdminApi=False)
        return resp


dataset_create_template = {
    "name": "",
    "has_custom_transform": False,
    "parent_data_set_id": 0,
    "transform": {}
}

dataset_transform_template = {
    "transform": {}
}
