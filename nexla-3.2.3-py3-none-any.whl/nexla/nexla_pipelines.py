from nexla.nexla_sink import DataSink
from nexla.nexla_dataset import DataSet
from nexla.nexla_source import DataSource
from beautifultable import BeautifulTable
from nexla.log_config import log
import json


# Get dataset information as tree format
def get_dataset_tree(flow, data_sets, src_dataset_id, sink_dataset_id=None, dataset_id=None):
    """
        To get dataset information as tree format
        :Params
            flow (string): flow details
            data_sets (string): dataset details
            sink_dataset_id (string): id of a sink before dataset
            dataset_id (string): id of a dataset
        :Returns
            Dataset_List: return dataset list

        """
    continue_loop = True
    cnt = 1
    data_set_list = []
    if sink_dataset_id != None:
        parent_datset_id = sink_dataset_id
        parent_data_set_ids = get_parent_data_set_ids(flow, parent_data_set_ids=[])

        for data_set_child in data_sets:
            if not continue_loop: break
            for res in parent_data_set_ids:
                if data_set_child["id"] == parent_datset_id and res["id"] == data_set_child["id"] or data_set_child["parent_data_set_id"] is None and str(data_set_child['id']) in str(parent_data_set_ids):
                    data_set_list.append(
                        {"id": data_set_child["id"], "name": data_set_child["name"], "status": data_set_child["status"],
                         "parent_data_set_id": res["parent_data_set_id"], "created_at": data_set_child["created_at"],
                         "updated_at": data_set_child["updated_at"]})
                    cnt += 1
                    if "parent_data_set_id" in res or res["parent_data_set_id"] is None:
                        if res["parent_data_set_id"] is None:
                            break
                        parent_datset_id = res["parent_data_set_id"]
                    if not parent_datset_id:
                        break
    else:
        parent_datset_id = dataset_id
        parent_data_set_ids = get_parent_data_set_ids(flow, parent_data_set_ids=[])

        for data_set_child in data_sets:
            if not continue_loop: break
            for res in parent_data_set_ids:
                if data_set_child["id"] == parent_datset_id and res["id"] == data_set_child["id"] or data_set_child["parent_data_set_id"] is None and str(data_set_child['id']) in str(parent_data_set_ids):
                    data_set_list.append(
                        {"id": data_set_child["id"], "name": data_set_child["name"], "status": data_set_child["status"],
                         "parent_data_set_id": res["parent_data_set_id"], "created_at": data_set_child["created_at"],
                         "updated_at": data_set_child["updated_at"]})
                    cnt += 1
                    if "parent_data_set_id" in res:
                        if res["parent_data_set_id"] is None:
                            break
                        parent_datset_id = res["parent_data_set_id"]
                    if not parent_datset_id:
                        break
    # Handled even if the source dataset id order or unordered.
    item_dict = {item['id']: item for item in data_set_list}
    sorted_data = []
    for item in data_set_list:
        if item['parent_data_set_id'] is None:
            sorted_data.append(item)
            def add_children(parent_item):
                children = [item_dict[child_id] for child_id in item_dict if
                            item_dict[child_id]['parent_data_set_id'] == parent_item['id']]
                children.sort(key=lambda x: x['id'])
                sorted_data.extend(children)
                for child in children:
                    add_children(child)
            add_children(item)
    return sorted_data


# get parent dataset id's
def get_parent_data_set_ids(flow, parent_data_set_ids=[]):
    """
        To get parent dataset id's
        :Params
            flow (string): flow details
            parent_data_set_ids (list): list of parent dataset id's
        :Returns
            Parent_Dataset_ID: return parent dataset id's

        """
    parent_data_set_ids.append({"id": flow["id"], "parent_data_set_id": flow["parent_data_set_id"]})
    children = flow["children"]
    if children == []:
        parent_data_set_ids.append({"id": flow["id"], "parent_data_set_id": flow["parent_data_set_id"]})
        return parent_data_set_ids
    else:
        for children in children:
            if children["children"] == []:
                parent_data_set_ids.append({"id": children["id"], "parent_data_set_id": children["parent_data_set_id"]})
            if children["children"] != []:
                get_parent_data_set_ids(children, parent_data_set_ids)
        return parent_data_set_ids


# Get datasets without sinks
def get_datasets_without_sink(dataset, dset_details=[], datasets_with_sinks=[]):
    """
        To get datasets which are not having sinks
        :Params
            dset_details (list): dataset details
            datasets_with_sinks (list): list of datasets which are with sinks
        :Returns
            Dataset: return details of a dataset

        """
    children = dataset["children"]
    if children == [] and (dataset["id"] not in datasets_with_sinks):
        dset_details.append({"last_dataset_id": dataset["id"]})
        return dset_details

    else:
        for children in children:
            if children["children"] == [] and not children["data_sinks"]:
                last_dataset_id = children["id"]
                dset_details.append({"last_dataset_id":last_dataset_id})

            if children["children"]:
                get_datasets_without_sink(children,dset_details)
        return dset_details


# Get the sink information's
def get_sink_details(flow_item, sink_details=[]):
    """
        To get datasets which are not having sinks
        :Params
            flow_item (string): flow details
            sink_details (list): list of datasets which are with sinks
        :Returns
            Sink: return sink details

        """
    if flow_item:
        try:
            if flow_item.get("children") != []:
                for children in flow_item.get("children"):
                    if children["data_sinks"] != []:
                        sink_dataset_id = children["id"]
                        for sink_id in children["data_sinks"]:
                            sink_details.append({"sink_id": sink_id.get("id"), "sink_dataset_id": sink_dataset_id})
                    if children["children"] != []:
                        get_sink_details(children, sink_details)
            else:
                sink_dataset_id = flow_item["id"]
                for sink_id in flow_item["data_sinks"]:
                    sink_details.append({"sink_id": sink_id.get("id"), "sink_dataset_id": sink_dataset_id})
        except:
            print("------------Except------------")
            print(json.dumps(flow_item, indent=4))
            exit()

        return sink_details
    else:
        return sink_details


class DataPipeline(object):
    cached_sources = {}

    # for clone a existing pipeline details in the platform
    @staticmethod
    def clone_pipeline(auth,  sink_id = None, dataset_id = None, reuse_creds = False, copy_other_sinks = False, copy_access_ctrl = False, access_role = "collaborator", payload = None):
        """
            To clone a existing pipeline information's
            :Params
                sink_id (string): id of a sink
                dataset_id (string): id of a dataset
                reuse_creds (string): credential information's
                copy_other_sinks (string): sink information's
                copy_access_ctrl (string): access control information's
                access_role (string):access role information's
            :Returns
                None

            """
        print("Cloning Flows")
        if payload == None:
            payload = {}
            payload["reuse_data_credentials"] = reuse_creds
            payload["copy_access_controls"] = copy_access_ctrl
            payload["copy_other_data_sinks"] = copy_other_sinks
            payload["owner_id"] = auth.user_id
            payload["org_id"] = auth.org_id
        else:
            payload = json.loads(payload)
        if sink_id:
            temp_url = "data_flows/data_sink/%d/copy?access_role=%s"%(int(sink_id), access_role)
        if dataset_id:
            temp_url = "data_flows/%d/copy?access_role=%s"%(int(dataset_id), access_role)
        resp = auth.call_url_return_json(method="POST", url = temp_url, payload=payload)
        print("Flows cloned successfully")

    @staticmethod
    def getAll(auth, access_all=False):
        """
        get all pipelines.
        :Params
            access_all (bool): accessibility of pipelines
        :Returns
            list: list of all pipelines

        """
        all_subs = DataPipeline.list_pipelines(auth, access_all=access_all)
        pipelines = []
        for sub in all_subs:
            log.info("New Pipeline ...")
            log.info(sub)
            if not sub.get("sink"): continue
            pipe = DataPipeline(auth, data_sub=sub)
            pipelines.append(pipe)

        return pipelines

    def __init__(self, auth, **kwargs):
        """
        Pipeline initializer.
        :Params
            auth (string): auth token
            data_sub (json string): dataset payload
        :Returns
            None

        """
        self.auth = auth
        if "data_sub" in kwargs:
            self._init_from_sub_payload(data_sub=kwargs["data_sub"])

    def _init_from_sub_payload(self, data_sub):
        """
        Pipeline initializer with dataset payload.
        :Params
            data_sub (json string): dataset payload
        :Returns
            None

        """
        self.attributes = {}
        self.attributes["data_sets"] = data_sub.get("data_sets")
        self.attributes["src_id"] = data_sub.get("src").get("id")
        self.attributes["src_name"] = data_sub.get("src").get("name")
        self.attributes["src_status"] = data_sub.get("src").get("status")
        self.attributes["src_type"] = data_sub.get("src").get("source_type")
        self.attributes["src_updated_at"] = data_sub.get("src").get("updated_at")
        self.attributes["src_dataset_id"] = data_sub.get("data_sets")[0].get("id")
        self.attributes["src_credential_id"] = data_sub.get("src").get("data_credential_id")
        self.attributes["sink_id"] = data_sub.get("sink").get("id")
        self.attributes["sink_name"] = data_sub.get("sink").get("name")
        self.attributes["sink_type"] = data_sub.get("sink").get("sink_type")
        self.attributes["sink_updated_at"] = data_sub.get("sink").get("updated_at")
        self.attributes["sink_credential_id"] = data_sub.get("sink").get("data_credential_id")

        self.data_sets = data_sub.get("data_sets")
        self.data_sink = DataSink(self.auth, id=self.attributes["sink_id"])
        if str(self.attributes["src_id"]) not in self.cached_sources:
            self.data_source = DataSource(self.auth, id=self.attributes["src_id"])
            self.cached_sources[str(self.attributes["src_id"])] = self.data_source
        else:
            self.data_source = self.cached_sources[str(self.attributes["src_id"])]
        self.attributes["src_location"] = self.data_source.get("location")
        self.attributes["src_frequency"] = self.data_source.get("frequency")
        self.attributes["owner"] = self.data_source.get("owner")
        self.attributes["sink_status"] = self.data_sink.get("status")
        print(json.dumps(self.attributes))

    def get(self, attr):
        """
        get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr, "")

    def is_active(self):
        """
        check if the pipeline is active (if all the entities are active)
        :Params
            no parameters
        :Returns
            bool: The return value is True if the pipeline is active, False otherwise.

        """
        return (self.attributes["src_status"] == "ACTIVE" and self.attributes["sub_status"] == "ACTIVE" and
                self.attributes["pub_status"] == "ACTIVE")


    @staticmethod
    def list_pipelines(auth, src_id=None, sink_id=None, access_all=False):
        """
        list pipeline
        :Params
            src_id (int): source id
            sink_id (int): sink id
            access_all (bool): accessibility of pipelines
        :Returns
            list: list of pipelines

        """
        pipeline_list = []
        url = "data_flows?expand=1"
        if src_id != None:
            url = "data_flows/data_source/%d?expand=1" % int(src_id)
        elif sink_id != None:
            url = "data_flows/data_sink/%d?expand=1" % int(sink_id)

        if access_all: url += "&access_role=all"
        pipeline_flow = auth.call_url_return_json(url)
        data_sets = pipeline_flow["data_sets"]
        data_sets = data_sets[::-1]
        src_dataset_with_sink = []


        if len(pipeline_flow) > 0 and len(pipeline_flow["flows"]):
            for index in range(len(pipeline_flow["flows"])):
                datasets_without_sink = []
                if "data_source" in pipeline_flow["flows"][index]:
                    src_id = pipeline_flow["flows"][index]["data_source"]["id"]
                src_dataset_id = pipeline_flow["flows"][index]["id"]
                sink_details = []
                sink_array = []
                if len(pipeline_flow["flows"][index]["children"]) != 0 or len(pipeline_flow["flows"][index]["data_sinks"]) != 0:
                    sink_details = get_sink_details(pipeline_flow["flows"][index], sink_details=sink_details)
                    for i in sink_details:
                        sink_array.append(i.get("sink_id"))

                if len(pipeline_flow["flows"][index]["data_sinks"]) != 0: # details about direct sinks created from source datasets
                    for sink_id in pipeline_flow["flows"][index]["data_sinks"]:
                        for sink in pipeline_flow["data_sinks"]:
                            if sink.get("id") == sink_id.get("id") and (sink.get("id") not in sink_array):
                                sink_details.append({"sink_id": sink_id.get("id"), "sink_dataset_id": sink.get("data_set_id")})
                                src_dataset_with_sink.append(sink.get("data_set_id"))
                            elif sink.get("id") == sink_id.get("id"):
                                src_dataset_with_sink.append(sink.get("data_set_id"))
                for sink in sink_details:
                    dataset_list = get_dataset_tree(pipeline_flow["flows"][index], data_sets, src_dataset_id, sink_dataset_id=sink["sink_dataset_id"])
                    pipeline_list.append(
                        {"src": {"id": src_id}, "sink": {"id": sink["sink_id"]}, "data_sets": dataset_list})
                #if (pipeline_flow["flows"][index]["id"] not in src_dataset_with_sink):
                if (pipeline_flow["flows"][index]["id"]):
                    datasets_without_sink = get_datasets_without_sink(pipeline_flow["flows"][index], dset_details=[], datasets_with_sinks=src_dataset_with_sink)

                for dset in datasets_without_sink:
                    dataset_list = get_dataset_tree(pipeline_flow["flows"][index], data_sets, src_dataset_id, dataset_id=dset["last_dataset_id"])
                    pipeline_list.append(
                        {"src": {"id": src_id}, "data_sets": dataset_list})
            for i in range(len(pipeline_flow["data_sources"])):
                for index in range(len(pipeline_list)):
                    if pipeline_list[index]["src"]["id"] == pipeline_flow["data_sources"][i]["id"]:
                        pipeline_list[index]["src"]["name"] = pipeline_flow["data_sources"][i]["name"]
                        pipeline_list[index]["src"]["status"] = pipeline_flow["data_sources"][i]["status"]
                        pipeline_list[index]["src"]["created_at"] = pipeline_flow["data_sources"][i]["created_at"]
                        pipeline_list[index]["src"]["flow_id"] = pipeline_flow["data_sources"][i]["origin_node_id"]
                        pipeline_list[index]["src"]["updated_at"] = pipeline_flow["data_sources"][i]["updated_at"]
                        pipeline_list[index]["src"]["source_type"] = pipeline_flow["data_sources"][i]["source_type"]
                        if isinstance(pipeline_flow["data_sources"][i]["data_credentials"], list):
                            pipeline_list[index]["src"]["data_credential_id"] = \
                            pipeline_flow["data_sources"][i]["data_credentials"][0]
                        if isinstance(pipeline_flow["data_sources"][i]["data_credentials"], dict):
                            pipeline_list[index]["src"]["data_credential_id"] = \
                            pipeline_flow["data_sources"][i]["data_credentials"]["id"]
                        else:
                            pipeline_list[index]["src"]["data_credential_id"] = pipeline_flow["data_sources"][i][
                                "data_credentials"]

            for i in range(len(pipeline_flow["data_sinks"])):
                for j in range(len(pipeline_list)):
                    if "sink" in pipeline_list[j] and pipeline_list[j]["sink"]["id"] == \
                            pipeline_flow["data_sinks"][i]["id"]:
                        if "data_credential_id" in pipeline_list[j]["sink"]: break
                        pipeline_list[j]["sink"]["name"] = pipeline_flow["data_sinks"][i]["name"]
                        pipeline_list[j]["sink"]["created_at"] = pipeline_flow["data_sinks"][i]["created_at"]
                        pipeline_list[j]["sink"]["updated_at"] = pipeline_flow["data_sinks"][i]["updated_at"]
                        pipeline_list[j]["sink"]["sink_type"] = pipeline_flow["data_sinks"][i]["sink_type"]
                        if isinstance(pipeline_flow["data_sinks"][i]["data_credentials"], list):
                            pipeline_list[j]["sink"]["data_credential_id"] = \
                            pipeline_flow["data_sinks"][i]["data_credentials"][0]
                        elif isinstance(pipeline_flow["data_sinks"][i]["data_credentials"], dict):
                            pipeline_list[j]["sink"]["data_credential_id"] = \
                            pipeline_flow["data_sinks"][i]["data_credentials"]["id"]
                        else:
                            pipeline_list[j]["sink"]["data_credential_id"] = pipeline_flow["data_sinks"][i][
                                "data_credentials"]
                        break

        for i in range(len(pipeline_list)):
            pipeline_list[i]["branch_id"] = i + 1
        # print(pipeline_list)
        # raise
        return pipeline_list

    def has_filter(self):
        """
        check if a pipeline has filter
        :Params
            no parameters
        :Returns
            bool: The return value is True if the pipeline has filter, False otherwise.

        """
        has_filter = False
        for data_set in self.data_sets:
            has_filter = DataSet(self.auth, dsid=data_set["id"]).has_filter()
            if has_filter:
                return has_filter
        return has_filter

    @staticmethod
    def print_pipelines(auth, src_id=None, sink_id=None):
        """
        print pipeline
        :Params
            src_id (int): source id
            sink_id (int): sink id
        :Returns
            list: list of pipelines

        """
        pipeline_list = []
        if src_id != None and src_id != "":
            pipeline_list = DataPipeline.list_pipelines(auth, src_id=src_id)
        elif sink_id != None and sink_id != "":
            pipeline_list = DataPipeline.list_pipelines(auth, sink_id=sink_id)
        else:
            pipeline_list = DataPipeline.list_pipelines(auth)
        if len(pipeline_list) == 0:
            return
        else:
            maxNumOfDatasets = 0
            for pipeline in pipeline_list:
                numOfDatasets = len(pipeline["data_sets"])
                if numOfDatasets > maxNumOfDatasets:
                    maxNumOfDatasets = numOfDatasets
            maxNumOfDatasets = maxNumOfDatasets - 1
            table = BeautifulTable(max_width=175)
            headers = ["flow_id", "source", "src_dataset"]
            dataset_header = []
            data = []
            for i in range(maxNumOfDatasets):
                dataset_header.append("dataset_%d" % (i + 1))
                data.append("")
            headers.extend(dataset_header)
            headers.append("sink")
            table.column_headers = headers
            for pipeline in pipeline_list:
                table_data = []
                table_data = list(data)
                for i in range(len(pipeline["data_sets"]) - 1):
                    table_data[i] = str(pipeline["data_sets"][i + 1]["id"]) + " (" + pipeline["data_sets"][i + 1][
                        "name"] + ")"
                table_data.insert(0, pipeline["flow_id"])
                table_data.insert(1, str(pipeline["src"]["id"]) + " (" + pipeline["src"]["name"] + ")")
                table_data.insert(2,
                                  str(pipeline["data_sets"][0]["id"]) + " (" + pipeline["data_sets"][0]["name"] + ")")

                if pipeline["sink"]:
                    table_data.append(str(pipeline["sink"]["id"]) + " (" + pipeline["sink"]["name"] + ")")
                else:
                    table_data.append("")
                table.append_row(table_data)
            return table

    @staticmethod
    def delete_flow(auth, src_id=None, dataset_id=None):
        """
           To delete a pipeline
           :Params
               auth (string): auth token
               src_id (string): id of a source
               dataset_id (string): id of a dataset
           :Returns
               None

           """
        if src_id:
            temp_url = "data_flows/data_source/%d?include_dependent_flows=1" % int(src_id)
        if dataset_id:
            temp_url = "data_flows/%d?include_dependent_flows=1" % int(dataset_id)
        resp = auth.call_url_return_json(method="DELETE", url=temp_url)
        if resp.get("message") != "" and resp.get("message") != None:
            print(resp.get("message"))
        else:
            print("Deleted flow Successfully")

    @staticmethod
    def pause_flow(auth, src_id=None, dataset_id=None):
        """
           To pause a pipeline
           :Params
               auth (string): auth token
               src_id (string): id of a source
               dataset_id (string): id of a dataset
           :Returns
               None

           """
        if src_id:
            temp_url = "data_flows/data_source/%d/pause?include_dependent_flows=1" % int(src_id)
        if dataset_id:
            temp_url = "data_flows/%d/pause?include_dependent_flows=1" % int(dataset_id)
        resp = auth.call_url_return_json(method="PUT", url=temp_url)
        if resp.get("message") != "" and resp.get("message") != None:
            print(resp.get("message"))
        else:
            print("Paused flow Successfully")

    @staticmethod
    def activate_flow(auth, src_id=None, dataset_id=None):
        """
           To activate a pipeline
           :Params
               auth (string): auth token
               src_id (string): id of a source
               dataset_id (string): id of a dataset
           :Returns
               None

           """
        if src_id:
            temp_url = "data_flows/data_source/%d/activate?include_dependent_flows=1" % int(src_id)
        if dataset_id:
            temp_url = "data_flows/%d/activate?include_dependent_flows=1" % int(dataset_id)
        resp = auth.call_url_return_json(method="PUT", url=temp_url)
        if resp.get("message") != "" and resp.get("message") != None:
            print(resp.get("message"))
        else:
            print("Activated flow Successfully")


'''
    def get_last_read_time(self, duration=24 * 3600, start=None, end=None, ignore_zero_byte_events=False):
        """
        get the most recent time when the source read
        :Params
            duration (int): number of seconds from current timestamp to be considered to fetch read time
            start (int): start time as epoch
            end (int): end time as epoch
            ignore_zero_byte_events (bool): if zero byte events need to be ignored
        :Returns
            int: the most recent time when the source read

        """
        return self.data_source.get_success_stream(goback_secs=duration, start=start, end=end).get_latest_event_epoch(
            ignore_zero_byte_events=ignore_zero_byte_events)

    def get_last_read_error_time(self, duration=24 * 3600, start=None, end=None):
        """
        get the most recent time when the source had error while reading
        :Params
            duration (int): number of seconds from current timestamp to be considered to fetch read time
            start (int): start time as epoch
            end (int): end time as epoch
        :Returns
            int: the most recent time when the source had error while reading

        """
        return self.data_source.get_error_stream(goback_secs=duration, start=start, end=end).get_latest_event_epoch()

    def get_last_write_time(self, duration=24 * 3600, start=None, end=None, ignore_zero_byte_events=False):
        """
        get the most recent time when the sink wrote
        :Params
            duration (int): number of seconds from current timestamp to be considered to fetch write time
            start (int): start time as epoch
            end (int): end time as epoch
            ignore_zero_byte_events (bool): if zero byte events need to be ignored
        :Returns
            int: the most recent time when the source read

        """
        return self.data_sink.get_success_stream(goback_secs=duration, start=start, end=end).get_latest_event_epoch(
            ignore_zero_byte_events=ignore_zero_byte_events)

    def get_last_write_error_time(self, duration=24 * 3600, start=None, end=None):
        """
        get the most recent time when the sink had error while writing
        :Params
            duration (int): number of seconds from current timestamp to be considered to fetch write time
            start (int): start time as epoch
            end (int): end time as epoch
        :Returns
            int: the most recent time when the sink had error while writing

        """
        return self.data_sink.get_error_stream(goback_secs=duration, start=start, end=end).get_latest_event_epoch()
'''