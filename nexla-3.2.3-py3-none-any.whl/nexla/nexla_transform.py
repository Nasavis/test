import json
import copy
import base64
from collections import OrderedDict


class DataTransform(object):

    @staticmethod
    def get_all(auth, reusable="false", transform_type=None, access_role = "collaborator"):
        """
        Get all transform informations
        :Params
            auth (string): auth token
            reusable (boolean): return a boolean value
            transform_type (string): type of transform
            access_role (strin): collaborator information
        :Returns
            DataSource: returns source object

        """
        transforms_list = []
        if reusable.lower() == "true":
            resp = auth.call_url_return_json("code_containers?expand=1&reusable=1&access_role=%s" %access_role)
        else:
            resp = auth.call_url_return_json("code_containers?expand=1&access_role=%s" %access_role)

        for rt in resp:
            if (transform_type != None):
                if (rt.get("output_type") == transform_type):
                    transforms_list.append(rt)
            else:
                transforms_list.append(rt)
        return transforms_list

    def __init__(self, auth, **kwargs):
        """
        Transform initializer.
        :Params
            auth (string): auth token
            payload (string): request body having transform details
            transform_id (int): transform id
        :Returns
            None

        """
        self.auth = auth
        self.access_role = "collaborator"
        if "payload" in kwargs:
            self._init_from_payload(payload=kwargs["payload"])
        elif "transform_id" in kwargs:
            self._init_from_id(auth,transform_id=kwargs["transform_id"])
        else:
            raise Exception("Unsupported Initialization of Transform Object")

    def _init_from_id(self, auth_obj, transform_id ):
        """
        Transform initializer using id.
        :Params
            auth_obj (string): auth token
            transform_id (int): transform id
        :Returns
            None

        """
        # Fix for ResourceNotFound error while export(reusable_trasnsforms not found)
        resp = auth_obj.call_url_return_json("code_containers/%d?expand=1&access_role=%s" % (transform_id, self.access_role), resource="resuable transform", id=transform_id)
        self._init_from_payload(payload=resp)

    def _init_from_payload(self,payload=None):
        """
        Transform initializer using payload.
        :Params
            payload (string): request body having transform details
        :Returns
            None

        """
        if payload == None:
            raise Exception("Missing payload to initialize Transform")
        self.attributes={}
        self.attributes["raw"]=payload
        self.attributes["id"] = payload.get("id", "")
        self.attributes["name"] = payload.get("name","")
        self.attributes["description"] = payload.get("description","")
        self.attributes["reusable"] = payload.get("reusable","")
        self.attributes["code"] = payload.get("code","")
        self.attributes["custom_config"] = payload.get("custom_config","")
        self.attributes["code_type"] = payload.get("code_type", "")
        self.attributes["output_type"] = payload.get("output_type", "")
        self.attributes["code_encoding"] = payload.get("code_encoding", "")
        self.attributes["tags"] = payload.get("tags", "")
        self.attributes["created_at"] = payload.get("created_at","").replace('.000Z', '')
        self.attributes["updated_at"] = payload.get("updated_at", "").replace('.000Z', '')

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def __str__(self):
        return("ID: %d, Name: %s" % ( self.attributes.get("id",""), self.attributes.get("name","")))

    
    @staticmethod
    def transform_file_data(auth, file_path, dataset_id=None, transform_id=None):
        """
        Transform data in file using a dataset or a transform
        :Params
            auth (string): auth token
            file_path (string): file path
            dataset_id (int): dataset id to be used for transformation
            transform_id (int): transform id to be used for transformation
        :Returns
            string: response of transform call

        """
        try :
            with open(file_path) as jsonFile:  
                inputData = json.load(jsonFile,object_pairs_hook=OrderedDict)
        except :
            raise Exception("Invalid path or file name")
        if transform_id:
            resp = auth.call_url_return_json("/transforms/%d/transform"%transform_id, method="POST", payload=inputData)
            return resp
        else:
            resp = auth.call_url_return_json("/data_sets/%d/transform"%dataset_id, method="POST", payload=inputData)
            return resp


    @staticmethod
    def transform_sample_data(auth, dataset_id, transform_id=None, dataset_id_trans=None):
        """
        Transform sample data using a dataset or a transform
        :Params
            auth (string): auth token
            dataset_id (int): id of the dataset from where sample data will be taken
            dataset_id_trans (int): dataset id to be used for transformation
            transform_id (int): transform id to be used for transformation
        :Returns
            string: response of transform call

        """
        sample_data = auth.call_url_return_json("/data_sets/%d/samples?count=5&include_metadata=1&output_only=1"%dataset_id) #confirm api
        if transform_id:
            resp = auth.call_url_return_json("/transforms/%d/transform"%transform_id, method="POST", payload=sample_data)
            return resp
        else:
            resp = auth.call_url_return_json("/data_sets/%d/transform"%dataset_id_trans, method="POST", payload=sample_data)
            return resp


    @staticmethod
    def create_transform(auth, transform_name=None, code_type=None, code=None):
        """
        Create transform
        :Params
            auth (string): auth token
            transform_name (string): name of transform
            code_type (string): type of transform code
            code (string): transform code
        :Returns
            DataTransform: returns transform object

        """

        if not transform_name or not code_type or not code:
            print("Enter name, code type and code of transform")
            return None
        else:
            payload = copy.deepcopy(transform_create_template)
            payload["name"] = transform_name
            payload["code_type"] = code_type
            if code_type == "jolt_standard":
                payload["code"] = code
            elif code_type == "python":
                python_code = copy.deepcopy(python_transform_code_template)
                python_code["spec"]["script"] = base64.b64encode(code)
                payload["code"] = python_code
            resp = auth.call_url_return_json("/transforms", method="POST", payload=payload)
            trans_obj = DataTransform(transform_id=resp["id"])
            return trans_obj

    @staticmethod
    def create_reusable_transform(auth, payload):
        """
        Create reusable transform
        :Params
            auth (string): auth token
            payload (string): payload of reusable transform details
        :Returns
            DataTransform: returns reusable transform object
        """
        if payload.get("output_type") == "attribute":
            resp = auth.call_url_return_json("/attribute_transforms", method="POST", payload=payload)
        else:
            resp = auth.call_url_return_json("/transforms", method="POST", payload=payload)
        trans_obj = DataTransform(auth=auth, transform_id=resp["id"])
        return trans_obj

    @staticmethod
    def update_reusable_transform(auth, payload, transform_id):
        """
        Create reusable transform
        :Params
            auth (string): auth token
            payload (string): payload of reusable transform details
        :Returns
            DataTransform: returns reusable transform object
        """
        del payload['id']
        del payload["accessors"]
        del payload["meta_data"]
        tag_payload = dict({"tags": payload["tags"]})
        try:
            if payload.get("output_type") == "attribute":
                resp = auth.call_url_return_json("/attribute_transforms/%d" % transform_id, method="PUT", payload=payload)
                auth.call_url_return_json("/code_containers/%d/tags" % transform_id, method="POST",payload=tag_payload)
            else:
                resp = auth.call_url_return_json("/transforms/%d" % transform_id, method="PUT", payload=payload)
                auth.call_url_return_json("/code_containers/%d/tags" % transform_id, method="POST",payload=tag_payload)
        except Exception:
            print("Please ensure that the targeted transform type and the payload transform type are of the same type.")
        trans_obj = DataTransform(auth=auth, transform_id=resp["id"])
        return trans_obj

    @staticmethod
    def get_transforms_accessors(auth, trans_id):
        """
        Get transform accessors details.
        :Params
            auth (string): auth token
            trans_id (string): transform id
        :Returns
            Accessors: returns transform accessors details
        """
        try:
            accessors_config = auth.call_url_return_json("code_containers/%s/accessors" % trans_id, method="GET")
            return accessors_config
        except:
            print("Unable to get the accessors details")

    @staticmethod
    def create_transforms_accessors(auth, trans_id, payload):
        """
        Create transform accessors using payload
        :Params
            auth (string): auth token
            trans_id (string): transform id
            payload (string): request body having transform accessors details
        :Returns
            Accessors: returns transform accessors object
        """
        try:
            accessors_config = auth.call_url_return_json("code_containers/%s/accessors" % trans_id, method="POST", payload=payload)
            return accessors_config
        except Exception:
            print("Creation of accessors will not scope for outside the environment")
            return False

    def attach_transform_to_dataset(self, dataset_id, copy_transform=False):
        # if copy_transform == False:
        #     transform_payload = {
        #         transform_id = self.get("id")
        #     }
        #     code = auth.call_url_return_status("/data_sets/%d?expand=1" % dataset_id, payload=transform_payload, method="PUT")
        #     return code
        # else:
        #     return
        #to be completed
        return

    def get_reusable_transform_json(self, reusable_trans_id = None):
        reusable_transform_details = OrderedDict()
        reusable_transform_details["id"] = self.get("id")
        reusable_transform_details["name"] = self.get("name")
        reusable_transform_details["description"] = self.get("description")
        reusable_transform_details["reusable"] = self.get("reusable")
        reusable_transform_details["code_type"] = self.get("code_type")
        reusable_transform_details["output_type"] = self.get("output_type")
        reusable_transform_details["code_encoding"] = self.get("code_encoding")
        reusable_transform_details["code"] = self.get("code")
        reusable_transform_details["custom_config"] = self.get("custom_config")
        reusable_transform_details["tags"] = self.get("tags")
        return reusable_transform_details

    @staticmethod
    def replace_transform_in_dataset(auth, dataset_id, transform):
        """
        Replace transform in a dataset
        :Params
            auth (string): auth token
            dataset_id (int): id of dataset where transform needs to be replaced
            transform (string): transform code
        :Returns
            int: returns response code

        """
        transform_payload = copy.deepcopy(replace_transform_template)
        transform_payload["transforms"] = transform
        code = auth.call_url_return_status("/data_sets/%d?expand=1" % dataset_id, payload=payload, method="PUT")
        return code

    def update_transform(self, transform_name=None, reusable=None, transform=None):
        """
        Update a transform
        :Params
            transform_name (string): name of transform
            reusable (boolean): True if the transform is reusable, False otherwise
            transform (string): transform code
        :Returns
            None

        """
        payload = copy.deepcopy(transform_update_template)
        payload["name"] = self.attributes["name"]
        payload["reusable"] = self.attributes["reusable"]
        payload["code"] = self.attributes["code"]
        if transform_name:
            payload["name"] = transform_name
        elif reusable:
            payload["reusable"] = reusable
        elif transform:
            payload["code"] = transform
        else:
            print("Invalid arguments. Unable to update transform.")
            return
        code = self.auth.call_url_return_json("/transforms/%d?expand=1" % self.attributes["id"], payload=payload, method="PUT")
        if (str(code) == "200"):
            print("Successfully updated.")
        else:
            print("Failed to update. Received response code = %s" % str(code)) 
    
    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def __str__(self):
        return("ID: %d, Name: %s" % ( self.attributes.get("id",""), self.attributes.get("name","")))


transform_update_template = {
  "name": "",
  "reusable": 0,
  "code": []
}
transform_create_template = {
  "name": "",
  "code_type":"",
  "code": []
}
python_transform_code_template = { 
    "operation": "nexla.custom",
    "spec": {
      "language": "python",
      "script": ""
    }
}
replace_transform_template = {
    "transform" : {
        "version" : 1,
        "transforms" : []
    }
}
