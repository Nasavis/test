#!/usr/bin/python -u
import json
import re
import copy
import sys
from beautifultable import BeautifulTable
from collections import OrderedDict
from datetime import datetime
import base64
from nexla.nexla_auth import Auth
from nexla.nexla_source import DataSource
from nexla.nexla_dataset import DataSet
from nexla.nexla_sink import DataSink
from nexla.nexla_credentials import DataCredentials
from nexla.nexla_pipelines import DataPipeline
from nexla.nexla_datamap import DataMap
from nexla.nexla_transform import DataTransform
from nexla.log_config import log
from io import StringIO
import os

def print_log_with_utc(text):
    utcnow = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    text = "[%s UTC] %s" %(utcnow,text)
    print(text)

class ImportExport(object):
    def __init__(self, auth, properties_file = None):
        """
        Export file initializer.
        :Params
            auth (string): auth token
            properties_file (string): path and name of the properties file.
        :Returns
            None

        """
        self.auth = auth
        self.pipeline_inputs = OrderedDict()
        self.pipeline_metadata = OrderedDict()
        self.pipeline_metadata["exported_dataset_ids"] = {}
        self.pipeline_metadata["exported_detected_dataset_ids"] = {}
        self.pipeline_metadata["exported_sink_ids"] = {}
        self.pipeline_metadata["dataset_ids_to_update"] = {}
        self.pipeline_metadata["sink_ids_to_update"] = {}
        self.pipeline_metadata["detected_dataset_ids_to_update"] = {}
        self.pipeline_metadata["source_id_to_update"] = ''
        self.use_inputs = False
        self.is_current_env = False
        self.properties_data = ''
        self.transform_template = {
        "version": 1,
        "data_maps": [],
        "transforms": [],
        "custom_config": {}
    }
        if properties_file != None and properties_file != '':
            try:
                with open(properties_file) as json_file:
                    self.import_properties = json.load(json_file, object_pairs_hook=OrderedDict)
            except:
                print_log_with_utc("Invalid path or file name")
                raise Exception("Invalid path or file name")
        else:
            self.import_properties = None

    def load_inputs_from_properties(self, import_json, property_json):
        """
        Load inputs from properties file
        :Params
            import_json (string): importing file details
            property_json (string): importing property file details
        :Returns
            None

        """
        for key in property_json:
            if import_json.get(key) != None:
                if isinstance(property_json.get(key), dict):
                    self.load_inputs_from_properties(import_json.get(key), property_json.get(key))
                    continue
                import_json[key] = property_json.get(key)


    def export_pipelines(self,src_id,sink_id=None,pipeline_ids=[],output_file="export_pipeline.json"):
        """
        Export a pipeline
        :Params
            src_id (string): id of the source
            sink_id (string): id of the destination
            pipeline_ids (list): list of pipelines to be exported.
        :Returns
            None

        """
        pipeline_details = {}
        properties = {}
        if sink_id != None:
            detected_dataset_details, dataset_details, sink_details, data_map_details, reusable_trans_details = self.get_dataset_schema(src_id,sink_id=sink_id)
        else:
            detected_dataset_details, dataset_details, sink_details, data_map_details, reusable_trans_details = self.get_dataset_schema(src_id,pipeline_ids=pipeline_ids)
        self.replace_value_recursive(dataset_details)
        src_obj = DataSource(self.auth,id=src_id)
        src_details, src_config_details = self.get_source_details(src_obj)
        pipeline_details["source"] = src_details
        if ("script_config" in src_details):
            pipeline_details["source"]["source_config"] = src_config_details.get("source_config")
        pipeline_details["detected_dataset"] = detected_dataset_details
        pipeline_details["dataset"] = dataset_details
        pipeline_details["sink"] = sink_details
        pipeline_details["data_maps"] = data_map_details
        pipeline_details["reusable_transforms"] = reusable_trans_details
        pipeline_details["meta_data"] = {}
        pipeline_details["meta_data"]["env"] = self.get_enviroment()
        properties["inputs"] = self.pipeline_inputs
        properties["meta_data"] = self.pipeline_metadata
        with open(output_file, 'w') as outfile:
            json.dump(pipeline_details, outfile,indent=4)
        properties_file = output_file.split(".")[0]+"_properties.json"
        with open(properties_file, 'w') as out_prop_file:
            json.dump(properties, out_prop_file, indent=4)
        print_log_with_utc("The config files are exported to ===> %s" % output_file)

    # Handle the re-usable tx and datamap updates using the recursion method.
    def replace_value_recursive(self, data):
        """
        To handle the Name and value for datamaps and reusable_transform
        while replacing and updating
        :Params
            data (dict): dataset payload
        :Returns
            will not return anything, it will update the existing dataset payload
        """
        if isinstance(data, dict):
            for key, value in data.items():
                if isinstance(value, dict) or isinstance(value, list):
                    self.replace_value_recursive(value)
                elif self.properties_data and key == "name" and data[key] and "customAttrTx" in data[key]:
                    val = data['parameters']['attrTxId']['value']
                    val = str(val).replace("<", "").replace(">", "")
                    if val in self.properties_data['inputs']:
                        reuse_id = self.properties_data['inputs'][val]
                        data[key] = 'customAttrTx_'+str(reuse_id)
                elif key == "name" and data[key] and "customAttrTx" in data[key]:
                    val = data['parameters']['attrTxId']['value']
                    if str(val) in self.comparision:
                        data[key] = 'customAttrTx_'+str(self.comparision.get(val))
                elif key == "value" or key == "transformId":
                    val = data[key]
                    if str(val) in self.comparision:
                        data[key] = self.comparision[str(val)]
                    val = str(val).replace("<", "").replace(">", "")
                    if self.properties_data and val in self.properties_data['inputs']:
                        data[key] = self.properties_data['inputs'][val]
        elif isinstance(data, list):
            for item in data:
                self.replace_value_recursive(item)

    def create_source_datasets(self, src_dataset_payloads, src_id):
        """
        Create a source dataset while import a pipeline
        :Params
            src_id (string): id of the source
            src_dataset_payloads (string): payload of the source dataset
        :Returns
            ID: return dataset id's

        """
        dataset_ids_map = {}
        for src_dataset_name, ds_payload in src_dataset_payloads.items():
            # print(src_dataset_name)
            ds_payload["output_schema"] = ds_payload.get("source_schema")
            ds_payload["transform"] = self.transform_template
            ds_payload["data_source_id"] = src_id
            ds_payload.pop("parent_data_set_id")
            sharers = ds_payload.get("sharers")
            del ds_payload["sharers"]
            resp = DataSet.create(self.auth, payload=ds_payload)
            self.create_the_accessors(sharers=sharers, id=resp.get("id"))
            dataset_id = int(resp.get("id"))
            dataset_ids_map[src_dataset_name] = dataset_id
        return dataset_ids_map

    def create_dataset_from_dataset(self, dataset_payload, parent_dataset_id, credential_id = ''):
        """
        Create a source dataset while import a pipeline
        :Params
            parent_dataset_id (string): id of the parent dataset
            dataset_payload (string): payload of the dataset details
        :Returns
            ID: return created dataset id

        """
        dataset_payload["parent_data_set_id"] = parent_dataset_id
        print_log_with_utc("Creating Nexset : %s"%dataset_payload.get("name"))
        sharers = dataset_payload.get("sharers")
        del dataset_payload["sharers"]
        resp = DataSet.create(self.auth, payload=dataset_payload)
        print_log_with_utc(resp)
        self.create_the_accessors(sharers=sharers, id=resp.get("id"))
        dataset_id = int(resp.get("id"))
        # Update Output Schema once the dataset is created
        op_schema = {}
        op_schema["output_schema"] = dataset_payload.get("output_schema")
        if (resp):
            ds_obj = DataSet(auth=self.auth, dsid=dataset_id)
            res = ds_obj.update(payload=op_schema)
        print_log_with_utc("Created Nexset with ID, %d from nexset %d" % (dataset_id,parent_dataset_id))
        return dataset_id

    # get the accessors payload
    def get_accessors_payload(self, sharers):
        """
        Get accessors details
        :Params
            sharers (string): sharers details
        :Returns
            ID: return accessors details

        """
        result = []
        try:
            for sharer in sharers:
                res = {}
                res["id"] = sharer.get("id")
                res["type"] = sharer.get("type")
                res["org_id"] = sharer.get("accessor_org_id")
                res["access_role"] = sharer.get("access_roles")[0]
                result.append(res)
            return result
        except:
            print("Error while updating accessors: id, type, accessor_org_id and access_roles should be present in the sharer details")
            sys.exit(0)

    # create the access roles for datasets
    def create_the_accessors(self, sharers, id):
        """
        Create a accessors for datasets
        :Params
            sharers (string): sharers details
            id (string): dataset id
        :Returns
            None

        """
        accessors = {}
        if self.is_current_env:
            result = self.get_accessors_payload(sharers)
            accessors["accessors"] = result
            DataSet.add_accessors(self.auth, payload=accessors, dsid=id)
        else:
            print_log_with_utc("Creation of accessors will not scope for outside the environment")

    # create the accessors payload to create the access roles
    def create_accessors_payload(self, payload):
        """
        Create a accessors payload
        :Params
            payload (string): accessors details
        :Returns
            None

        """
        acc_payload = []
        if (payload.get("accessors")):
            acc_payload = payload["accessors"]
            del payload["accessors"]
        accessors_payload = {}
        accessors_payload["accessors"] = acc_payload
        return acc_payload, accessors_payload

    # create the sink from the dataset
    def create_sink_from_dataset(self, sink_payload,dataset_id):
        """
        Create sink from the dataaset
        :Params
            sink_payload (string): accessors details
            dataset_id (string): id of the dataset
        :Returns
            None

        """
        sink_type = sink_payload["sink_type"]
        credential_id_list = []
        log.debug(sink_type)
        if not self.use_inputs and sink_payload['sink_type'] not in ["data_map", "script"]:
            credentials_list = DataCredentials.get_all_credentials(self.auth,type=sink_type, access_role="collaborator")
            if len(credentials_list)==0:
                print_log_with_utc("No credentials found. Skipping..")
                return
            if sink_payload.get("data_credentials"):
                if "<" in str(sink_payload["data_credentials"]):
                    print_log_with_utc("Credential Name given on Exported Flow : %s" % (re.match(r"<.*:(.*)>", sink_payload.get("data_credentials"))).group(1))
                    print_log_with_utc("credential_id \t credential_name")
                    for credential in credentials_list:
                        credential_id_list.append(credential.id)
                        print_log_with_utc("    %d \t\t %s"%(credential.id,credential.name))
                    credential_id = int(input("Enter credential_id : "))
                    if credential_id not in credential_id_list:
                        print("Given Credential ID doesn't match with given credentials list, select credential from given list")
                        exit(1)
                    sink_payload["data_credentials"] = credential_id
                else:
                    credential_id = int(sink_payload["data_credentials"])
                for i in range(len(credentials_list)):
                    if int(credentials_list[i].id) != credential_id:
                        continue
                    else:
                        break
                if i == len(credentials_list):
                    print_log_with_utc("Invalid credential id")
                    raise AttributeError("Invalid credential id")
            if (sink_type.lower() == "mysql" or sink_type.lower() == "redshift" or sink_type.lower() == "snowflake" or sink_type.lower() == "postgres"):
                sink_config = sink_payload["sink_config"]
                cred = DataCredentials(self.auth, id=credential_id)
                mapping_fields_lower = list((sink_config["mapping"]["mapping"]).keys())
                mapping_fields_lower = [x.lower() for x in mapping_fields_lower]
                mapping_fields_lower.sort()
                m_database = sink_config["database"]
                m_tablename = sink_config["table"]

                ins_method = sink_config["insert.mode"]
                if(ins_method == "UPSERT"):
                    m_primary_key = sink_config["primary.key"]
                else:
                    m_primary_key = ""

                create_destination = "false"
                print_log_with_utc(
                    "received  database = %s ,\n received m_tablename = %s ,\n received m_primary_key = %s ,\n insert mode = %s" % (
                    m_database, m_tablename, m_primary_key, ins_method))
                print_log_with_utc("------building payload-------")

                # get all tables for given credential
                json_payload = json.loads(str("{\"database\":\"%s\"}" % m_database))
                if sink_type.lower() == "bigquery":
                    tables = cred.probe_tree(payload=json_payload)
                else:
                    tables = cred.probe_tree(payload={})

                table_names = []
                table_index = 1
                print_log_with_utc("Previous table name was : %s" % m_tablename)
                print_log_with_utc("List of Tables present in Database")
                print_log_with_utc("---------------------------------------------------------------------------")
                print_log_with_utc("No.  --  Table Name")
                for name, val in list((tables["output"][m_database]["value"]).items()):
                    table_name = name
                    table_names.append(table_name)
                    print_log_with_utc("%s  --  %s" % (table_index, table_name))
                    table_index = table_index + 1

                print_log_with_utc("---------------------------------------------------------------------------")
                iter = True
                while (iter):
                    selected_t_name = input("Select any one of the table name: \n Type \"create\" if you want to create new table : ")
                    if (selected_t_name in table_names):
                        print_log_with_utc("Selecting %s as table name" % selected_t_name)
                        m_tablename = selected_t_name
                        iter = False
                    elif (selected_t_name.strip() == "create"):
                        table_already_in_use = m_tablename
                        # to handle if space or empty value given
                        while True :
                            m_tablename = input("Enter New Table Name : ")
                            if m_tablename.isspace() or m_tablename == '':
                                print("You’ve entered an empty or invalid table name. Please provide a valid table name.")
                            else:
                                break
                        m_tablename = m_tablename.strip().replace(" ", "_")
                        if m_tablename in table_names:
                            print("Table %s already exists , please create a unique table name or use the existing one" % m_tablename)
                            continue
                        while True:
                            ins_method = input("Choose mode of operation: INSERT/UPSERT : ").upper()
                            if ins_method in ["INSERT", "UPSERT"]: break
                            else: print("Please Select valid mode of operation, Either INSERT/UPSERT : ")
                        if (ins_method == "UPSERT"):
                            m_primary_key = input("Select Primary Key for Table:")
                        else:
                            m_primary_key = ""
                        mapping_fields_lower = [x.lower() for x in mapping_fields_lower]
                        create_destination = "true"
                        iter = False
                    else:
                        print_log_with_utc("Selected Table name = %s not matched with existing tables" % selected_t_name)
                        print_log_with_utc("!!!!!!Select any Existing table or create new!!!!!!")
                if(create_destination == "true"):
                    sink_payload["create_destination"] = create_destination
                sink_payload["sink_config"]["table"] = m_tablename
                if(m_primary_key != ""):
                    sink_payload["sink_config"]["primary.key"] = m_primary_key
                sink_payload["sink_config"]["insert.mode"] = ins_method

            elif sink_type.lower() == "bigquery" :
                sink_config = sink_payload["sink_config"]
                mapping_fields_lower = list((sink_config["mapping"]["mapping"]).keys())
                mapping_fields_lower = [x.lower() for x in mapping_fields_lower]
                mapping_fields_lower.sort()
                m_database = sink_config["database"]
                m_tablename = sink_config["table"]
                database_url = "data_credentials/%d/probe/tree"
                resp = self.auth.call_url_return_json(database_url % (credential_id), method="POST", payload={})
                print_log_with_utc("Available database in Provided GBQ credential %d" % credential_id)
                print_log_with_utc("---------------------------------------------------------------------------")
                print_log_with_utc("Databases list")
                db_list =[]
                for dbs in resp["output"].keys():
                    db_list.append(dbs)
                for db in db_list:
                    print_log_with_utc("%s" % db)
                print_log_with_utc("---------------------------------------------------------------------------")
                print_log_with_utc("Previous database name was : %s" % m_database)
                database = input("Enter database you wanted to create a table : ")
                if database not in db_list:
                    print("Given database not found in provided GBQ Cred")
                    exit(2)
                json_payload = json.loads(str("{\"database\":\"%s\"}" % database))
                # print("json_payload", json_payload)
                cred = DataCredentials(self.auth, id=credential_id)
                tables = cred.probe_tree(payload=json_payload)
                # print("tables", tables)
                table_names = []
                table_index = 1
                print_log_with_utc("List of Tables present in Database")
                print_log_with_utc("---------------------------------------------------------------------------")
                print_log_with_utc("No.  --  Table Name")
                for name, val in list((tables["output"][database]["value"]).items()):
                    table_name = name
                    table_names.append(table_name)
                    print_log_with_utc("%s  --  %s" % (table_index, table_name))
                    table_index = table_index + 1
                print_log_with_utc("---------------------------------------------------------------------------")
                print_log_with_utc("Previous table name was : %s" % m_tablename)
                ins_method = sink_config["insert.mode"]
                if(ins_method == "UPSERT"):
                    m_primary_key = sink_config["primary.key"]
                else:
                    m_primary_key = ""
                create_destination = "false"
                iter = True
                while (iter):
                    selected_t_name = input("Select any one of the table name or Type \"create\" if you want to create new table : ")
                    if (selected_t_name in table_names):
                        print_log_with_utc("Selecting %s as table name" % selected_t_name)
                        m_tablename = selected_t_name
                        iter = False
                    elif (selected_t_name.strip() == "create"):
                        table_already_in_use = m_tablename
                        # to handle if space or empty value given
                        while True :
                            m_tablename = input("Enter New Table Name : ")
                            if m_tablename.isspace() or m_tablename == '':
                                print("You’ve entered an empty or invalid table name. Please provide a valid table name.")
                            else:
                                break
                        m_tablename = m_tablename.strip().replace(" ", "_")
                        sink_payload["name"] = "GBQ-SINK - " + m_tablename
                        if m_tablename in table_names:
                            print("Table %s already exists , please create a unique table name or use the existing one" % m_tablename)
                            continue
                        while True:
                            ins_method = input("Choose mode of operation: INSERT/UPSERT : ").upper()
                            if ins_method in ["INSERT", "UPSERT"]: break
                            else: print("Please Select valid mode of operation, Either INSERT/UPSERT : ")

                        if (ins_method == "UPSERT"):
                            m_primary_key = input("Select Primary Key for Table:")
                        else:
                            m_primary_key = ""
                        mapping_fields_lower = [x.lower() for x in mapping_fields_lower]
                        create_destination = "true"
                        iter = False
                    else:
                        print_log_with_utc("Selected Table name = %s not matched with existing tables" % selected_t_name)
                        print_log_with_utc("!!!!!!Select any Existing table or create new!!!!!!")
                if(create_destination == "true"):
                    sink_payload["create_destination"] = create_destination
                sink_payload["sink_config"]["database"] = database
                sink_payload["sink_config"]["table"] = m_tablename
                if(m_primary_key != ""):
                    sink_payload["sink_config"]["primary.key"] = m_primary_key
                sink_payload["sink_config"]["insert.mode"] = ins_method
        # New method for sink-creds validation
        if self.use_inputs and sink_payload['sink_type'] not in ["data_map", "script"]:
            credentials_list = DataCredentials.get_all_credentials(self.auth, type=sink_type,access_role="collaborator")
            if len(credentials_list) == 0:
                print_log_with_utc("No credentials found. Skipping..")
                return
            for credential in credentials_list:
                credential_id_list.append(credential.id)
            credential_id = sink_payload.get('data_credentials')
            if credential_id not in credential_id_list:
                print("Given Credential ID doesn't match with given credentials list, select credential from given list")
                exit(1)

        sink_payload["data_set_id"] = dataset_id
        print_log_with_utc("Creating Sink with name : %s"%sink_payload["name"])
        sink_obj = DataSink.create(self.auth, payload=sink_payload)
        sink_id = int(sink_obj.get("id"))
        if (sink_id != None):
            print_log_with_utc("Sink created with ID: %d, and associated with nexset %d" % (sink_id, dataset_id))
        else:
            print_log_with_utc("Unable to create the sink")

    def create_reusble_transform(self):
        return None

    # update the pipeline details
    def update_pipelines(self,import_file_path, properties_file_path):
        """
        To update a existing pipeline details
        :Params
            import_file_path (string): name of the importing file path
            properties_file_path (string): name of the importing properties file path
        :Returns
            None

        """
        import_data = self.validate_json_file(file_path=import_file_path)
        if properties_file_path is not None:
            self.properties_data = self.validate_json_file(file_path=properties_file_path)
            self.use_inputs = True
        else:
            print_log_with_utc("The properties file is required for the flow update")
            sys.exit(0)

        self.is_current_env = self.check_env(import_data.get("meta_data"))
        if (
                "source_id_to_update" not in self.properties_data.get("meta_data", {}) or
                "dataset_ids_to_update" not in self.properties_data.get("meta_data", {}) or
                "detected_dataset_ids_to_update" not in self.properties_data.get("meta_data", {}) or
                "sink_ids_to_update" not in self.properties_data.get("meta_data", {})
        ):
            print_log_with_utc("Error: One or more keys are missing in the JSON file: source_id_to_update, dataset_ids_to_update, detected_dataset_ids_to_update, sink_ids_to_update.")
            sys.exit(0)
        if (
                not self.properties_data["meta_data"]["source_id_to_update"] and
                not self.properties_data["meta_data"]["dataset_ids_to_update"] and
                not self.properties_data["meta_data"]["detected_dataset_ids_to_update"] and
                not self.properties_data["meta_data"]["sink_ids_to_update"]
        ):
            print_log_with_utc("Please fill out the ID in the properties file that you want to update.")
        # Update Source
        if self.properties_data.get("meta_data").get("source_id_to_update", "") != "":
            # Handle the rest sources with lookup iterations
            src_payload = import_data.get("source")
            source_config = src_payload.get("source_config")
            if (src_payload["source_type"] == "rest" and source_config.get("dataMapKeys")):
                src_payload = self.get_rest_src_with_lookup_payload(src_payload, source_config)
                import_data["source"] = src_payload

            if import_data.get("source").get("is_plugin_script", "") == "" or import_data.get("source_type") != "nexla_rest":
                print_log_with_utc("Updating Source %s " % self.properties_data.get("meta_data").get("source_id_to_update"))
                payload = {}
                payload["source_config"] = import_data.get("source").get("source_config")
                payload["name"] = import_data.get("source").get("name")
                payload["description"] = import_data.get("source").get("description")
                payload["tags"] = import_data.get("source").get("tags")
                resp = DataSource.update(self.auth, self.properties_data.get("meta_data").get("source_id_to_update"), payload)
                if resp.get('message') == "Can't change config of active source":
                    print("Please pause the source in order to update the configuration")
                    sys.exit(0)
                if resp:
                    print_log_with_utc("The source %s has been updated successfully" % self.properties_data.get("meta_data").get("source_id_to_update"))
                data_source_id = self.properties_data.get("meta_data").get("source_id_to_update", "")
                acc_payload, accessors_payload = self.create_accessors_payload(payload=src_payload)
                DataSource.create_flows_accessors(self.auth, s_id=data_source_id, payload=accessors_payload)
            else:
                src_id = self.properties_data.get("meta_data").get("source_id_to_update")
                print("Updating of the Source %s is not supported" % src_id)
        # Update Datasets
        if self.properties_data["meta_data"]["dataset_ids_to_update"] != {}:
            for key, val in self.properties_data["meta_data"]["dataset_ids_to_update"].items():
                dataset_payload = import_data["dataset"][key]
                ds_obj = DataSet(auth=self.auth, dsid=val)
                print_log_with_utc("Updating dataset %s " % val)
                del dataset_payload["parent_data_set_id"]
                sharers = dataset_payload.get("sharers")
                del dataset_payload["sharers"]
                self.comparision = self.properties_data['inputs']
                self.replace_value_recursive(dataset_payload)
                resp = ds_obj.update(payload=dataset_payload)
                if resp:
                    print_log_with_utc("The nexset %s has been updated successfully" % val)
                self.create_the_accessors(sharers=sharers, id=val)
        # Update Detected dataset
        if self.properties_data["meta_data"]["detected_dataset_ids_to_update"] != {}:
            for key, val in self.properties_data["meta_data"]["detected_dataset_ids_to_update"].items():
                detected_dataset_payload = {}
                detected_dataset_payload["name"] = import_data["detected_dataset"][key].get('name')
                detected_dataset_payload["description"] = import_data["detected_dataset"][key].get("description")
                detected_dataset_payload["tags"] = import_data["detected_dataset"][key].get("tags")
                ds_obj = DataSet(auth=self.auth, dsid=val)
                sharers = import_data["detected_dataset"][key].get("sharers")
                print_log_with_utc("Updating detected_dataset %s " % val)
                resp = ds_obj.update(payload=detected_dataset_payload)
                if resp:
                    print_log_with_utc("The detected nexset %s has been updated successfully" % val)
                self.create_the_accessors(sharers=sharers, id=val)
        # Update Sinks
        if self.properties_data["meta_data"]["sink_ids_to_update"] != {}:
            for key, val in self.properties_data["meta_data"]["sink_ids_to_update"].items():
                sink_payload = import_data["sink"][key]
                print_log_with_utc("Updating Sink %s " % val)
                if sink_payload["sink_type"] == "data_map":
                    print_log_with_utc("Dynamic lookup sinks can't be updated.")
                try:
                    del sink_payload["data_set_id"]
                    del sink_payload["data_credentials"]
                except:
                    continue
                resp = DataSink.update(auth=self.auth, payload=sink_payload, sink_id=val)
                if resp:
                    print_log_with_utc("The sink %s has been updated successfully" % val)

    # create new pipeline using exported pipeline details
    def import_pipelines(self, import_file_path, properties_file_path=None):
        """
        To create a a new pipeline
        :Params
            import_file_path (string): name of the importing file path
            properties_file_path (string): name of the importing properties file path
        :Returns
            None

        """
        self.comparision = {}
        import_data = self.validate_json_file(file_path=import_file_path)
        if properties_file_path is not None:
            self.properties_data = self.validate_json_file(file_path=properties_file_path)
            self.use_inputs = True
        self.check_env(import_data.get("meta_data"))
        if import_data["data_maps"] != None:
            for datamap_key,datamap_value in list(import_data["data_maps"].items()):
                if self.properties_data != '':
                    datamap_id = self.properties_data.get("inputs").get(datamap_key.replace('<','').replace('>',''))
                else:
                    if (datamap_value.get("datamap_type") == "Dynamic"):
                        print_log_with_utc("Dynamic Lookup detected")
                        print_log_with_utc("Select any one of the lookups, Previous lookup name was : %s" % (datamap_value.get("name")))
                        datamap_list = DataMap.get_all(self.auth, datamap_type="Dynamic")
                        print_log_with_utc("LookupID  --  Lookup Name")
                        map_list = []
                        for map in datamap_list:
                            print_log_with_utc("%s  --  %s" % (map.get("id"), map.get("name")))
                            map_list.append(map.get("id"))
                        datamap_id = int(input("Enter lookup id you want to use: "))
                        while (datamap_id not in map_list):
                            print_log_with_utc("You can only pick from the available LookupIDs. Please try again.")
                            datamap_id = input("Enter lookup_id you want to use: ")
                            datamap_id = int(datamap_id)
                        print_log_with_utc("Lookup Id Selected is : %s" % datamap_id)
                    else:
                        print_log_with_utc("Static Lookup detected")
                        print_log_with_utc("Loading existing Lookups...")
                        datamap_list = DataMap.get_all(self.auth, datamap_type="Static")
                        print_log_with_utc("LookupID  --  Lookup Name")
                        map_list = []
                        for map in datamap_list:
                            print_log_with_utc("%s  --  %s" % (map.get("id"), map.get("name")))
                            map_list.append(map.get("id"))
                        print_log_with_utc("Previous lookup name was : %s" % (datamap_value.get("name")))
                        datamap_id = input("Enter the lookup id you want to use or type \"create\" to create new lookup: ")
                        if (datamap_id.lower() == "create"):
                            del datamap_value["datamap_type"]
                            acc_payload, accessors_payload = self.create_accessors_payload(payload=datamap_value)
                            datamap_obj = DataMap.create_datamap(self.auth, payload=datamap_value)
                            datamap_id = datamap_obj.get("id")
                            self.is_current_env = self.check_env(import_data.get("meta_data"))
                            if (acc_payload):
                                if self.is_current_env:
                                    DataMap.create_lookup_accessors(self.auth, l_id=datamap_id, payload=accessors_payload)
                                else:
                                    print_log_with_utc("Creation of accessors will not scope for outside the environmen")
                            print_log_with_utc("Lookup Id Generated is : %s" % datamap_id)
                        else:
                            try:
                                datamap_id = int(datamap_id)
                            except:
                                print_log_with_utc("Invalid Option given instead of LookupID or \"create\". Please try again.")
                                exit()
                            while datamap_id not in map_list:
                                print_log_with_utc("You can only pick from the available LookupIDs. Please try again.")
                                datamap_id = int(input("Enter lookup_id you want to use: "))
                                if datamap_id in map_list:
                                    break
                            print_log_with_utc("Lookup Id Selected is : %s" % datamap_id)
                    self.comparision[datamap_key] = datamap_id

                for dataset_key, dataset_payload in list(import_data["dataset"].items()):
                    for j in range(len(dataset_payload["transform"]["data_maps"])):
                        if dataset_payload["transform"]["data_maps"][j] == datamap_key:
                            dataset_payload["transform"]["data_maps"][j] = int(datamap_id)
                            break

                    for j in range(len(dataset_payload["transform"]["transforms"])):
                        if dataset_payload["transform"]["transforms"][j]["operation"] == "nexla.modify":
                            for spec_key, spec_value in list(dataset_payload["transform"]["transforms"][j]["spec"].items()):
                                if "toMapValue" in spec_value and datamap_key in spec_value:
                                    dataset_payload["transform"]["transforms"][j]["spec"][spec_key] = spec_value.replace(datamap_key, str(datamap_id))
                                    # break
                        elif(dataset_payload["transform"]["transforms"][j]["operation"] == "nexla.custom"):
                            received_script = dataset_payload["transform"]["transforms"][j]["spec"]["script"]
                            decoded_script = base64.b64decode(received_script)
                            srtingified_script = decoded_script.decode("utf-8")
                            s = StringIO(srtingified_script)
                            new_script = ""
                            for line in s:
                                if ("toMapValue2" in line or "toMapValue" in line or 'getMap' in line):
                                    new_line = line.replace(datamap_key, str(datamap_id))
                                    new_script += new_line
                                else:
                                    new_script += line
                            byte_encoded = str.encode(new_script)
                            if dataset_payload.get("custom_config") and 'txSpec' in dataset_payload.get("custom_config"):
                                dataset_payload["custom_config"]["txSpec"]["spec"][j]["data"]["code"] = str(new_script)
                                if dataset_payload["transform"]["custom_config"]:
                                    dataset_payload["transform"]["custom_config"]["txSpec"]["spec"][j]["data"]["code"] = str(new_script)
                                dataset_payload["transform"]["transforms"][j]["spec"]["script"] = base64.b64encode(byte_encoded).decode("utf-8")
        if import_data["reusable_transforms"] != {}:
            for reusable_trans_key, reusable_trans_value in list(import_data["reusable_transforms"].items()):
                if self.properties_data != '':
                    reusable_transform_id = self.properties_data.get("inputs").get(reusable_trans_key.replace('<','').replace('>',''))
                else:
                    print_log_with_utc("Reusable Attribute transform detected")
                    print_log_with_utc("Select any one of the Reusable Attribute transform, Previous Transform name was : %s" % (reusable_trans_value.get("name")))
                    reusable_transform_list = DataTransform.get_all(self.auth, reusable="true", transform_type = reusable_trans_value.get("output_type"))
                    print_log_with_utc("TransformID  --  Transform Name")
                    reusable_trans_list = []
                    for rt in reusable_transform_list:
                        print_log_with_utc("%s  --  %s" % (rt.get("id"), rt.get("name")))
                        reusable_trans_list.append(rt.get("id"))
                    while True:
                        reusable_transform_id = input("Enter the reusable_transform id you want to use or type \"create\" to create new reusable_transform: ")
                        if (reusable_transform_id.lower() == "create"):
                            acc_payload, accessors_payload = self.create_accessors_payload(payload=reusable_trans_value)
                            if reusable_trans_value.get('code_type') == 'jolt_custom':
                                    for i in range(len(reusable_trans_value.get("code"))):
                                        code = reusable_trans_value.get("code")[i].get('spec').get('script')
                                        reusable_trans_value["code"][i]['spec']['script'] = self.scan_reusable_python_transform(code)
                            else:
                                reusable_trans_value['code'] = self.scan_reusable_python_transform(reusable_trans_value.get('code'))
                            reusable_transform_obj = DataTransform.create_reusable_transform(self.auth, payload=reusable_trans_value)
                            reusable_transform_id = reusable_transform_obj.get("id")
                            if (acc_payload):
                                if self.is_current_env:
                                    DataTransform.create_transforms_accessors(self.auth, trans_id=reusable_transform_id, payload=accessors_payload)
                                else:
                                    print_log_with_utc("Creation of accessors will not scope for outside the environment")
                            print_log_with_utc("Reusable Transform Id Generated is : %s" % reusable_transform_id)
                            break
                        else:
                            try :
                                reusable_transform_id = int(reusable_transform_id)
                                break
                            except:
                                print_log_with_utc("Please choose from the available Transform IDs. Try again.")
                                continue
                    print_log_with_utc("Reusable Transform Selected ID is : %s" % reusable_transform_id)
                    self.comparision[reusable_trans_key] = reusable_transform_id

                for dataset_key, dataset_payload in list(import_data["dataset"].items()):
                    for j in range(len(dataset_payload["transform"]["transforms"])):
                        if dataset_payload["transform"]["transforms"][j]["operation"] == "nexla.modify":
                            for spec_key, spec_value in list(dataset_payload["transform"]["transforms"][j]["spec"].items()):
                                if "custom" in spec_value and reusable_trans_key in spec_value:
                                    dataset_payload["transform"]["transforms"][j]["spec"][spec_key] = spec_value.replace(reusable_trans_key, str(reusable_transform_id))
                                    # break
                        elif(dataset_payload["transform"]["transforms"][j]["operation"] == "nexla.custom"):
                            received_script = dataset_payload["transform"]["transforms"][j]["spec"]["script"]
                            decoded_script = base64.b64decode(received_script)
                            srtingified_script = decoded_script.decode("utf-8")
                            s = StringIO(srtingified_script)
                            new_script = ""
                            for line in s:
                                if ("nexla_fn.call('toMapValue2'" in line):
                                    new_line = line.replace(datamap_key, str(datamap_id))
                                    new_script += new_line
                                elif ("nexla_fn.call" and "custom" in line):
                                    new_line = line.replace(reusable_trans_key, str(reusable_transform_id))
                                    new_script += new_line
                                else:
                                    new_script += line
                            byte_encoded = str.encode(new_script)
                            if dataset_payload.get("custom_config") and 'txSpec' in dataset_payload.get("custom_config"):
                                dataset_payload["custom_config"]["txSpec"]["spec"][j]["data"]["code"] = str(new_script)
                                dataset_payload["transform"]["transforms"][j]["spec"]["script"] = base64.b64encode(byte_encoded).decode("utf-8")
                                if dataset_payload["transform"]["custom_config"]:
                                    dataset_payload["transform"]["custom_config"]["txSpec"]["spec"][j]["data"]["code"] = str(new_script)
        self.is_current_env = self.check_env(import_data.get("meta_data"))
        if (import_data.get("source").get("internal_source_type", "") == "Email"):
            src_obj = self.create_src_from_json(import_data.get("source"), import_data.get("source").get("source_config"))
        else:
            src_obj = self.create_src_from_json(import_data.get("source"), import_data.get("source_config"))
        dataset_ids_map = self.create_source_datasets(import_data["detected_dataset"], src_obj.get("id"))
        if import_data["dataset"]:
            for dataset_key, dataset_payload in list(import_data["dataset"].items()):
                if self.properties_data:
                    self.comparision = self.properties_data['inputs']
                    self.replace_value_recursive(dataset_payload)
                else:
                    self.replace_value_recursive(dataset_payload)
                parent_dataset_id = dataset_ids_map[dataset_payload["parent_data_set_id"]]
                dataset_id = self.create_dataset_from_dataset(dataset_payload, parent_dataset_id)
                dataset_ids_map[dataset_key] = dataset_id
                print_log_with_utc("Created Nexset ID ====> %s" %dataset_id)

        if import_data["sink"]:
            for sink_key, sink_payload in list(import_data["sink"].items()):
                parent_dataset_id = dataset_ids_map[sink_payload["data_set_id"]]
                print_log_with_utc("Parent Nexset ID for Sink is ===> %s" % parent_dataset_id)
                if sink_payload.get("is_plugin_script", "") != "":
                    sink_config = {}
                    if "script_config" in sink_payload:
                        self.get_credential_for_script_based_sinks(sink_payload, sink_key)
                        curr_env = self.get_enviroment()
                        if (curr_env == "beta.nexla.com"): curr_env = "beta.nexla.com"
                        elif (curr_env == "dataops.nexla.io"): curr_env = "production"
                        elif (curr_env == "qa.nexla.com"): curr_env = "qa"
                        sink_payload["sink_config"]["path"] = (sink_payload["sink_config"]["path"]).replace("<env>", curr_env)
                        sink_config["sink_config"] = sink_payload["sink_config"]
                        del sink_payload["sink_config"]
                        sink_payload["data_set_id"] = parent_dataset_id
                        print_log_with_utc("Creating Sink with name : %s" % sink_payload["name"])
                        sink_obj = DataSink.create(self.auth, payload=sink_payload)
                        if (sink_obj):
                            sink_config["script_config"] = {}
                            sink_config["script_config"]["config"] = {}
                            sink_config["sink_config"]["path"] = (sink_config["sink_config"]["path"]).replace("<sink_id>", str(sink_obj.get("id")))
                            s_obj = DataSink.create_script_sink(self.auth, payload=sink_config, id=sink_obj.get("id"))
                        sink_id = int(sink_obj.get("id"))
                        if (sink_id != None):
                            print_log_with_utc("Sink created with ID: %d, and associated with Nexset ID %d" % (sink_id, parent_dataset_id))
                        else:
                            print_log_with_utc("Unable to create the sink")
                else:
                    if self.properties_data != '':
                        if sink_payload.get('sink_type') != "data_map":
                            self.load_inputs_from_properties(sink_payload, self.properties_data.get("inputs").get(sink_key.replace('<','').replace('>','')))
                            self.use_inputs = True
                    self.create_sink_from_dataset(sink_payload, parent_dataset_id)

    # get the credential information's for script based sinks
    def get_credential_for_script_based_sinks(self, sink_payload, sink_key):
        """
        Get credential information's for script based sinks
        :Params
            sink_payload (string): payload of a sink
            sink_key (string): key values of a sink
        :Returns
            None

        """
        for key in list((sink_payload["script_config"]["config"]).keys()):
            if re.match(r"credentials..*", key):
                if self.properties_data != '':
                    self.load_inputs_from_properties(sink_payload, self.properties_data.get("inputs").get(
                        sink_key.replace('<', '').replace('>', '')))
                    self.use_inputs = True
                elif not self.use_inputs:
                    credentials_list = DataCredentials.get_all_credentials(self.auth, display_name=sink_payload["internal_sink_type"])
                    sink_type = sink_payload["internal_sink_type"]
                    credential_id_list = []
                    if len(credentials_list) == 0:
                        raise Exception("No credentials found. Skipping..")
                    elif "<" in str(sink_payload["script_config"]["config"][key]):
                        print_log_with_utc("Credential Name given on Exported Flow : %s" % (re.match(r"<.*:(.*)>", sink_payload["script_config"]["config"][key])).group(1))
                        print_log_with_utc("Available %s credentials" % sink_type)
                        print_log_with_utc("credential_id \t credential_name")
                        for credential in credentials_list:
                            credential_id_list.append(credential.id)
                            print_log_with_utc("    %d \t\t %s" % (credential.id, credential.name))
                        credential_id = int(input("Enter credential_id : "))
                        if credential_id not in credential_id_list:
                            print("Given Credential ID doesn't match with given credentials list, select credential from given list")
                            exit(2)
                        sink_payload["script_config"]["config"][key] = credential_id
                    else:
                        credential_id = int(sink_payload["script_config"]["config"][key])
                    for i in range(len(credentials_list)):
                        if int(credentials_list[i].id) != credential_id:
                            continue
                        else:
                            break
                    if i == len(credentials_list):
                        print_log_with_utc("Invalid credential id")
                        raise Exception("Invalid credential id")

    # create template for exporting source
    def get_source_details(self,src_obj):
        """
        Template for create source
        :Params
            src_obj (string): source object information
        :Returns
            Source_Details: Return the source details and config detials

        """
        src_details = OrderedDict()
        print_log_with_utc("Fetching source details")
        src_details = src_obj.get_export()
        complete_src_details = src_obj.get("raw")
        src_config_details = OrderedDict()
        if(src_details.get("source_type") != "nexla_rest"):
            if not complete_src_details.get("vendor_endpoint", "") != "":
                self.pipeline_inputs["source"] = {}
                # Handle the file upload sources credentials
                if src_details.get("source_type") == "file_upload":
                    self.pipeline_inputs["source"]["data_credentials"] = ""
                    src_details["data_credentials"] = ""
                else:
                    self.pipeline_inputs["source"]["data_credentials"] = int((re.match(r"<(.*):.*>", src_details.get("data_credentials"))).group(1))
                    src_details["data_credentials"] = "<data_credentials_id:%s>"%(re.match(r"<.*:(.*)>", src_details.get("data_credentials"))).group(1)
                src_details["tags"] = complete_src_details.get("tags")
                # Handle the rest sources with lookup iterations
                source_config = src_details.get("source_config")
                if (src_details.get("source_type") == "rest" and source_config.get("dataMapKeys")):
                    self.rest_datamap_ids = {}
                    rest_data_map_details = OrderedDict()
                    self.lookup_count = 1
                    dataMapKeys_array = []
                    iterations_array = []
                    for i in range(len(source_config["rest.iterations"])):
                        rest_iterations = source_config["rest.iterations"][i]
                        if (rest_iterations.get("map.id")):
                            dataMapKeys_array.append(rest_iterations)
                        elif (rest_iterations.get("url.template")):
                            iterations_array.append(rest_iterations)
                        elif (rest_iterations.get("body.template")):
                            iterations_array.append(rest_iterations)

                    for i in range(len(dataMapKeys_array)):
                        rest_iterations = dataMapKeys_array[i]
                        rest_datamap_id = rest_iterations.get("key")
                        datamapId = rest_iterations.get("map.id")
                        dataMapKeys_array[i]["map.id"] = "<rest_datamap_%s>" % self.lookup_count
                        dataMapKeys_array[i]["key"] = "lookup<rest_datamap_%s>" % self.lookup_count
                        dataMapKeys = source_config.get("dataMapKeys")
                        for j in range(len(iterations_array)):
                            url_template = iterations_array[j]["url.template"]
                            body_template = iterations_array[j]["body.template"]
                            pattern = rf'\{{{rest_datamap_id}\.([a-zA-Z0-9_]+)\}}'
                            def replacement(match):
                                return f"{{lookup<rest_datamap_{self.lookup_count}>.{match.group(1)}}}"
                            updated_url = re.sub(pattern, replacement, url_template)
                            updated_body = re.sub(pattern, replacement, body_template)
                            iterations_array[j]["url.template"] = updated_url
                            iterations_array[j]["body.template"] = updated_body
                        if (dataMapKeys.get(rest_datamap_id)):
                            source_config["dataMapKeys"][
                                "lookup<rest_datamap_%s>" % self.lookup_count] = dataMapKeys.get(rest_datamap_id)
                        if rest_datamap_id in source_config["dataMapKeys"]:
                            del source_config["dataMapKeys"][rest_datamap_id]
                        if datamapId not in self.rest_datamap_ids:
                            datamap_template_variable = "<rest_datamap_%d>" % self.lookup_count
                            self.rest_datamap_ids[datamapId] = datamap_template_variable
                        else:
                            datamap_template_variable = self.rest_datamap_ids[datamapId]
                        src_details["rest_data_maps"] = datamap_template_variable
                        self.lookup_count += 1
                    for key, value in list(self.rest_datamap_ids.items()):
                        datamap_obj = DataMap(self.auth, datamap_id=key)
                        temp_data_map_details = OrderedDict()
                        temp_data_map_details["name"] = datamap_obj.get("name")
                        temp_data_map_details["map_primary_key"] = datamap_obj.get("map_primary_key")
                        temp_data_map_details["data_defaults"] = datamap_obj.get("data_defaults")
                        temp_data_map_details["data_map"] = datamap_obj.get("data_map")
                        temp_data_map_details["data_type"] = datamap_obj.get("data_type")
                        temp_data_map_details["datamap_type"] = datamap_obj.get("map_type")
                        rest_data_map_details[value] = OrderedDict(temp_data_map_details)
                        self.pipeline_inputs[value.replace('<', '').replace('>', '')] = int(key)
                    src_details["rest_data_maps"] = rest_data_map_details
            else:
                # Handle Script-Runner sources
                source_type = complete_src_details["vendor"].get("display_name")
                if ("script_config" in complete_src_details):
                    script_configs = OrderedDict()
                    src_config_details["source_config"] = src_details.get("source_config")
                    src_details = OrderedDict()
                    src_id = (re.match(r".*/([0-9]+)", src_config_details["source_config"]["path"])).group(1)
                    alias_src_id = "<src_id>"
                    src_config_details["source_config"]["path"] = (src_config_details["source_config"]["path"]).replace(
                        str(src_id), alias_src_id)
                    src_details["name"] = complete_src_details["name"]
                    src_details["description"] = complete_src_details.get("description")
                    src_details["source_type"] = complete_src_details["source_type"]
                    src_details["internal_source_type"] = source_type
                    if complete_src_details["vendor_endpoint"]["id"]:
                        src_details["vendor_endpoint_id"] = complete_src_details["vendor_endpoint"]["id"]
                    src_details["ingest_method"] = complete_src_details["ingest_method"]
                    src_details["tags"] = complete_src_details.get("tags")

                    script_configs["source_config.force_single_schema"] = complete_src_details["source_config"][
                        "schema.detection.once"]
                    for key, val in list((complete_src_details["script_config"]["parameters"]).items()):
                        if (key == "script.cron"):
                            script_configs["script.start.cron"] = val
                        else:
                            script_configs["parameters.%s" % key] = val
                    if "credentials" in complete_src_details["script_config"] and len(
                            complete_src_details["script_config"]["credentials"]) != 0:
                        for i in range(len(complete_src_details["script_config"]["credentials"])):
                            self.pipeline_inputs["script_config"] = {}
                            self.pipeline_inputs["script_config"]["credentials"] = int(
                                complete_src_details["script_config"]["credentials"][i]["id"])
                            credential_name = DataCredentials.get_credential_name(self.auth, id=
                            complete_src_details["script_config"]["credentials"][i]["id"])
                            if (source_type == "Expensify"):
                                script_configs["credentials.id_%s" % i] = "<script_credential:%s>" % credential_name
                            else:
                                script_configs["credentials.id"] = "<script_credential:%s>" % credential_name
                    src_details["script_config"] = OrderedDict()
                    src_details["script_config"]["config"] = script_configs
                    src_details["is_plugin_script"] = "true"
                    print_log_with_utc("%s Source Found" % source_type)
                # Handle API Templatized based sources
                else:
                    src_details = OrderedDict()
                    print_log_with_utc("%s Source Found" % source_type)
                    src_details["name"] = complete_src_details["name"]
                    src_details["description"] = complete_src_details.get("description", "")
                    src_details["source_type"] = complete_src_details["source_type"]
                    src_details["ingest_method"] = complete_src_details["ingest_method"]
                    src_details_obj = src_obj.get_export()
                    self.pipeline_inputs["source"] = {}
                    self.pipeline_inputs["source"]["data_credentials"] = int((re.match(r"<(.*):.*>", src_details_obj.get("data_credentials"))).group(1))
                    src_details["data_credentials"] = "<data_credentials_id:%s>" % (re.match(r"<.*:(.*)>", src_details_obj.get("data_credentials"))).group(1)
                    src_details["source_config"] = complete_src_details["source_config"]
                    src_details["vendor_endpoint_id"] = complete_src_details.get("vendor_endpoint").get("id")
                    src_details["is_plugin_script"] = "true"
        accessors_details = DataSource.get_flows_accessors(self.auth, s_id=complete_src_details.get("id"))
        if(accessors_details):
            accessors = self.get_accessors_payload(accessors_details)
            if "access_role" in str(accessors):
                src_details["accessors"] = accessors
        self.pipeline_metadata["exported_source"] = complete_src_details.get("id")
        return src_details, src_config_details

    # create template for exporting DATASETS
    def get_dataset_schema(self, src_id, sink_id=None, pipeline_ids=None):
        """
        Template for datasets
        :Params
            src_id (string): id of a source
            sink_id (string): id of a sink
            pipeline_ids (list): list of pipeline id's
        :Returns
            None

        """
        pipeline_list = None
        if sink_id != None:
            src_sink_list = []
            src_sink_list = DataPipeline.list_pipelines(self.auth,src_id=src_id)
            sink_exists = False
            if len(src_sink_list)>0:
                for pair in src_sink_list:
                    if int(pair["sink"]["id"]) == int(sink_id):
                        sink_exists = True
                        break
                if sink_exists == False:
                    raise Exception("Invalid sink_id. Skipping..")
        elif pipeline_ids != None:
            pipeline_list = DataPipeline.list_pipelines(self.auth,src_id=src_id)
            if len(pipeline_list)>0:
                for id in pipeline_ids:
                    if int(id) not in [int(pipeline["branch_id"]) for pipeline in pipeline_list]:
                        raise Exception( "Invalid branch_id. Skipping..")

        dataset_details = OrderedDict()
        detected_dataset_details = OrderedDict()
        sink_details = OrderedDict()
        data_map_details = OrderedDict()
        print_log_with_utc("Creating template for nexset, sink and datamap")


        self.datamap_ids, export_pipeline_list={},[]
        self.reusable_trans_ids = {}

        reusable_trans_details = OrderedDict()
        dset_id_mapping_dict = {}
        detected_dataset_mapping_dict = {}
        self.dataset_counter=1
        self.sink_counter = 1
        self.datamap_counter = 1
        self.detected_dataset_counter = 1
        self.reusbale_trans_counter = 1

        # Handling the datamaps python script
        def handle_datamaps_py(transform_script_line, new_script):
            """
            To handling datamaps python scripts
            :Params
                transform_script_line (string): transform python code
                new_script (string): create a new script
            :Returns
                New_Script: returns a newly created script

            """
            try:
                data_map_ids = re.findall(r"(?:toMapValue|toMapValue2)'\s*,\s*(\d+)", str(transform_script_line))
            except:
                print("Please check the datamap ID.")
            if data_map_ids:
                for datamap_id in data_map_ids:
                    if datamap_id not in self.datamap_ids:
                        datamap_template_variable = "<datamap_%d>" %self.datamap_counter
                        self.datamap_counter += 1
                        self.datamap_ids[datamap_id] = datamap_template_variable
                    else:
                        datamap_template_variable = self.datamap_ids[datamap_id]
                    transform_script_line = transform_script_line.replace(str(datamap_id), datamap_template_variable)
            new_script += transform_script_line
            return new_script

        # Handling the getmaps python script
        def handle_getmaps_py(transform_script_line, new_script):
            """
            To handling getmaps python scripts
            :Params
                transform_script_line (string): transform python code
                new_script (string): create a new script
            :Returns
                New_Script: returns a newly created script

            """
            datamap_id = (re.match(r".*getMap.*\,(?:| )([0-9]+).*", transform_script_line)).group(1)
            if datamap_id not in self.datamap_ids:
                datamap_template_variable = "<datamap_%d>" %self.datamap_counter
                self.datamap_counter += 1
                self.datamap_ids[datamap_id] = datamap_template_variable
            else:
                datamap_template_variable = self.datamap_ids[datamap_id]
            new_line = transform_script_line.replace(str(datamap_id), datamap_template_variable)
            new_script += new_line
            return new_script

        # Handling the reusable transform python script
        def handle_reusbale_transform_py(transform_script_line, new_script):
            """
            To handling reusable transform python scripts
            :Params
                transform_script_line (string): transform python code
                new_script (string): create a new script
            :Returns
                New_Script: returns a newly created script

            """
            reusable_trans_ids = re.findall(r"[\"']custom[\"'],s*\[(\d+),", transform_script_line)
            if reusable_trans_ids:
                for reusable_trans_id in reusable_trans_ids:
                    if reusable_trans_id not in self.reusable_trans_ids:
                        reusable_trans_template_variable = "<reusable_trans_%d>" % (self.reusbale_trans_counter)
                        self.reusbale_trans_counter += 1
                        self.reusable_trans_ids[reusable_trans_id] = reusable_trans_template_variable
                    else:
                        reusable_trans_template_variable = self.reusable_trans_ids[reusable_trans_id]
                    transform_script_line = transform_script_line.replace(str(reusable_trans_id), reusable_trans_template_variable)
            new_script += transform_script_line
            return new_script

        # Scanning the jolt transform information's
        def scan_jolt_transform():
            for spec_key, spec_value in list(transform["transforms"][k]["spec"].items()):
                if ("toMapValue2" in spec_value or "toMapValue" in spec_value or "getMap" in spec_value):
                    try:
                        data_map_ids = (re.findall(r"(?:toMapValue|toMapValue2|getMap)\((\d+)",str(spec_value)))
                    except:
                        print("Please check the datamap ID.")
                    for datamap_id in data_map_ids:
                        if datamap_id not in self.datamap_ids:
                            datamap_template_variable = "<data_maps_%d>" % (self.datamap_counter)
                            self.datamap_counter += 1
                            self.datamap_ids[datamap_id] = datamap_template_variable
                        else:
                            datamap_template_variable = self.datamap_ids[datamap_id]
                        temp_dataset_details["transform"]["transforms"][k]["spec"][spec_key] = spec_value.replace(str(datamap_id), datamap_template_variable)
                        spec_value = temp_dataset_details["transform"]["transforms"][k]["spec"][spec_key]
                        temp_dataset_details["transform"]["data_maps"] = [datamap_template_variable]
                try:
                    val = re.findall(r"custom\((\d+)", str(spec_value))
                except:
                    print("Please check the reusable transform ID.")
                if (val is not None):
                    for reusable_trans_id in val:
                        if reusable_trans_id not in self.reusable_trans_ids:
                            reusable_trans_template_variable = "<reusable_trans_%d>" % (self.reusbale_trans_counter)
                            self.reusbale_trans_counter += 1
                            self.reusable_trans_ids[reusable_trans_id] = reusable_trans_template_variable
                        else:
                            reusable_trans_template_variable = self.reusable_trans_ids[reusable_trans_id]
                        temp_dataset_details["transform"]["transforms"][k]["spec"][spec_key] = spec_value.replace(str(reusable_trans_id), reusable_trans_template_variable)
                        spec_value = temp_dataset_details["transform"]["transforms"][k]["spec"][spec_key]
                        temp_dataset_details["transform"]["reusable_trans"] = [reusable_trans_template_variable]

        # Scanning the python transform information's
        def scan_python_transform(encoded_script):
            """
            To verify the encoded python transform code
            :Params
                encoded_script (string): encoded python script
            :Returns
                encoded_script: returns a encoded script depend upon the utf format

            """
            if dataset_raw.get("custom_config") and 'txSpec' in dataset_raw.get("custom_config"):
                for spec_data in dataset_raw.get("custom_config")["txSpec"]["spec"]:
                    for spec_key, spec_value in spec_data.items():
                        try:
                            if 'transformId' in str(spec_value):
                                val = re.findall(r"'transformId',\s(\d+)", str(spec_value))
                            else:
                                continue
                        except:
                            print("Please check the reusable transform ID.")
                        if (val is not None):
                            for reusable_trans_id in val:
                                if reusable_trans_id not in self.reusable_trans_ids:
                                    reusable_trans_template_variable = "<reusable_trans_%d>" % (self.reusbale_trans_counter)
                                    self.reusbale_trans_counter += 1
                                    self.reusable_trans_ids[reusable_trans_id] = reusable_trans_template_variable
                                else:
                                    reusable_trans_template_variable = self.reusable_trans_ids[reusable_trans_id]
                                temp_dataset_details["custom_config"]["txSpec"]["spec"][k][spec_key]['transformId'] = reusable_trans_template_variable
                                temp_dataset_details["transform"]["reusable_trans"] = [reusable_trans_template_variable]
            decoded_script = base64.b64decode(encoded_script)
            srtingified_script = decoded_script.decode("utf-8")
            if ("toMapValue" in srtingified_script or "getMap" in srtingified_script or "nexla_fn.call" and "custom" in srtingified_script):
                s = StringIO(srtingified_script)
                new_script = ""
                for line in s:
                    if ("toMapValue2" in line or "toMapValue" in line):
                        new_script = handle_datamaps_py(line, new_script)
                    elif ("getMap" in line):
                        new_script=handle_getmaps_py(line, new_script)
                    elif ("nexla_fn.call" and "custom" in line):
                        if (re.match(r'.*#.*check_for_pipeline_ids_range.*\,(?:| )\[[0-9]+.*',line) == None):  # Fix for ResourceNotFound error while export(avoid reusable_trasnsforms in commented line)
                            new_script = handle_reusbale_transform_py(line, new_script)
                    else:
                        new_script += line
                byte_encoded = str.encode(new_script)
                return base64.b64encode(byte_encoded).decode("utf-8")
            else:
                return encoded_script

        if pipeline_ids != None:
            for i in range(len(pipeline_ids)):
                for pipeline in pipeline_list:
                    if int(pipeline["branch_id"])==int(pipeline_ids[i]):
                        print_log_with_utc("Scanning flow branch %d " % int(pipeline_ids[i]))
                        if "data_sets" in pipeline:
                            detected_dataset_id = int(pipeline["data_sets"][0]["id"])
                            if len(detected_dataset_mapping_dict) == 0:
                                detected_dataset_template_variable = "detected_dataset_%s" % str(self.detected_dataset_counter)
                                self.detected_dataset_counter += 1
                                detected_dataset_mapping_dict[detected_dataset_id] = detected_dataset_template_variable
                            if detected_dataset_id not in detected_dataset_mapping_dict:
                                print_log_with_utc("Additional detected nexset found --> %s, adding that also" %detected_dataset_id)
                                detected_dataset_template_variable = "detected_dataset_%s" % str(self.detected_dataset_counter)
                                self.detected_dataset_counter += 1
                                detected_dataset_mapping_dict[detected_dataset_id] = detected_dataset_template_variable
                            for j in range(0, len(pipeline["data_sets"])):
                                temp_dataset_details = {}
                                dset = DataSet(self.auth, dsid=int(pipeline["data_sets"][j]["id"]))
                                dataset_raw = dset.get("raw")
                                curr_dset_id = int(pipeline["data_sets"][j]["id"])

                                if (curr_dset_id not in dset_id_mapping_dict.keys()):
                                    temp_dataset_details["name"] = pipeline["data_sets"][j]["name"]
                                    # in few cases description may come as None, this will cause error while creating dataset, to avoid that there is a if case written
                                    if (dataset_raw.get("description") == None):
                                        temp_dataset_details["description"] = ""
                                    else:
                                        temp_dataset_details["description"] = dataset_raw.get("description")

                                    if(curr_dset_id in detected_dataset_mapping_dict):
                                        temp_dataset_details["data_source_id"] = "<data_source_id>"
                                        temp_dataset_details["parent_data_set_id"] = None
                                        temp_dataset_details["source_schema"] = dataset_raw.get("source_schema")
                                        temp_dataset_details["tags"] = dataset_raw.get("tags")
                                        temp_dataset_details = self.get_sharers_details(temp_dataset_details=temp_dataset_details, dataset_raw=dataset_raw, curr_dset_id=curr_dset_id)
                                        detected_dataset_details[detected_dataset_template_variable] = OrderedDict(copy.deepcopy(temp_dataset_details))
                                        dset_id_mapping_dict[curr_dset_id] = detected_dataset_template_variable
                                    else:
                                        if dset_id_mapping_dict.get(int(dset.get("id")), "") == "":
                                            dataset_alias = "dataset_%s" % str(self.dataset_counter)
                                            self.dataset_counter += 1
                                            dset_id_mapping_dict[int(dset.get("id"))] = dataset_alias
                                            self.pipeline_metadata["exported_dataset_ids"][dataset_alias] = int(dset.get("id"))

                                        temp_dataset_details["parent_data_set_id"] = dset_id_mapping_dict[int(pipeline["data_sets"][j]["parent_data_set_id"])]
                                        transform = dataset_raw.get("transform")
                                        temp_dataset_details["output_schema"] = {}
                                        temp_dataset_details["output_schema"]["properties"] = dataset_raw.get("output_schema").get("properties")
                                        if transform["custom_config"]:
                                            temp_dataset_details["custom_config"] = transform["custom_config"]
                                        else:
                                            temp_dataset_details["custom_config"] = dataset_raw.get("custom_config")
                                        temp_dataset_details["transform"] = transform
                                        temp_dataset_details["has_custom_transform"] = dataset_raw.get("has_custom_transform")
                                        for k in range(len(transform["transforms"])):
                                            # Scan Jolt Transform
                                            if transform["transforms"][k]["operation"] == "nexla.modify":
                                                scan_jolt_transform()
                                            # Scan Python Transform
                                            elif transform["transforms"][k]["operation"] == "nexla.custom":
                                                transform["transforms"][k]["spec"]["script"] = scan_python_transform(encoded_script=transform["transforms"][k]["spec"]["script"])
                                                temp_dataset_details["has_custom_transform"] = True
                                                # scan_python_transform(transform["transforms"][k]["spec"]["script"])
                                        temp_dataset_details.update(dset.get_output_validation_schema())
                                        temp_dataset_details["tags"] = dataset_raw.get("tags")
                                        temp_dataset_details = self.get_sharers_details(temp_dataset_details=temp_dataset_details, dataset_raw=dataset_raw, curr_dset_id=curr_dset_id)
                                        dataset_details[dataset_alias] = OrderedDict(copy.deepcopy(temp_dataset_details))


                        if pipeline.get("sink", "") != "":
                            temp_sink_details = {}
                            has_sink = True
                            sink_dataset_id = int(pipeline["data_sets"][-1]["id"])
                            sink_id = pipeline["sink"]["id"]
                            sink = DataSink(self.auth, id = sink_id)
                            complete_sink_details = sink.get("raw")
                            temp_sink_details["name"] =sink.get("name")
                            temp_sink_details["sink_type"] = sink.get("sink_type")
                            if complete_sink_details.get("sink_config").get("dataset_id", "") != "":
                                del complete_sink_details["sink_config"]["dataset_id"]
                            temp_sink_details["sink_config"] = complete_sink_details.get("sink_config")
                            temp_sink_details["data_set_id"] = dset_id_mapping_dict[sink.get("data_set_id")]
                            temp_sink_details["tags"] = complete_sink_details.get("tags")

                            if (temp_sink_details["sink_type"] == "data_map"):
                                data_map_id = complete_sink_details["data_map"]["id"]
                                data_map_obj = DataMap(self.auth, datamap_id=data_map_id)
                                temp_sink_details["data_map"] = data_map_obj.get_export()

                            sink_template_variable = "sink_%s" % str(self.sink_counter)
                            if (temp_sink_details["sink_type"] == "data_map"):
                                data_map_id = complete_sink_details["data_map"]["id"]
                                data_map_obj = DataMap(self.auth, datamap_id=data_map_id)
                                temp_sink_details["data_map"] = data_map_obj.get_export()
                            if not complete_sink_details.get("vendor_endpoint", "") != "" and temp_sink_details["sink_type"] != "data_map":
                                temp_sink_details["data_credentials"] = "<data_credentials_id: %s>" % sink.get(
                                    "credentials_name")
                                self.pipeline_inputs[sink_template_variable] = {}
                                self.pipeline_inputs[sink_template_variable]["data_credentials"] = sink.get("credentials_id")
                            # For Api based vendor sinks
                            if complete_sink_details.get("vendor_endpoint", "") != "" and complete_sink_details.get("data_credentials"):
                                temp_sink_details["vendor_endpoint_id"] = complete_sink_details["vendor_endpoint"]["id"]
                                temp_sink_details["template_config"] = complete_sink_details["template_config"]
                                temp_sink_details["data_credentials"] = "<data_credentials_id: %s>" % sink.get("credentials_name")
                                del temp_sink_details["sink_config"]
                                self.pipeline_inputs[sink_template_variable] = {}
                                self.pipeline_inputs[sink_template_variable]["data_credentials"] = sink.get("credentials_id")
                            else:
                                if ("script_config" in complete_sink_details):
                                    temp_sink_details["internal_sink_type"] = complete_sink_details["vendor"].get("display_name")
                                    temp_sink_details["vendor_endpoint_id"] = complete_sink_details["vendor_endpoint"]["id"]
                                    temp_sink_details["script_config"] = {}
                                    # s_id = (re.match(r".*/([0-9]+)", temp_sink_details["sink_config"]["path"])).group(1)
                                    # curr_env = (re.match(r".*/([a-z,.]+)/[0-9]+", temp_sink_details["sink_config"]["path"])).group(1)
                                    s_id = (re.match(r".*/([a-zA-Z0-9]+)", temp_sink_details["sink_config"]["path"])).group(1)
                                    curr_env = (re.match(r".*/([a-z,.]+)/[a-zA-Z0-9]+", temp_sink_details["sink_config"]["path"])).group(1)
                                    temp_sink_details["sink_config"]["path"] = (
                                    temp_sink_details["sink_config"]["path"]).replace(str(s_id), "<sink_id>")
                                    temp_sink_details["sink_config"]["path"] = (
                                    temp_sink_details["sink_config"]["path"]).replace(curr_env, "<env>")
                                    temp_sink_details["script_config"] = {}
                                    temp_sink_details["script_config"]["config"] = {}
                                    for key, val in list((complete_sink_details["script_config"]["parameters"]).items()):
                                        temp_sink_details["script_config"]["config"]["parameters.%s" % key] = val
                                    if "credentials" in complete_sink_details["script_config"] and len(complete_sink_details["script_config"]["credentials"]) != 0:
                                        for i in range(len(complete_sink_details["script_config"]["credentials"])):
                                            self.pipeline_inputs[sink_template_variable] = {}
                                            self.pipeline_inputs[sink_template_variable]["script_config"] = {}
                                            self.pipeline_inputs[sink_template_variable]["script_config"]["config"] = {}
                                            self.pipeline_inputs[sink_template_variable]["script_config"]["config"]["credentials.id"] = int(complete_sink_details["script_config"]["credentials"][i]["id"])
                                            credential_name = DataCredentials.get_credential_name(self.auth, id=complete_sink_details["script_config"]["credentials"][i]["id"])
                                            temp_sink_details["script_config"]["config"]["credentials.id"] = "<script_credential:%s>" % credential_name
                                    print_log_with_utc("Plugin Script Sink Found")
                                    temp_sink_details["is_plugin_script"] = "true"
                                    temp_sink_details["tags"] = complete_sink_details.get("tags")
                            self.sink_counter += 1
                            sink_details[sink_template_variable] = OrderedDict(temp_sink_details)
                            self.pipeline_metadata["exported_sink_ids"][sink_template_variable] = complete_sink_details.get("id")
                        else:
                            has_sink = False
                            sink_dataset_id = None

            self.iterate_again = True
            self.processed_rt = []
            while self.iterate_again:
                reusable_trans_ids_temp = copy.deepcopy(self.reusable_trans_ids)
                if len(reusable_trans_ids_temp.keys()) > len(self.processed_rt):
                    for key, value in list(reusable_trans_ids_temp.items()):
                        if key not in self.processed_rt:
                            reusable_transform_obj = DataTransform(self.auth, transform_id=int(key))
                            reusable_transform_details = OrderedDict()
                            reusable_transform_details["name"] = reusable_transform_obj.get("name")
                            reusable_transform_details["description"] = reusable_transform_obj.get("description")
                            reusable_transform_details["reusable"] = reusable_transform_obj.get("reusable")
                            reusable_transform_details["code_type"] = reusable_transform_obj.get("code_type")
                            reusable_transform_details["output_type"] = reusable_transform_obj.get("output_type")
                            reusable_transform_details["code_encoding"] = reusable_transform_obj.get("code_encoding")
                            if reusable_transform_obj.get("code_type") == 'jolt_standard' and reusable_transform_obj.get("code_encoding") == "none":
                                reusable_transform_details["code_encoding"] = 'base64'
                                reusable_transform_details["code"] = reusable_transform_obj.get("code")
                            elif reusable_transform_obj.get("code_type") == 'jolt_custom' and reusable_transform_obj.get("code_encoding") == "none":
                                reusable_transform_details["code"] = reusable_transform_obj.get("code")

                            if type(reusable_transform_obj.get("code")) == str:
                                reusable_transform_details["code"] = scan_python_transform(encoded_script=reusable_transform_obj.get("code"))
                            if type(reusable_transform_obj.get("code")) == list and reusable_transform_obj.get('code_type') == 'jolt_custom':
                                for i in range(len(reusable_transform_obj.get("code"))):
                                    code = reusable_transform_obj.get("code")[i].get('spec').get('script')
                                    reusable_transform_details["code"][i]['spec']['script'] = scan_python_transform(encoded_script=code)

                            reusable_transform_details["custom_config"] = reusable_transform_obj.get("custom_config")
                            accessors_details = DataTransform.get_transforms_accessors(self.auth, trans_id=reusable_transform_obj.get("id"))
                            if (accessors_details):
                                accessors = self.get_accessors_payload(accessors_details)
                                if "access_role" in str(accessors) and self.is_current_env:
                                    reusable_transform_details["accessors"] = accessors
                            reusable_trans_details[value] = OrderedDict(reusable_transform_details)
                            self.processed_rt.append(key)
                            self.pipeline_inputs[value.replace('<','').replace('>','')] = int(key)
                else:
                    self.iterate_again = False

            for key, value in list(self.datamap_ids.items()):
                datamap_obj = DataMap(self.auth, datamap_id=key)
                temp_data_map_details = OrderedDict()
                temp_data_map_details["name"] = datamap_obj.get("name")
                temp_data_map_details["description"] = datamap_obj.get("description")
                temp_data_map_details["map_primary_key"] = datamap_obj.get("map_primary_key")
                temp_data_map_details["data_defaults"] = datamap_obj.get("data_defaults")
                temp_data_map_details["data_map"] = datamap_obj.get("data_map")
                temp_data_map_details["data_type"] = datamap_obj.get("data_type")
                temp_data_map_details["datamap_type"] = datamap_obj.get("map_type")
                accessors_details = DataMap.get_lookup_accessors(self.auth, l_id=datamap_obj.get("id"))
                if (accessors_details):
                    accessors = self.get_accessors_payload(accessors_details)
                    if "access_role" in str(accessors) and self.is_current_env:
                        temp_data_map_details["accessors"] = accessors
                data_map_details[value] = OrderedDict(temp_data_map_details)
                self.pipeline_inputs[value.replace('<','').replace('>','')] = int(key)
        self.comparision = copy.deepcopy(self.reusable_trans_ids)
        self.comparision.update(self.datamap_ids)
        export_detected_dataset_mapping_dict = {value: int(key) for key, value in detected_dataset_mapping_dict.items()}
        self.pipeline_metadata['exported_detected_dataset_ids'] = export_detected_dataset_mapping_dict
        return detected_dataset_details, dataset_details, sink_details, data_map_details, reusable_trans_details

    # get the sharers information's
    def get_sharers_details(self, temp_dataset_details, dataset_raw, curr_dset_id):
        """
       To get the sharers informations
       :Params
           transform_script_line (string): transform python code
           new_script (string): create a new script
       :Returns
           New_Script: returns a newly created script

       """
        temp_dataset_details["sharers"] = dataset_raw.get("sharers")
        if (len(temp_dataset_details["sharers"]) != 0):
            sharers = DataSet.get_accessors(self.auth, dsid=curr_dset_id)
            temp_dataset_details["sharers"] = sharers
        return temp_dataset_details

    # create data source from imported pipeline
    def create_src_from_json(self, src_payload, src_config_payload, is_activate = False):
        """
       To create a source from the imported pipeline information's
       :Params
           src_payload (string): payload of a source
           src_config_payload (string): config payload of a source
       :Returns
           None

       """
        acc_payload, accessors_payload = self.create_accessors_payload(payload=src_payload)
        if src_payload.get("is_plugin_script"):
            if "script_config" in src_payload:
                for key in list((src_payload["script_config"]["config"]).keys()):
                    if re.match(r"credentials..*", key):
                        credentials_list = DataCredentials.get_all_credentials(self.auth, display_name=src_payload["internal_source_type"], access_role = "collaborator")
                        source_type = src_payload["internal_source_type"]
                        credential_id_list = []
                        if len(credentials_list) == 0:
                            raise Exception("No credentials found. Skipping..")
                        if self.properties_data != '':
                            self.load_inputs_from_properties(src_payload,self.properties_data.get("inputs").get("script_config"))
                            credential_id = self.properties_data.get("inputs").get("script_config").get("credentials")
                            print_log_with_utc("Using credential %s from properties file" % credential_id)
                            src_payload["script_config"]["config"][key] = credential_id
                        elif "<" in str(src_payload["script_config"]["config"][key]):
                            print_log_with_utc("Credential Name given on Exported Flow : %s" % (
                                re.match(r"<.*:(.*)>", src_payload["script_config"]["config"][key])).group(1))
                            print_log_with_utc("Available %s credentials" % source_type)
                            print_log_with_utc("credential_id \t credential_name")
                            for credential in credentials_list:
                                credential_id_list.append(credential.id)
                                print_log_with_utc("    %d \t\t %s" % (credential.id, credential.name))
                            credential_id = int(input("Enter credential_id : "))
                            if credential_id not in credential_id_list:
                                print(
                                    "Given Credential ID doesn't match with given credentials list, select credential from given list")
                                exit(2)
                            src_payload["script_config"]["config"][key] = credential_id
                        else:
                            credential_id = int(src_payload["script_config"]["config"][key])
                        for i in range(len(credentials_list)):
                            if int(credentials_list[i].id) != credential_id:
                                continue
                            else:
                                break
                        if i == len(credentials_list):
                            print_log_with_utc("Invalid credential id")
                            raise Exception("Invalid credential id")
            else:
                ve_id = src_payload["vendor_endpoint_id"]
                src_display_name = DataSource.get_src_type_from_vendor_endpoint(self.auth, endpoint_id = ve_id)
                credentials_list = DataCredentials.get_all_credentials(self.auth, display_name=src_display_name,access_role = "collaborator" )
                credential_id_list = []
                for credential in credentials_list:
                    credential_id_list.append(credential.id)
                source_type = src_payload["source_type"]
                if len(credentials_list) == 0:
                    raise Exception("No credentials found. Skipping..")
                if self.properties_data != '':
                    self.load_inputs_from_properties(src_payload, self.properties_data.get("inputs").get("source"))
                    credential_id = self.properties_data.get("inputs").get("source").get("data_credentials")
                    if credential_id not in credential_id_list:
                        print("The Credential ID in the properties file doesn't match with given credentials list, select credential from given list")
                        exit(2)
                    print_log_with_utc("Using credential %s from properties file" % credential_id)
                elif "<" in str(src_payload["data_credentials"]):
                    print_log_with_utc("Credential Name given on Exported Flow : %s" % (
                    re.match(r"<.*:(.*)>", src_payload.get("data_credentials"))).group(1))
                    print_log_with_utc("Available %s credentials" % src_display_name)
                    print_log_with_utc("credential_id \t credential_name")
                    for credential in credentials_list:
                        credential_id_list.append(credential.id)
                        print_log_with_utc("    %d \t\t %s" % (credential.id, credential.name))
                    credential_id = int(input("Enter credential_id : "))
                    if credential_id not in credential_id_list:
                        print("Given Credential ID doesn't match with given credentials list, select credential from given list")
                        exit(2)
                    src_payload["data_credentials"] = credential_id
                else:
                    credential_id = int(src_payload["data_credentials"])
                for i in range(len(credentials_list)):
                    if int(credentials_list[i].id) != credential_id:
                        continue
                    else:
                        break
                if i == len(credentials_list):
                    print_log_with_utc("Invalid credential id")
                    raise Exception("Invalid credential id")
        else:
            if src_payload["source_type"] != "nexla_rest" and src_payload["source_type"] != "file_upload":
                credentials_list = DataCredentials.get_all_credentials(self.auth, type=src_payload["source_type"], access_role = "collaborator")
                credential_id_list = []
                for credential in credentials_list:
                    credential_id_list.append(credential.id)
                if len(credentials_list)==0:
                    raise Exception("No credentials found. Skipping..")
                if self.properties_data != '':
                    self.load_inputs_from_properties(src_payload, self.properties_data.get("inputs").get("source"))
                    credential_id = self.properties_data.get("inputs").get("source").get("data_credentials")
                    if credential_id not in credential_id_list:
                        print("The Credential ID in the properties file doesn't match with given credentials list, select credential from given list")
                        for credential in credentials_list:
                            credential_id_list.append(credential.id)
                            print_log_with_utc("    %d \t\t %s"%(credential.id,credential.name))
                        credential_id = int(input("Enter credential_id : "))
                        if credential_id not in credential_id_list:
                            raise Exception("Invalid credential id")
                            exit(2)
                    src_payload["data_credentials"] = credential_id
                elif "<" in str(src_payload["data_credentials"]):
                    print_log_with_utc("Credential Name given on Exported Flow : %s"%(re.match(r"<.*:(.*)>", src_payload.get("data_credentials"))).group(1))
                    print_log_with_utc("Available %s credentials"%src_payload["source_type"])
                    print_log_with_utc("credential_id \t credential_name" )
                    for credential in credentials_list:
                        credential_id_list.append(credential.id)
                        print_log_with_utc("    %d \t\t %s"%(credential.id,credential.name))
                    credential_id = int(input("Enter credential_id : "))
                    if credential_id not in credential_id_list:
                        print("Given Credential ID doesn't match with given credentials list, select credential from given list")
                        exit(2)
                    src_payload["data_credentials"] = credential_id
                else:
                    credential_id = int(src_payload["data_credentials"])
                for i in range(len(credentials_list)):
                    if int(credentials_list[i].id) != credential_id:
                        continue
                    else:
                        break
                if i == len(credentials_list):
                    print_log_with_utc("Invalid credential id")
                    raise Exception("Invalid credential id")
            source_config = src_payload.get("source_config")
            if (src_payload["source_type"] == "rest" and source_config.get("dataMapKeys")):
                src_payload = self.get_rest_src_with_lookup_payload(src_payload, source_config)

        print_log_with_utc("Creating Source with name : %s" % src_payload["name"])
        script_source_flag = False
        if src_payload.get("is_plugin_script"):
            is_plugin_script = True
            del src_payload["is_plugin_script"]
        if src_payload.get("internal_source_type") != None and src_payload.get("internal_source_type") != '':
            del src_payload["internal_source_type"]
            script_source_flag = True
        if src_payload["source_type"] == "file_upload":
            del src_payload["data_credentials"]
        src_obj = DataSource.create_source(self.auth, payload=src_payload)
        if "script_config" in src_payload:
            # This is specific to Script based sources
            if src_obj and script_source_flag:
                put_payload = {}
                src_config_payload = src_obj.raw.get("source_config")
                put_payload["source_config"] = src_config_payload
                meta_directory = src_obj.raw.get("script_config").get("meta_dir")
                put_payload["source_config"]["path"] = meta_directory.replace('meta/', '')
                src_obj = DataSource.create_script_source(self.auth, id=src_obj.get("id"), payload=put_payload)
        if (src_obj.get("node_id")!=None):
            print_log_with_utc("Data Flow created with Flow ID: %s" % src_obj.get("node_id"))
        if (src_obj.get("id")!=None):
            print_log_with_utc("Data Source created with Source ID: %s" % src_obj.get("id"))
            data_source_id = int(src_obj.get("id"))
            if(acc_payload):
                if self.is_current_env:
                    DataSource.create_flows_accessors(self.auth, s_id=data_source_id, payload=accessors_payload)
                else:
                    print_log_with_utc("Creation of accessors will not scope for outside the environment")
        else:
            print_log_with_utc("Unable to create a new data source")
            raise Exception("Unable to create a new data source")

        if(is_activate):
            print_log_with_utc("Activating Source now ....")
            is_activated = DataSource.activate(self.auth, src_obj.get("id"))
            if (is_activated == True):
                print_log_with_utc("Successfully activated.")
            else:
                print_log_with_utc("Activation failed")
        return src_obj

    # Handle the rest sources with lookup iterations
    def get_rest_src_with_lookup_payload(self, src_payload, source_config):
        """
          To handle the rest source with look up iterations
          :Params
              src_payload (string): payload of a source
              src_config_payload (string): config payload of a source
          :Returns
              None

          """
        i = 0
        for datamap_key, datamap_value in list(src_payload["rest_data_maps"].items()):
            if self.properties_data != '':
                datamap_id = int(self.properties_data.get("inputs").get(datamap_key.replace('<', '').replace('>', '')))
            else:
                if (datamap_value.get("datamap_type") == "Dynamic"):
                    print_log_with_utc("Dynamic Lookup detected")
                else:
                    print_log_with_utc("Static Lookup detected")
                print_log_with_utc("Select any one of the lookups, Previous lookup name was : %s" % (datamap_value.get("name")))
                print_log_with_utc("Loading existing Lookups...")
                datamap_list = DataMap.get_all(self.auth, datamap_type=datamap_value.get("datamap_type"))
                print_log_with_utc("LookupID  --  Lookup Name")
                map_list = []
                for map in datamap_list:
                    print_log_with_utc("%s  --  %s" % (map.get("id"), map.get("name")))
                    map_list.append(map.get("id"))
                datamap_id = int(input("Enter lookup id you want to use: "))

                while (datamap_id not in map_list):
                    print_log_with_utc("You can only pick from the available LookupIDs. Please try again.")
                    datamap_id = int(input("Enter lookup_id you want to use: "))
                print_log_with_utc("Lookup Id Selected is : %s" % datamap_id)

            dataMapKeys_array = []
            iterations_array = []
            for k in range(len(source_config["rest.iterations"])):
                rest_iterations = source_config["rest.iterations"][k]
                if (rest_iterations.get("map.id")):
                    dataMapKeys_array.append(rest_iterations)
                elif (rest_iterations.get("url.template")):
                    iterations_array.append(rest_iterations)
                elif (rest_iterations.get("body.template")):
                    iterations_array.append(rest_iterations)

            rest_iterations = dataMapKeys_array[i]
            rest_datamap = rest_iterations.get("key")
            dataMapKeys_array[i]["map.id"] = int(datamap_id)
            dataMapKeys_array[i]["key"] = "lookup%d" % datamap_id
            dataMapKeys = source_config.get("dataMapKeys")
            for j in range(len(iterations_array)):
                url_template = iterations_array[j]["url.template"]
                body_template = iterations_array[j]["body.template"]
                pattern = rf'\{{{rest_datamap}\.([a-zA-Z0-9_]+)\}}'
                def replacement(match):
                    return f"{{lookup{datamap_id}.{match.group(1)}}}"
                updated_url = re.sub(pattern, replacement, url_template)
                updated_body = re.sub(pattern, replacement, body_template)
                iterations_array[j]["url.template"] = updated_url
                iterations_array[j]["body.template"] = updated_body
            source_config["dataMapKeys"]["lookup%d" % datamap_id] = dataMapKeys.get(rest_datamap)
            del source_config["dataMapKeys"][rest_datamap]
            i += 1
        del src_payload["rest_data_maps"]
        return src_payload

    # create data map
    def create_data_map(self, datamap_payload):
        """
          To create a datamap
          :Params
              datamap_payload (string): payload of a datamap
          :Returns
              ID: return a created datamap id

          """
        datamap_name = input("Enter name for datamap : ")
        datamap_payload["name"] = datamap_name
        print_log_with_utc("Creating Datamap : %s"%datamap_name)
        datamap_obj = DataMap.create_datamap(self.auth,payload=datamap_payload)
        datamap_id = int(datamap_obj.get("id"))
        print_log_with_utc("Created datamap with ID %d" % datamap_id)
        return datamap_id

    # print all sinks for a source id
    def print_source_sink_pairs(self, src_id):
        """
          To print all sinks for a source id

          :Params
              datamap_payload (string): payload of a datamap
          :Returns
              ID: return a created datamap id

          """
        src_sink_list = []
        src_sink_list = DataPipeline.list_pipelines(self.auth,src_id=src_id)
        if len(src_sink_list) == 0:
            print_log_with_utc("No sink found")
        else:
            table = BeautifulTable(maxwidth=150)
            table.columns.header = ["src","sink"]
            for pair in src_sink_list:
                table.rows.append([str(pair["src"]["id"])+" ("+pair["src"]["name"]+")",str(pair["sink"]["id"])+" ("+pair["sink"]["name"]+")"])
            print_log_with_utc(table)

    # create template for exporting lookup
    def get_lookup_details(self, lookup_obj):
        """
          To template for a exporting lookup

          :Params
              lookup_obj (string): lookup information
          :Returns
              Lookup_Details: return a lookup details

          """
        print_log_with_utc("Fetching Lookup details")
        complete_lookup_details = lookup_obj.get("raw")
        if complete_lookup_details["data_sink_id"] is not None:
            print_log_with_utc("Sorry, the dynamic lookup cannot be exported")
            exit()
        lookup_details = OrderedDict()
        lookup_details["name"] = complete_lookup_details["name"]
        lookup_details["description"] = complete_lookup_details["description"]
        lookup_details["map_primary_key"] = complete_lookup_details.get("map_primary_key")
        lookup_details["data_defaults"] = complete_lookup_details.get("data_defaults")
        lookup_details["data_map"] = complete_lookup_details.get("data_map")
        lookup_details["data_type"] = complete_lookup_details.get("data_type")
        lookup_details["tags"] = complete_lookup_details.get("tags")
        accessors_details = DataMap.get_lookup_accessors(self.auth, l_id=complete_lookup_details.get("id"))
        if accessors_details:
            accessors = self.get_accessors_payload(accessors_details)
            if "access_role" in str(accessors):
                lookup_details["accessors"] = accessors
        lookup_details["meta_data"] = {}
        lookup_details["meta_data"]["env"] = self.get_enviroment()
        return lookup_details

    # Import a lookup information
    def import_lookup(self, import_file_path):
        """
          To importing a lookup information

          :Params
              lookup_obj (string): lookup information
          :Returns
              Lookup_Details: return a lookup details

          """
        import_data = self.validate_json_file(file_path=import_file_path)
        import_data_with_accessors = self.validate_json_file(file_path=import_file_path)
        self.is_current_env = self.check_env(import_data.get("meta_data"))
        print_log_with_utc("Creating the static lookup with name : %s" % import_data.get("name"))
        acc_payload = import_data_with_accessors.get("accessors")
        if import_data.get("meta_data"):
            del import_data["meta_data"]
        if import_data.get("accessors"):
            acc_payload = import_data.get("accessors")
            del import_data["accessors"]
        try:
            datamap_obj = DataMap.create_datamap(self.auth, payload=import_data)
            datamap_id = datamap_obj.get("id")
            print_log_with_utc("Static Lookup is created with ID : %s" % datamap_id)
        except:
            print_log_with_utc("Unable to create a new Static Lookup")
            print_log_with_utc("The payload is invalid please check the payload")
        if acc_payload:
            if self.is_current_env:
                accessors_payload = {"accessors": acc_payload}
                DataMap.create_lookup_accessors(self.auth, l_id=datamap_id, payload=accessors_payload)
            else:
                print_log_with_utc("Creation of accessors will not scope for outside the environment")

    # Export a lookup information
    def export_lookup(self, lookup_id, output_file="export_lookup.json"):
        """
          To exporting a lookup information

          :Params
              lookup_id (string): id of a lookup
              output_file (string): path name of exporting file
          :Returns
              None

          """
        lookup_obj = DataMap(self.auth, datamap_id=lookup_id)
        lookup_details = self.get_lookup_details(lookup_obj)
        with open(output_file, 'w') as outfile:
            json.dump(lookup_details, outfile, indent=4)
        print_log_with_utc("The config json is exported to ===> %s " % output_file)

    def get_reusable_transform_details(self, reusable_transform_obj):
        """
          To template for a exporting reusable_transform

          :Params
              reusable_transform_obj (string): reusable_transform information
          :Returns
              Lookup_Details: return a reusable_transform details

          """
        print_log_with_utc("Fetching reusable transform details")
        complete_reusable_transform_details = reusable_transform_obj.get("raw")
        reusable_transform_details = OrderedDict()
        reusable_transform_details["id"] = complete_reusable_transform_details["id"]
        reusable_transform_details["name"] = complete_reusable_transform_details["name"]
        reusable_transform_details["description"] = complete_reusable_transform_details["description"]
        reusable_transform_details["reusable"] = complete_reusable_transform_details.get("reusable")
        reusable_transform_details["code"] = complete_reusable_transform_details.get("code")
        reusable_transform_details["custom_config"] = complete_reusable_transform_details.get("custom_config")
        reusable_transform_details["code_type"] = complete_reusable_transform_details.get("code_type")
        reusable_transform_details["output_type"] = complete_reusable_transform_details.get("output_type")
        reusable_transform_details["code_encoding"] = complete_reusable_transform_details.get("code_encoding")
        reusable_transform_details["tags"] = complete_reusable_transform_details.get("tags")
        accessors_details = DataTransform.get_transforms_accessors(self.auth, trans_id=complete_reusable_transform_details.get("id"))
        if accessors_details:
            accessors = self.get_accessors_payload(accessors_details)
            if "access_role" in str(accessors):
                reusable_transform_details["accessors"] = accessors
        reusable_transform_details["meta_data"] = {}
        reusable_transform_details["meta_data"]["env"] = self.get_enviroment()
        return reusable_transform_details

    def import_reusable_transform(self, import_file_path):
        """
          To importing reusable transform information

          :Params
              reusable_transform_obj (string): reusable transform information
          :Returns
              Reusable_Transform_Details: return a reusable transform details

          """
        import_data = self.validate_json_file(file_path=import_file_path)
        import_data_with_accessors = self.validate_json_file(file_path=import_file_path)
        self.is_current_env = self.check_env(import_data.get("meta_data"))
        print_log_with_utc("Creating the reusable transform : %s" % import_data.get("name"))
        acc_payload = import_data_with_accessors.get("accessors")
        reusable_transform_id = None
        if import_data.get("id"):
            del import_data["id"]
        if import_data.get("meta_data"):
            del import_data["meta_data"]
        if import_data.get("accessors"):
            acc_payload = import_data.get("accessors")
            del import_data["accessors"]
        # Replace lookup and reusable transform ID's
        if import_data.get("code") and type(import_data.get("code")) == str:
            import_data["code"] =  ImportExport.scan_reusable_python_transform(self, import_data.get("code"))
        elif import_data.get("code") and type(import_data.get("code")) == list:
            import_data["code"][0]['spec']['script'] = ImportExport.scan_reusable_python_transform(self, import_data['code'][0]['spec']['script'])

        try:
            reusable_transform_obj = DataTransform.create_reusable_transform(self.auth, payload=import_data)
            reusable_transform_id = reusable_transform_obj.get("id")
            print_log_with_utc("Reusable Transform is created with ID : %s" % reusable_transform_id)
        except:
            print_log_with_utc("Unable to create a new reusable transform")
            print_log_with_utc("The payload is invalid please check the payload")
        if acc_payload:
            if self.is_current_env:
                accessors_payload = {"accessors": acc_payload}
                DataTransform.create_transforms_accessors(self.auth, trans_id=reusable_transform_id, payload=accessors_payload)
            else:
                print_log_with_utc("Creation of accessors will not scope for outside the environment")



    def export_reusable_transform(self, transform_id, output_file="export_transform.json"):
        """
          To exporting reusable transform information

          :Params
              transform_id (string): id of a reusable transform
              output_file (string): path name of exporting file
          :Returns
              None

          """
        reusable_transform_obj = DataTransform(self.auth, transform_id=transform_id)
        reusable_transform_details = self.get_reusable_transform_details(reusable_transform_obj)
        if reusable_transform_details["output_type"] == "record":
            del reusable_transform_details["custom_config"]
        with open(output_file, 'w') as outfile:
            json.dump(reusable_transform_details, outfile, indent=4)
        print_log_with_utc("The config json is exported to ===> %s " % output_file)


    # Replace lookup and reusable transform ID's
    def scan_reusable_python_transform(self, encoded_script):
        """
        To verify the encoded python transform code
        :Params
            encoded_script (string): encoded python script
        :Returns
            encoded_script: returns a encoded script depend upon the utf format
        """
        decoded_script = base64.b64decode(encoded_script)
        srtingified_script = decoded_script.decode("utf-8")
        if ("toMapValue" in srtingified_script or "getMap" in srtingified_script or "nexla_fn.call" and "custom" in srtingified_script):
            s = StringIO(srtingified_script)
            new_script = ""
            for line in s:
                if "toMapValue2" in line or "toMapValue" in line or 'getMap' in line:
                    try:
                        if "toMapValue2" in line or "toMapValue" in line:
                            data_map_ids = re.findall(r"(?:toMapValue|toMapValue2)[\"']\s*,\s*(\d+)", str(line))
                        elif "getMap" in line:
                            data_map_ids = re.findall(r"(?:getMap)[\"']\s*,\s*(\d+)", str(line))
                            if type(data_map_ids) != list:
                                data_map_ids = [data_map_ids]
                        for data_map in data_map_ids:
                            print_log_with_utc("Lookup Dectected : %s " % data_map)
                            datamap_list = DataMap.get_all(self.auth)
                            print("LookupID  --  Lookup Name")
                            map_list = []
                            for map in datamap_list:
                                print_log_with_utc("%s  --  %s" % (map.get("id"), map.get("name")))
                                map_list.append(map.get("id"))
                            datamap_id = input("Enter the lookup id you want to use : ")
                            retry = 1
                            while retry < 3:
                                try:
                                    datamap_id = int(datamap_id)
                                    if str(datamap_id) not in str(map_list):
                                        raise Exception
                                    break
                                except:
                                    print_log_with_utc("Invalid Option given instead of LookupID. Please try again.")
                                    print_log_with_utc("You can only pick from the available LookupIDs. Please try again.")
                                    datamap_id = input("Enter lookup_id you want to use: ")
                                    retry += 1
                                    continue
                            else:
                                print_log_with_utc("Invalid Option given instead of LookupID. Limit exceeded...!")
                                exit()
                            print_log_with_utc("Lookup ID Selected is : %s" % datamap_id)
                            line = line.replace(str(data_map), str(datamap_id))
                        for reusable_resource in self.comparision:
                            if reusable_resource in line:
                                line = line.replace(str(reusable_resource), str(self.comparision.get(reusable_resource)))
                        new_script += line

                    except Exception as e:
                        print(e)
                        print("Please check the datamap ID.")

                elif "nexla_fn.call" and "custom" in line:
                    if re.match(r'.*#.*check_for_pipeline_ids_range.*\,(?:| )\[[0-9]+.*', line) == None:  # Fix for ResourceNotFound error while export(avoid reusable_trasnsforms in commented line)
                        reusable_trans_ids = re.findall(r"'custom', \[(\d+),", line)
                        print_log_with_utc("Reusable Attribute transform detected")
                        for reusable_id in reusable_trans_ids :
                            print_log_with_utc(
                                "Select any one of the Reusable Attribute transform, Previous Transform ID was : %s" % (
                                   reusable_id))
                            reusable_transform_list = DataTransform.get_all(self.auth, reusable="true")
                            print_log_with_utc("TransformID  --  Transform Name")
                            reusable_trans_list = []
                            for rt in reusable_transform_list:
                                print_log_with_utc("%s  --  %s" % (rt.get("id"), rt.get("name")))
                                reusable_trans_list.append(rt.get("id"))
                            retry = 1
                            while retry < 3:
                                reusable_transform_id = input(
                                    "Enter the reusable_transform id you want to use : ")
                                try:
                                    reusable_transform_id = int(reusable_transform_id)
                                    break
                                except:
                                    print_log_with_utc("Please choose from the available Transform IDs. Try again.")
                                    retry += 1
                                    continue
                            print_log_with_utc("Reusable Transform Selected ID is : %s" % reusable_transform_id)
                            line = line.replace(str(reusable_id), str(reusable_transform_id))
                        for reusable_resource in self.comparision:
                            if reusable_resource in line:
                                line = line.replace(str(reusable_resource), str(self.comparision.get('reusable_resource')))
                        new_script += line
                else:
                    new_script += line
            byte_encoded = str.encode(new_script)
            return base64.b64encode(byte_encoded).decode("utf-8")
        else:
            return encoded_script

    def update_reusable_transform(self, update_file_path, target_transform_id=None):
        """
          To updating reusable transform information

          :Params
              reusable_transform_obj (string): reusable transform information
          :Returns
              Reusable_Transform_Details: return a reusable transform details

          """
        import_data = self.validate_json_file(file_path=update_file_path)
        import_data_with_accessors = self.validate_json_file(file_path=update_file_path)
        self.is_current_env = self.check_env(import_data.get("meta_data"))
        acc_payload = import_data_with_accessors.get("accessors")
        if target_transform_id:
            transform_id = int(target_transform_id)
            print_log_with_utc("Updating the reusable transform : %s" % transform_id)
        else:
            transform_id = import_data.get('id')
            if not transform_id or not str(transform_id).isdigit():
                print_log_with_utc("Error: ID must be numeric and not null or missing.")
                sys.exit(0)
            print_log_with_utc("Updating the reusable transform : %s" % transform_id)
        transform_id = self.check_id_present(id=transform_id, type="reusable_transform")
        try:
            reusable_transform_obj = DataTransform.update_reusable_transform(self.auth, payload=import_data, transform_id=transform_id)
            reusable_transform_id = reusable_transform_obj.get("id")
            print_log_with_utc("Reusable Transform is updated with ID : %s" % reusable_transform_id)
        except:
            print_log_with_utc("Unable to update a reusable transform")
            print_log_with_utc("The payload is invalid please check the payload")
        if acc_payload:
            if self.is_current_env:
                accessors_payload = {"accessors": acc_payload}
                DataTransform.create_transforms_accessors(self.auth, trans_id=reusable_transform_id, payload=accessors_payload)
            else:
                print_log_with_utc("Creation of accessors will not scope for outside the environment")

    # get the accessors payload
    def get_accessors_payload(self, sharers):
        """
            Get accessors details
            :Params
                sharers (string): sharers details
            :Returns
                ID: return accessors details

            """
        result = []
        try:
            for sharer in sharers:
                res = {}
                res["id"] = sharer.get("id")
                res["type"] = sharer.get("type")
                res["org_id"] = sharer.get("accessor_org_id")
                res["access_role"] = sharer.get("access_roles")[0]
                result.append(res)
            return result
        except:
            print("Error while updating accessors: id, type, accessor_org_id and access_roles should be present in the sharer details")
            sys.exit(0)

    # print all pipelines of a source id
    def print_pipeline_tree(self, src_id):
        """
            Print all pipelines using source id
            :Params
                src_id (string): id of a source
            :Returns
                None

            """
        pipeline_list = []
        pipeline_list=DataPipeline.list_pipelines(self.auth,src_id=src_id)
        if len(pipeline_list) == 0:
            print_log_with_utc("No datasets found for this source")
            exit()
        else:
            table = BeautifulTable(maxwidth=200)
            # Get the maximum number of datasets in any pipeline for given source
            max_dataset_count = 0
            for i in pipeline_list:
                curr_dset_count = len(i["data_sets"])
                if curr_dset_count > max_dataset_count:
                    max_dataset_count = curr_dset_count
                else:
                    continue
            column_headers = ["branch_id","flow_id", "source"]
            dataset_template = "dataset_"
            if max_dataset_count != 0:
                for i in range(max_dataset_count):
                    if i == 0:
                        column_headers.append("detected_dataset")
                    else:
                        column_headers.append(dataset_template+str(i))
            column_headers.append("destination")
            table.columns.header = column_headers
            for pipeline in pipeline_list:
                if "data_sets" in pipeline:
                    dataset_items = []
                    current_dataset_count = len(pipeline["data_sets"])
                    dataset_items.append(pipeline["branch_id"])
                    dataset_items.append(pipeline["src"]["flow_id"])
                    dataset_items.append(pipeline["src"]["id"])

                    for i in range(max_dataset_count):
                        if(i < current_dataset_count):
                            dset_extracted = str(pipeline["data_sets"][i]["id"]) + " (" + pipeline["data_sets"][i]["name"] + "," + pipeline["data_sets"][i]["status"] + ")"
                        else:
                            dset_extracted = ""
                        dataset_items.append(dset_extracted)
                    if("sink" in pipeline):
                        sink_extracted = str(pipeline["sink"]["id"])+" ("+pipeline["sink"]["name"]+")"
                    else:
                        sink_extracted = ""
                    dataset_items.append(sink_extracted)
                    table.rows.append(dataset_items)
            print(table)

    # Get all flow id's
    def get_all_flows_ids(self, src_id):
        """
            Get all flow id's
            :Params
                src_id (string): id of a source
            :Returns
                Flow_ID: return the list of flow id's

            """
        flow_list = DataPipeline.list_pipelines(self.auth, src_id=src_id)
        flows_id_list = []
        if len(flow_list) == 0:
            print_log_with_utc("No datasets found for this source")
            exit()
        print_log_with_utc("Getting all branch ids...")
        for flow in flow_list:
            if "data_sets" in flow:
                flows_id_list.append(flow["branch_id"])
        print_log_with_utc("Found %d branches, exporting them" %len(flows_id_list))
        return flows_id_list

    # Check the pipeline id's range
    def check_for_pipeline_ids_range(self, pipeline_ids):
        """
            To check the pipeline range of the id's
            :Params
                pipeline_ids (list): list of pipeline id's
            :Returns
                Pipeline_Id_Range: return pipeline id's has range

            """
        has_range = False
        pipeline_ids_range = ''
        if re.match(r"range\s[0-9]+,[0-9]+", pipeline_ids):
            id_range = re.match(r"range\s([0-9]+,[0-9]+)", pipeline_ids).group(1)
            ids = id_range.split(',')
            pipeline_ids_range = list(range(int(ids[0]), int(ids[1])+1))
            string_ids = ','.join(str(e) for e in pipeline_ids_range)
            print_log_with_utc("Exporting flows ID’s %s" %string_ids)
            has_range = True
        return pipeline_ids_range, has_range

    # to get the current environment for email source creation
    def get_enviroment(self):
        custom_env_config_path = os.getenv("NEXLA_CREDS_FILE")
        if (custom_env_config_path == None):
            env_config_path = "~/.nxla_creds.json"
        else:
            env_config_path = custom_env_config_path
        file_path = os.path.expanduser(env_config_path)
        config_file_exists = os.path.isfile(file_path)
        config_json = {}
        if (config_file_exists):
            with open(file_path, 'r') as fh:
                config_json = json.load(fh)
        return config_json["current_env"]

    # To check the current environment for creating the accessor with exported configuration environment
    def check_env(self, meta_data):
        if meta_data:
            exp_env = meta_data.get("env")
            curr_env = self.get_enviroment()
            if exp_env == curr_env:
                return True
        else:
            print_log_with_utc("Environment details are missing from the meta data. Please check the JSON file.")
            exit()

    # To Validate the JSON file
    def validate_json_file(self, file_path):
        """
        To Validate the JSON file

        :Params
            file_path: importing file path
        :Returns
            extract the information and will send the data
        """
        data = OrderedDict()
        try:
            with open(file_path) as json_file:
                data = json.load(json_file, object_pairs_hook=OrderedDict)
        except json.decoder.JSONDecodeError:
            print_log_with_utc("The file is invalid please check the json file")
            exit()
        except:
            print_log_with_utc("Invalid flow path or file name")
            exit()
        if data == {}:
            print_log_with_utc("The file is empty json please check the json file.")
            exit()
        return data

    def check_id_present(self, id, type):
        temp = False
        if type == "reusable_transform":
            result = DataTransform.get_all(self.auth, reusable="true")
        if len(result) and id:
            for dic in result:
                if int(id) == dic['id']:
                    id = int(id)
                    temp = True
        if not temp:
            print_log_with_utc("The ID %d is not present in the current environment" % id)
            sys.exit(2)
        return id