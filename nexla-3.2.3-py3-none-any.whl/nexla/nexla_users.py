import copy
import json
from nexla.log_config import log


class Org(object):

    @staticmethod
    def list_orgs(auth):
        """
        List all organizations.
        :Params
            auth (string): auth token
        :Returns
            list: list of all Org objects

        """
        log.info("Getting detils of all Orgs.")
        org_list=[]
        try:
            orgs=auth.call_url_return_json("/orgs", method="GET")
            for org in orgs:
                org_list.append(Org(auth, payload=org))
            return org_list
        except:
            raise Exception("Unable to fetch Organizations list")

    def __init__(self, auth, **kwargs):
        """
        Org initializer.
        :Params
            auth (string): auth token
            payload (string): request body having organization details
            id (int): organization id
        :Returns
            None

        """
        self.auth = auth
        self.attributes = {}
        if "id" in kwargs:
            self.id = kwargs["id"]
            resp = self.auth.call_url_return_json("/orgs/%s" % self.id, method="GET")
            self.init_from_payload(payload=resp)
        elif "payload" in kwargs:
            self.init_from_payload(payload=kwargs["payload"])
        else:
            raise Exception("Unsupported Initialization of Source Object")

    def init_from_payload(self, payload):
        """
        Org initializer using payload.
        :Params
            payload (string): request body having organization details
        :Returns
            None

        """
        self.raw = payload
        self.id = self.attributes["id"] = payload.get("id")
        self.name = self.attributes["name"] = payload.get("name")

    def get_raw(self):
        return self.raw

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def get_attributes_list(self):
        """
        Get list of attributes
        :Returns
            list: list of attributes

        """
        return self.attributes.keys()

    def get_members(self):
        """
        List of members of the organization
        :Returns
            list: list of members of the organization

        """
        log.info("Getting all members of Org : %s" % self.id)
        member_list = []
        try:
            resp=self.auth.call_url_return_json("/orgs/%s/members" % self.id, method="GET")
            for member in resp:
                member_list.append(member)
            return member_list
        except:
            raise Exception("Unable to fetch Org Members")

    def get_metrics(self, metrics):
        """
        Get metrics of a source/sink
        :Params
            metrics (string): resource type
        :Returns
            list: list of files and their metrics

        """
        metrics_list = []
        log.info("Getting %s metrics of Org : %s" % (metrics, self.id))
        try:
            resp=self.auth.call_url_return_json("/orgs/%s/metrics?resource_type=%s" % (self.id, metrics), method="GET")
            for met in resp["metrics"]:
                metrics_list.append(met)
            return metrics_list
        except:
            raise Exception("Unable to fetch Org Metrices")

    @staticmethod
    def Create(auth, orgname=None, owner_name=None, email=None, description=None, payload=None ):
        """
        Create organization
        :Params
            auth (string): auth token
            orgname (string): organization name
            owner_name (string): owner name
            email (string): email of the owner
            description (string): organization description
            payload (string): request body having organization details
        :Returns
            Org: returns org object

        """
        try:
            if (payload != ""):
                log.info("Calling Create Organization with payload: \n%s \n\n" %json.dumps(payload, indent=4).replace("'", "\\'"))
                resp = auth.call_url_return_json("/orgs", method="POST", payload=payload)
                return Org(auth, id=resp["id"])
            else:
                email_domain = email.split("@")
                create_org_payload = copy.deepcopy(create_org_template)
                create_org_payload["name"] = orgname
                create_org_payload["owner"]["full_name"] = owner_name
                create_org_payload["owner"]["email"] = email
                create_org_payload["description"] = description
                create_org_payload["email_domain"] = email_domain[1]
                log.info("Calling Create Organization with payload: \n%s \n\n" % json.dumps(create_org_payload, indent=4).replace("'", "\\'"))
                resp = auth.call_url_return_json("/orgs", method="POST", payload=create_org_payload)
                return Org(auth, id=resp["id"])
        except:
            raise Exception("Error Creating org")

    def update(self, orgname=None, owner_name=None,  email=None, owner_email=None, description=None, payload=None):
        """
        Update organization details
        :Params
            orgname (string): organization name
            owner_name (string): owner name
            email (string): email address
            owner_email (string): email of the owner
            description (string): organization description
            payload (string): request body having organization details
        :Returns
            None

        """
        try:
            if (payload != ""):
                log.info("Calling Update Organization with payload: \n%s \n\n" %json.dumps(payload, indent=4).replace("'", "\\'"))
                status_code = self.auth.call_url_return_status("/orgs/%s"%self.id, method="PUT", payload=payload)
            else:
                update_user_payload = {}
                if(owner_name != "" ):
                    update_user_payload["owner"] = {}
                    print("owner email is " + owner_email)
                    if (owner_email == ""):
                        raise Exception("owner_email is mandatory")

                if (orgname != ""):
                    update_user_payload["name"] = orgname
                if(owner_name != ""):
                    update_user_payload["owner"]["full_name"] = owner_name
                if (email != ""):
                    update_user_payload["email"] = email
                if (owner_email != ""):
                    update_user_payload["owner"]["email"] = owner_email
                if (description != ""):
                    update_user_payload["description"] = description

                log.info("Calling Update Organization with payload: \n%s \n\n" % json.dumps(update_user_payload, indent=4).replace("'", "\\'"))
                status_code = self.auth.call_url_return_status("/orgs/%s" % self.id, method="PUT", payload=update_user_payload)

            if (status_code >= 200 and status_code < 300):
                self.status = True
            else:
                raise Exception("Update Organization failed. Received response code = %s" % status_code)
        except:
            raise Exception("Update Org Failed")

class User(object):

    @staticmethod
    def get_all(auth):
        """
        Get all users of an organization.
        :Params
            auth (string): auth token
        :Returns
            list: list of all user objects

        """
        user_list = []
        try:
            resp=auth.call_url_return_json("/users?access_role=all", method="GET")
            for obj in resp:
                user_list.append(User(auth, payload=obj))
            return user_list
        except:
            raise Exception("Failed to list users")


    def __init__(self, auth, **kwargs):
        """
        User initializer.
        :Params
            auth (string): auth token
            payload (string): request body having user details
            id (int): user id
        :Returns
            None

        """
        self.auth = auth
        self.attributes = {}
        if "id" in kwargs:
            self.id = self.attributes["id"] = kwargs["id"]
            resp = self.auth.call_url_return_json("/users/%s" % self.id, method="GET")
            if(self.id != ""):
                self.init_from_payload(payload=resp)
            else:
                self.init_from_payload(payload=resp[0])
        elif "payload" in kwargs:
            self.init_from_payload(payload=kwargs["payload"])
        else:
            raise Exception("Unsupported Initialization of Source Object")

    def init_from_payload(self, payload):
        """
        User initializer using payload.
        :Params
            payload (string): request body having user details
        :Returns
            None

        """
        try:
            self.raw=payload
            self.id = self.attributes["id"] = payload.get("id")
            self.name = self.attributes["name"] = self.attributes["full_name"] = payload.get("full_name")
            self.attributes["super_user"] = payload.get("super_user")
            self.email = self.attributes["email"] = payload.get("email")
            if(payload.get("default_org") != None):
                self.org_id = self.attributes["org_id"] = payload.get("default_org").get("id")
        except:
            log.error("Error on Initializing object with %s" %json.dumps(payload, indent=4))
            raise Exception("Error on Initializing object")

    def get_raw(self):
        return self.raw

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def get_metrics(self, metrics):
        """
        Get metrics of a source/sink
        :Params
            metrics (string): resource type
        :Returns
            list: list of files and their metrics

        """
        metrics_list = []
        try:
            resp=self.auth.call_url_return_json("/users/%s/metrics?org_id=%s&resource_type=%s" % (self.id, self.org_id, metrics), method="GET")
            for met in resp["metrics"]:
                metrics_list.append(met)
            return metrics_list
        except:
            raise Exception("Get Metrics Failed !!")

    @staticmethod
    def Create(auth, username = None, email = None, email_domain = None, payload=None):
        """
        Create user
        :Params
            auth (string): auth token
            username (string): user name
            email (string): email of the owner
            email_domain (string): organization's email domain
            payload (string): request body having user details
        :Returns
            User: returns user object

        """
        try:
            if (payload != ""):
                log.info("Calling Create User with payload: \n%s \n\n" %json.dumps(payload, indent=4).replace("'", "\\'"))
                resp = auth.call_url_return_json("/users", method="POST", payload=payload)
                return User(auth, id=resp["id"])
            else:
                log.info("Creating user with parameters")
                create_user_payload = copy.deepcopy(create_user_template)
                create_user_payload["full_name"] = username
                create_user_payload["email"] = email
                create_user_payload["default_org_email_domain"] = email_domain

                log.info("Calling Create User with payload: \n%s \n\n" % json.dumps(create_user_payload, indent=4).replace("'", "\\'"))
                resp = auth.call_url_return_json("/users", method="POST", payload=create_user_payload)
                return User(auth, id=resp["id"])
        except:
            log.error("Error Creating User")
            raise Exception("Error Creating User")

    def changePassword(self, new_passwd):
        """
        Change a user's password
        :Params
            new_passwd (string): new password
        :Returns
            boolean: True if password has been changed, False otherwise

        """
        change_pswd_payload = copy.deepcopy(change_passwd_template)
        change_pswd_payload["password"] = new_passwd
        change_pswd_payload["password_confirmation"] = new_passwd
        try:
            log.info("Calling Change password with payload: \n%s \n\n" % json.dumps(change_pswd_payload, indent=4).replace("'", "\\'"))
            resp = self.auth.call_url_return_status("/users/%s/change_password" %self.id, method="PUT", payload=change_pswd_payload)
            if (int(resp) >= 200 and int(resp) < 300):
                return True
            else:
                return False
        except:
            raise Exception("Password change failed !!")

    def Update(self, name=None, payload=None):
        """
        Update user details
        :Params
            name (string): user's name
            payload (string): request body having user details
        :Returns
            boolean: True if user details have been updated, False otherwise

        """
        try:
            if (payload):
                log.info("Calling Update User with payload: \n%s \n\n" % json.dumps(payload, indent=4).replace("'", "\\'"))
                status_code = self.auth.call_url_return_status("/users/%s" % self.id, method="PUT", payload=payload)
            else:
                update_user_payload = {}
                update_user_payload["full_name"] = name
                log.info("Calling Update User with payload: \n%s \n\n" % json.dumps(update_user_payload, indent=4).replace("'", "\\'"))
                status_code = self.auth.call_url_return_status("/users/%s" % self.id, method="PUT", payload=update_user_payload)

            if (status_code >= 200 and status_code < 300):
                return True
            else:
                return False
        except:
            raise Exception("Update User Failed")


create_org_template={
    "name": "",
    "description": "",
    "owner": {
        "full_name": "",
        "email": "",
    },
    "email_domain": "",
    "members_default_access_role": "none",
}

update_org_template={
    "name": "",
    "description": "",
    "owner": {
        "full_name": "",
        "email": "",
    },
    "members_default_access_role": "none",
}

create_user_template={
    "email": "",
    "full_name": "",
    "default_org_email_domain": ""
}

change_passwd_template={
  "password": "",
  "password_confirmation": ""
}
