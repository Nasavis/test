from datetime import datetime

import requests
import json
import os
from collections import OrderedDict
from urllib.parse import urlparse
from nexla.nexla_exceptions import *
from nexla.log_config import log
import re

class Auth(object):

    def __init__(self, config_file=None, host='', api_base_url='', username=None, password=None, api_key=None, access_token=None, impersonate={}):
        """
        Auth initializer.
        :Params
            config_file (string): configuration file name
            host (string): nexla url (ex: https://test.nexla.com)
            username (string): username
            password (string): password
            api_base_url (string): admin-api url (ex: https://test.nexla.com/admin-api
            auth_token (string): API key
            impersonate (string): User email address whom we want to impersonate
        :Returns
            None

        """
        self.org_id = None
        self.user_id = None
        self.impersonate = impersonate
        self.api_base_url = api_base_url
        if not api_base_url and host:
            self.api_base_url = urljoin(host,"/nexla-api")

        if config_file:
            self._init_with_config_file(config_file,is_validate=True)
        elif username and password:
            if not self.api_base_url:
                raise Exception("host or api_base_url required")
            self._init_with_user_pass(username=username, password=password)
        elif api_key:
            if not self.api_base_url:
                raise Exception("host or api_base_url required")
            self._init_with_api_key(api_key)
        elif access_token:
            if not self.api_base_url:
                raise Exception("host or api_base_url required")
            self._init_with_access_token(access_token, is_validate=True)
        else:
            custom_env_config_path = os.getenv("NEXLA_CREDS_FILE")
            if (custom_env_config_path == None):
                env_config_path = "~/.nxla_creds.json"
            else:
                env_config_path = custom_env_config_path
            self._init_with_config_file(config_file=env_config_path, is_validate=True)

    def _init_with_config_file(self,config_file, is_validate=False):
        """
        Auth initializer with configuration file.
        :Params
            config_file (string): configuration file name
        :Returns
            None

        """
        self.api_base_url = ''
        self.access_token = ''
        self.call_headers = None
        file_location = os.path.expanduser(config_file)
        try:
            with open(file_location, 'r') as fh:
                config_json = json.load(fh)
            self.file_location = file_location
            self.access_token = config_json[config_json["current_env"]]["ACCESS_TOKEN"]
            self.api_base_url = config_json[config_json["current_env"]]["BASE_URL"]
            self.call_headers = {'Authorization': 'Bearer ' + self.access_token, 'User-Agent': 'Nexla-CLI 1.0',
                                 'Content-Type': 'application/json'}
        except IOError:
            raise ConfigError
        except KeyError:
            raise ConfigError
        if is_validate:
            if not self.validate_credentials():
                raise AuthError

    def _init_with_access_token(self, access_token, is_validate=False):
        """
        Auth initializer with configuration.
        :Params
            api_base_url (string): admin-api url (ex: https://test.nexla.com/admin-api
            auth_token (string): API key
            impersonate (string): User email address whom we want to impersonate
        :Returns
            None

        """
        self.access_token = access_token
        if is_validate:
            if not self.validate_credentials():
                raise AuthError

    def _init_with_api_key(self,api_key):
        """
        Auth initializer with token.
        :Params
            host (string): nexla url (ex: https://test.nexla.com)
            auth_token (string): API key
        :Returns
            None

        """
        self.auth_token = api_key
        if not self.validate_credentials(generate_token=True):
            raise AuthError

    def _init_with_user_pass(self,username,password):
        """
        Auth initializer with username and password.
        :Params
            host (string): nexla url (ex: https://test.nexla.com)
            username (string): username
            password (string): password
            auth_token (string): API key
        :Returns
            None

        """
        self.auth_token = "%s:%s:*"%(username,password)
        if not self.validate_credentials(generate_token=True):
            raise AuthError

    def impersonate_user(self,orgid,userid):
        """
        Impersonating a user.
        :Params
            org_id (int): id of the organization of the user to be impersonated
            user_id (int): id of the user to be impersonated
        :Returns
            None

        """
        self.impersonate = "{\"org_id\": \"%d\", \"user_id\": \"%d\"}"%(orgid, userid)
        if not self.validate_credentials():
            raise AuthError

    def validate_credentials(self,generate_token=False):
        """
        Validating credentials.
        :param generate_token: Flag to generate bearer token using /token API. Default is True
        :return:
        bool: The return value is True if credentials are valid, False otherwise.
        """
        token_url = urljoin(self.api_base_url,'/token')
        self.raw = None
        self.attributes = {}

        if generate_token:
            head = {'Authorization': 'Basic ' + self.auth_token}
            response = requests.post(token_url, headers=head)
            if (response.status_code != 200):
                raise AuthError
            token_obj = json.loads(response.text)
            access_token = token_obj['access_token']
            print("\nYou are now logged into Nexla CLI as %s [%s]" %(token_obj["user"]["full_name"], token_obj["user"]["email"]))
            self.access_token = token_obj
            if (access_token[:2] != "ey"):
                log.error("Error: Invalid Bearer token")
                raise AuthError
            self.raw = token_obj
            return token_obj
        else:
            access_token = self.access_token
            if (access_token[:2] != "ey"):
                log.error("Error: Invalid Bearer token")
                raise AuthError
            url = self.api_base_url+'users'
            new_head = {'Authorization': 'Bearer ' + access_token, 'User-Agent': 'Nexla-CLI 1.0', 'Content-Type': 'application/json'}
            response = requests.get(url, headers=new_head)
            if (response.status_code != 200):
                with open(self.file_location, 'r') as fh:
                    config_json = json.load(fh)
                    if config_json[config_json["current_env"]].get("API_KEY"):
                        self.api_key = config_json[config_json["current_env"]]["API_KEY"]
                        self.auth_token =  self.api_key
                        token_obj = self.validate_credentials(generate_token=True)
                        generated_token = token_obj["access_token"]
                        access_token = generated_token
                        token_creation_time = datetime.now()
                        expires_in = token_obj['expires_in']
                        config_json[config_json["current_env"]]["ACCESS_TOKEN"] = generated_token
                        self.api_key = config_json[config_json["current_env"]]["API_KEY"]
                        minutes, seconds = divmod(expires_in, 60)
                        hours, minutes = divmod(minutes, 60)
                        user_name = token_obj['user']['full_name']
                        config_json[config_json["current_env"]]["API_Configured_Time"] = str(token_creation_time)
                        config_json[config_json["current_env"]]["TOKEN_EXPIRES_IN"] = hours
                        config_json[config_json["current_env"]]["USER"] = user_name
                        with open(self.file_location, "w") as fh:
                            fh.write(json.dumps(config_json))
                            print("\nThe token has been regenerated by the API key provided\n")
            else:
                try:
                    user = response.json()[0]
                    self.user_id = user.get('id')
                    self.org_id = user.get('default_org').get('id')
                    print("\nYou are now logged into Nexla CLI as %s [%s]" %(user.get("full_name"), user.get("email")))
                except:
                    pass
        if self.impersonate:
            new_head = {'Authorization': 'Bearer ' + access_token, 'Content-Type': 'application/json',
                        'User-Agent': 'Nexla-CLI 1.0'}
            response = requests.post(token_url, headers=new_head, data=self.impersonate)
            if (response.status_code != 200):
                raise AuthError
            token_obj = json.loads(response.text)
            access_token = token_obj['access_token']
            if (access_token[:2] != "ey"):
                log.error("Error getting an impersonated Bearer token")
                raise AuthError
            self.raw = token_obj

        if self.raw:
            try:
                self.attributes["org_id"]=self.raw["org"]["id"]
                self.attributes["user_id"] = self.raw["user"]["id"]
            except:
                self.attributes["org_id"] = None
                self.attributes["user_id"] = None
        self.call_headers = {'Authorization': 'Bearer ' + access_token, 'User-Agent': 'Nexla-CLI 1.0', 'Content-Type': 'application/json'}
        return True

    def call_url_return_json(self, url, method="GET", payload=None, isAdminApi=True, resource='', id=''):
        """
        call url and return response as json.
        :Params
            url (string): url
            method (string): API method (ex. GET)
            payload (string): request body for POST/PUT methods
            isAdminAPI (bool): true or false
        :Returns
            Dict: json response of API

        """
        if not isAdminApi:
            self.api_base_url = self.api_base_url.replace("/admin-api","")
        url = urljoin(self.api_base_url,url)
        log.info("Calling URL: %s, Method: %s, payload: %s"%(url, method, json.dumps(payload)))
        if (method == "GET"):
            response = requests.get(url, headers=self.call_headers)
        elif (method == "POST"):
            response = requests.post(url, headers=self.call_headers, data=json.dumps(payload).replace("'", "\\'"))
        elif (method == "DELETE"):
            response = requests.delete(url, headers=self.call_headers)
        elif (method == "PUT"):
            response = requests.put(url, headers=self.call_headers, data=json.dumps(payload).replace("'", "\\'"))
        if len(response.text) == 0 and response.status_code == 200:
            return {}
        elif response.status_code != 200:
            log.error("Error calling %s with payload: %s" % (url, payload))
            log.error("Response: %s, Response headers: %s, Response text: %s" %(response, response.headers, response.text))
            # Fix for ResourceNotFound error while export(reusable_transforms not found)
            if (resource):
                print("Error while calling api of %s with id %s" % (resource, id))
            if response.status_code == 401:
                raise AuthError
            elif response.status_code == 404:
                raise ResourceNotFound
            elif response.status_code == 403:
                raise PermissionDenied
            elif response.status_code == 500:
                raise InternalServerError
            elif response.status_code == 502:
                raise BadGateway
            elif response.status_code == 504:
                raise TimeoutError
        elif 'text/html' in response.headers.get('content-type', '').lower():
            print("The configured API URL seems to be wrong (%s). Please, reconfigure the API URL" % self.api_base_url)
            exit()

        json_response = json.loads(response.text, object_pairs_hook=OrderedDict)
        return json_response

    def call_url_return_status(self,url,method="GET",payload=None):
        """
        call url and return status code of response.
        :Params
            url (string): url
            method (string): API method (ex. GET)
            payload (string): request body for POST/PUT methods
        :Returns
            int: status code of response of API

        """
        url = urljoin(self.api_base_url, url)
        if (method == "GET"):
            response = requests.get(url,headers=self.call_headers)
        elif (method == "POST"):
            response = requests.post(url,headers=self.call_headers,data=json.dumps(payload))
        elif (method == "DELETE"):
            response = requests.delete(url,headers=self.call_headers)
        elif (method == "PUT"):
            response = requests.put(url,headers=self.call_headers,data=json.dumps(payload))

        return response.status_code

    def call_url_return_json_if_api_has_text(self, url, method="GET", payload=None):
        """
        call url and return response as json if api has text.
        :Params
            url (string): url
            method (string): API method (ex. GET)
            payload (string): request body for POST/PUT methods
        :Returns
            Dict: json response of API

        """
        url = urljoin(self.api_base_url, url)
        if (method == "GET"):
            response = requests.get(url, headers=self.call_headers)
        elif (method == "POST"):
            response = requests.post(url, headers=self.call_headers, data=json.dumps(payload).replace("'", "\\'"))
        elif (method == "DELETE"):
            response = requests.delete(url, headers=self.call_headers)
        elif (method == "PUT"):
            response = requests.put(url, headers=self.call_headers, data=json.dumps(payload).replace("'", "\\'"))
        if len(response.text) == 0 and response.status_code == 200:
            return {}
        elif response.status_code != 200:
            log.error("Error calling %s with payload: %s" % (url, payload))
            log.error("Response: %s, Response headers: %s, Reponse text: %s" %(response, response.headers, response.text))
            if response.status_code == 401:
                raise AuthError
            elif response.status_code == 404:
                raise ResourceNotFound
            elif response.status_code == 403:
                raise PermissionDenied
            elif response.status_code == 500:
                raise InternalServerError

        try:
            json_response = json.loads(response.text)
        except:
                print("The call to URL: %s , Method: %s failed with Response: %s" % (url, method, str(response)))
                return None
        return json_response

    def get_curl(self):
        """
        Get curl response of base url.
        :Params
            no parameters
        :Returns
            Dict: json response of API

        """
        return ("curl -sS -X GET -H \"Authorization: "+self.call_headers['Authorization']+"\" "+self.api_base_url)

    def get(self, attr):
        """
        get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string: value of the attribute

        """
        return self.attributes.get(attr)

    def get_host_name(self):
        """
        get host name
        :Params
            no parameters
        :Returns
            string: nexla url (ex: https://test.nexla.com)

        """
        return urlparse(self.api_base_url).hostname

    def get_env(self):
        """
        get environment
        :Returns
            string: environment name

        """
        env=None
        api_base_url = self.api_base_url
        if "dataops" in api_base_url:
            env = 'prod'
        elif "stage" in api_base_url:
            env = 'demo'
        elif "beta" in api_base_url:
            env = 'beta'
        elif "sb" in api_base_url:
            env = 'beta'
        elif "test" in api_base_url:
            env = 'local'
        if env:
            return env
        else:
            raise Exception("No Valid Auth environment detected")

def urljoin(base, url):
    return re.sub("/$","",base)+"/"+re.sub("^/","",url)

