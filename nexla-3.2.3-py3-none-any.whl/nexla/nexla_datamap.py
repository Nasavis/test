import json
from nexla.log_config import log
from nexla.nexla_exceptions import InternalServerError

class DataMap(object):

    @staticmethod
    def get_all(auth, access_role='collaborator', datamap_type=None):
        """
        Get all datamaps.
        :Params
            auth (string): auth token
            access_role (string): access role of the user
        :Returns
            list: list of all datamap objects

        """

        datamap_obj_list = []
        resp = auth.call_url_return_json("data_maps?access_role=%s" % access_role)
        for map in resp:
            map_obj = DataMap(auth, payload=map)
            if (datamap_type != None):
                if (map_obj.get("map_type") == datamap_type):
                    datamap_obj_list.append(map_obj)
            else:
                datamap_obj_list.append(map_obj)
        return datamap_obj_list

    def __init__(self, auth, **kwargs):
        """
        Datamap initializer.
        :Params
            auth (string): auth token
            payload (string): request body having datamap details
            datamap_id (int): datamap id
        :Returns
            None

        """
        self.auth = auth
        if "payload" in kwargs:
            self._init_from_payload(payload=kwargs["payload"])
        elif "datamap_id" in kwargs:
            self._init_from_id(auth,datamap_id=kwargs["datamap_id"])
        else:
            raise Exception("Unsupported Initialization of Source Object")

    def _init_from_id(self, auth_obj, datamap_id ):
        """
        Datamap initializer using id.
        :Params
            auth_obj (string): auth token
            datamap_id (int): datamap id
        :Returns
            None

        """
        resp = auth_obj.call_url_return_json("data_maps/%d?expand=1"%int(datamap_id))
        self._init_from_payload(payload=resp)

    def _init_from_payload(self,payload=None):
        """
        Datamap initializer using payload.
        :Params
            payload (string): request body having datamap details
        :Returns
            None

        """
        if payload == None:
            raise Exception("Missing payload to initialize Source")
        try:
            self.attributes={}
            self.attributes["raw"]=payload
            self.attributes["id"] = payload.get("id", "")
            self.attributes["name"] = payload.get("name","")
            self.attributes["description"] = payload.get("description","")
            self.attributes["created_at"] = payload.get("created_at","").replace('.000Z', '')
            self.attributes["updated_at"] = payload.get("updated_at", "").replace('.000Z', '')
            self.attributes["map_primary_key"] = payload.get("map_primary_key","")
            self.attributes["data_defaults"] = payload.get("data_defaults",{})
            self.attributes["data_map"] = payload.get("data_map",[])
            self.attributes["data_type"] = payload.get("data_type","")

            sink_id = payload.get("data_sink_id", None)
            if sink_id:
                self.attributes["map_type"] = "Dynamic"
                self.attributes["sink_id"] = sink_id
            else:
                self.attributes["map_type"] = "Static"

        except:
            log.exception("Exception Initializing the DataMap using payload:\n%s"%json.dumps(payload, indent=4))
            raise Exception("Exception Initializing the DataMap")

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr)

    def __str__(self):
        return("ID: %d, Name: %s" % ( self.attributes.get("id",""), self.attributes.get("name","")))

    @staticmethod
    def create_datamap(auth,payload=None):
        """
        Create datamap using payload
        :Params
            auth (string): auth token
            payload (string): request body having datamap details
        :Returns
            DataMap: returns datamap object

        """
        if not payload:
            return
            #to be completed
        resp = auth.call_url_return_json("/data_maps?expand=1", method="POST", payload=payload)
        datamap_obj = DataMap(auth,datamap_id=resp["id"])
        return datamap_obj

    @staticmethod
    def get_lookup_accessors(auth, l_id):
        """
        Get lookup accessors details.
        :Params
            auth (string): auth token
            l_id (string): lookup id
        :Returns
            Accessors: returns lookup accessors details
        """
        try:
            accessors_config = auth.call_url_return_json("data_maps/%s/accessors" % l_id, method="GET")
            return accessors_config
        except:
            print("Unable to get the accessors details")

    @staticmethod
    def create_lookup_accessors(auth, l_id, payload):
        """
        Create lookup accessors using payload
        :Params
            auth (string): auth token
            l_id (string): lookup id
            payload (string): request body having lookup accessors details
        :Returns
            Accessors: returns lookup accessors object
        """
        try:
            accessors_config = auth.call_url_return_json("data_maps/%s/accessors" % l_id, method="POST", payload=payload)
            return accessors_config
        except:
            print("*** Creation of accessors will not scope for outside the environment ***")
            return False

    def get_export(self):
        """
        Get templatized datamap details.
        :Returns
            Dict: returns templatized datamap details

        """
        resp = self.attributes
        map_template = {}
        map_template["name"] = resp["name"]
        map_template["description"] = resp["description"]
        map_template["map_primary_key"] = resp["map_primary_key"]
        map_template["data_defaults"] = resp["data_defaults"]
        map_template["data_map"] = resp["data_map"]
        map_template["data_type"] = resp["data_type"]
        return map_template
