'''
from datadog import initialize, api
import datetime
import re
import time
from beautifultable import BeautifulTable
import json
import requests
import tenacity

options = {
    'api_key': '<api_key>',
    'app_key': '<app_key>'
}
initialize(**options)


class DogMetrics:

    def __init__(self, res_id, env):
        """
        DogMetrics initializer.
        :Params
            res_id (int): resource id
            env (string): environment name
        :Returns
            None

        """

        self.environment = env
        self.resource_id = res_id

    @tenacity.retry(wait=tenacity.wait_exponential(multiplier=1, max=10), stop=tenacity.stop_after_delay(60))
    def api_metric_query_retry_on_fail(self, start, end, query):
        """
        Retry querying metrics on failure
        :Params
            start (int): start time as epoch
            end (string): end time as epoch
            query (string): query string
        :Returns
            string: query response

        """
        resp = api.Metric.query(start=start, end=end, query=query)
        return resp

    def api_metric_query(self, start, end, query):
        """
        Query metrics
        :Params
            start (int): start time as epoch
            end (string): end time as epoch
            query (string): query string
        :Returns
            string: query response

        """
        resp = self.api_metric_query_retry_on_fail(start=start, end=end, query=query)
        if "errors" in resp:
            raise Exception(resp["errors"])
        return resp

    def get_read_records(self, duration=24 * 3600, start=None, end=None):
        """
        Get read record count
        :Params
            duration (int): time interval(in seconds) for which the read records will be counted
            start (int): start time as epoch
            end (string): end time as epoch
        :Returns
            int: read record count

        """
        now = int(time.time())
        query = 'sum:nexla.sources.read_records{environment:' + self.environment + ',resource_id:' + str(
            self.resource_id) + '}.as_count()'
        if not start or not end:
            start = now - duration
            end = now
        resp = self.api_metric_query(start=start, end=end, query=query)
        total = 0
        if 'series' not in resp:
            print("Weird error.....")
            print(("Env = %s, Resource = %s" % (self.environment, self.resource_id)))
            print(resp)
        if 'series' in resp and len(resp['series']) > 0:
            for point in resp['series'][0]['pointlist']:
                total += point[1]
        return int(total)

    def get_write_records(self, duration=24 * 3600, start=None, end=None):
        """
        Get write record count
        :Params
            duration (int): time interval(in seconds) for which the write records will be counted
            start (int): start time as epoch
            end (string): end time as epoch
        :Returns
            int: write record count

        """
        now = int(time.time())
        query = 'sum:nexla.sinks.write_records{environment:' + self.environment + ',resource_id:' + str(
            self.resource_id) + '}.as_count()'
        if not start or not end:
            start = now - duration
            end = now
        resp = self.api_metric_query(start=start, end=end, query=query)
        total = 0
        if 'series' not in resp:
            print("Wierd error.....")
            print(("Env = %s, Resource = %s" % (self.environment, self.resource_id)))
            print(resp)
        if 'series' in resp and len(resp['series']) > 0:
            for point in resp['series'][0]['pointlist']:
                total += point[1]
        return int(total)

    def get_write_error_count(self, duration=24 * 3600, start=None, end=None):
        """
        Get write error count
        :Params
            duration (int): time interval(in seconds) for which the write error records will be counted
            start (int): start time as epoch
            end (string): end time as epoch
        :Returns
            int: error record count

        """
        now = int(time.time())
        query = 'sum:nexla.sinks.error_counts{environment:' + self.environment + ',resource_id:' + str(
            self.resource_id) + '}.as_count()'
        if not start or not end:
            start = now - duration
            end = now
        resp = self.api_metric_query(start=start, end=end, query=query)
        # print json.dumps(resp, indent=4)
        total = 0
        if 'series' not in resp:
            print("Wierd error.....")
            print(("Env = %s, Resource = %s" % (self.environment, self.resource_id)))
            print(resp)
        if 'series' in resp and len(resp['series']) > 0:
            for point in resp['series'][0]['pointlist']:
                total += point[1]
        return total

    def get_read_error_count(self, duration=24 * 3600, start=None, end=None):
        """
        Get read error count
        :Params
            duration (int): time interval(in seconds) for which the read error records will be counted
            start (int): start time as epoch
            end (string): end time as epoch
        :Returns
            int: error record count

        """
        now = int(time.time())
        query = 'sum:nexla.sources.error_counts{environment:' + self.environment + ',resource_id:' + str(
            self.resource_id) + '}.as_count()'
        if not start or not end:
            start = now - duration
            end = now
        resp = self.api_metric_query(start=start, end=end, query=query)
        # print json.dumps(resp, indent=4)
        total = 0
        if 'series' not in resp:
            print("Wierd error.....")
            print(("Env = %s, Resource = %s" % (self.environment, self.resource_id)))
            print(resp)
        if 'series' in resp and len(resp['series']) > 0:
            for point in resp['series'][0]['pointlist']:
                total += point[1]
        return total


class DogScreenBoard:
    @staticmethod
    def getList():
        """
        Get all screenboards' details
        :Returns
            table: list of all screenboards' details

        """
        resp_scr = api.Screenboard.get_all()
        table = BeautifulTable(max_width=100)
        table.column_headers = ['id', 'type', 'name', 'last_modified']
        for dash in resp_scr['screenboards']:
            table.append_row([dash['id'], 'Screen Board', dash['title'], dash['modified']])
        table.sort('last_modified', False)
        return table

    @staticmethod
    def getBoardByName(name):
        """
        Get screenboard's details using name
        :Params
            name (string): name of the screenboard
        :Returns
            int: id of the screenboard

        """
        resp_scr = api.Screenboard.get_all()
        for dash in resp_scr['screenboards']:
            if dash['title'] == name:
                return DogScreenBoard(dash['id'])
        return None

    @staticmethod
    def make_request(url_suffix, method='POST'):
        url = 'https://api.datadoghq.com/api/v1/' + url_suffix + '?api_key=<api_key>&application_key=<app_key>'
        print(url)
        response = requests.post(url)
        print(url)
        print((response.text))
        if response.status_code == 200:
            return json.loads(response.text)
        else:
            return None

    @staticmethod
    def create_from_payload(payload):
        """
        Create a screenboard
        :Params
            payload (string): details of the screenboard
        :Returns
            int: id of the screenboard

        """
        board_title = payload['board_title']
        description = payload.get('description')
        width = payload.get('width')
        widgets = payload['widgets']
        template_variables = payload.get('template_variables')
        resp = api.Screenboard.create(board_title=board_title,
                                      description=description,
                                      widgets=widgets,
                                      template_variables=template_variables,
                                      width=width)
        return DogScreenBoard(resp["id"])

    def __init__(self, id):
        """
        Screenboard initializer.
        :Params
            id (int): screenboard id
        :Returns
            None

        """
        self.id = id
        try:
            resp = api.Screenboard.get(id)
            self.raw = resp
            self.title = resp.get('board_title')
            self.description = resp.get('description')
            self.width = resp.get('width')
            self.widgets = resp['widgets']
            self.template_variables = resp['template_variables']
        except:
            print((json.dumps(resp)))
            raise Exception("Error getting screenboard definition")

    def get_create(self):
        return self.raw

    def update_from_payload(self, payload):
        """
        Update a screenboard using payload
        :Params
            payload (string): details of the screenboard
        :Returns
            None

        """
        board_id = self.id
        board_title = self.title
        description = self.description
        width = payload['width']
        widgets = payload['widgets']
        template_variables = payload['template_variables']
        resp = api.Screenboard.update(board_id,
                                      board_title=board_title,
                                      description=description,
                                      widgets=widgets,
                                      template_variables=template_variables,
                                      width=width)
        if "id" not in resp:
            print(resp)
            raise Exception("Error updating Dashboard")

    def get_share(self):
        """
        Get share url of a screenboard
        :Returns
            string: share url of the screenboard

        """
        # resp = api.Screenboard.share(self.id)
        resp = DogScreenBoard.make_request('screen/share/%d' % self.id, method='POST')
        if "public_url" in resp:
            return resp["public_url"]
        else:
            print((json.dumps(resp)))
            raise Exception("Unable to get a share URL")


class DogTimeBoard:
    @staticmethod
    def getList():
        """
        Get all timeboards' details
        :Returns
            table: list of all timeboards' details

        """
        resp_time = api.Timeboard.get_all()
        table = BeautifulTable(max_width=100)
        table.column_headers = ['id', 'type', 'name', 'last_modified']
        for dash in resp_time['dashes']:
            table.append_row([dash['id'], 'Time Board', dash['title'], dash['modified']])
        table.sort('last_modified', False)
        return table

    def __init__(self, res_id, env):
        """
        Timeboard initializer.
        :Params
            res_id (int): timeboard id
            env (string): environment name
        :Returns
            None

        """
        self.environment = env
        self.resource_id = res_id


class DogEventStream:

    @staticmethod
    @tenacity.retry(wait=tenacity.wait_exponential(multiplier=1, max=10), stop=tenacity.stop_after_delay(60))
    def api_event_query(start, end, priority, tags):
        """
        Query the event stream.
        :Params
            start (int): start time as epoch
            end (int): end time as epoch
            priority (string): priority of the event (low or normal)
            tags (string): comma separated string of tags
        :Returns
            None

        """
        response = api.Event.query(start=start, end=end, priority=priority, tags=tags)
        return response

    @staticmethod
    def get_source_event_stream(resource_id, env, goback_secs=None, status=None, max_time=4 * 60 * 60, start=None,
                                end=None):
        """
        Get source event stream.
        :Params
            resource_id (int): resource id
            env (string): environment name
            goback_secs (int): number of seconds from current timestamp
            status (string): status of the resource
            max_time (int): max time between events
            start (int): start time as epoch
            end (int): end time as epoch
        :Returns
            string: source event stream

        """
        now = int(time.time())
        resource_type = 'source'
        tarray = ["resource_id:" + str(resource_id), "resource_type:" + resource_type, "environment:" + env]
        if status:
            tarray.append("status:" + status)

        if not start or not end:
            start = now - goback_secs
            end = now
        response = DogEventStream.api_event_query(start=start, end=end, priority="normal", tags=tarray)
        return DogEventStream(response, max_time)

    @staticmethod
    def get_sink_event_stream(resource_id, env, goback_secs=None, status=None, max_time=4 * 60 * 60, start=None,
                              end=None):
        """
        Get sink event stream.
        :Params
            resource_id (int): resource id
            env (string): environment name
            goback_secs (int): number of seconds from current timestamp
            status (string): status of the resource
            max_time (int): max time between events
            start (int): start time as epoch
            end (int): end time as epoch
        :Returns
            string: sink event stream

        """
        now = int(time.time())
        resource_type = 'sink'
        tarray = ["resource_id:" + str(resource_id), "resource_type:" + resource_type, "environment:" + env]
        if status:
            tarray.append("status:" + status)
        if not start or not end:
            start = now - goback_secs
            end = now
        response = DogEventStream.api_event_query(start=start, end=end, priority="normal", tags=tarray)
        return DogEventStream(response, max_time)

    @tenacity.retry(wait=tenacity.wait_exponential(multiplier=1, max=10), stop=tenacity.stop_after_delay(60))
    def api_metric_query(self, start, end, query):
        """
        Query metrics
        :Params
            start (int): start time as epoch
            end (string): end time as epoch
            query (string): query string
        :Returns
            string: query response

        """
        resp = api.Metric.query(start=start, end=end, query=query)
        return resp

    def __init__(self, dog_response, max_time=4 * 60 * 60):
        """
        DogEventStream initializer.
        :Params
            dog_response (string): list of datadog events
            max_time (int): max time between events
        :Returns
            None

        """
        self.event_streams = []
        self.stream_count = 0

        MAX_TIME_BETWEEN_EVENTS = max_time
        oldest_seen_time = 0
        stream = []
        for event in dog_response["events"]:
            if oldest_seen_time > 0:
                diff = (oldest_seen_time - int(event["date_happened"]))
                if diff > MAX_TIME_BETWEEN_EVENTS:
                    self.event_streams.append(stream)
                    self.stream_count += 1
                    stream = []
            oldest_seen_time = int(event["date_happened"])
            stream.append(event)
        self.event_streams.append(stream)
        self.stream_count += 1

    def get_stream_count(self):
        """
        Get stream count.
        :Returns
            int: stream count

        """
        return self.stream_count

    def get_event_count(self):
        """
        Get event count.
        :Returns
            int: event count

        """
        return len(self.event_streams[0])

    def print_events(self, stream_num=0):
        """
        Display events
        :Params
            stream_num (int): stream index
        :Returns
            None

        """
        if stream_num == -1:
            for snum in range(len(self.event_streams)):
                for event in self.event_streams[snum]:
                    print(("[%s] \t %s" % (datetime.datetime.utcfromtimestamp(event["date_happened"]), event["text"])))
        else:
            for event in self.event_streams[stream_num]:
                print(("[%s] \t %s" % (datetime.datetime.utcfromtimestamp(event["date_happened"]), event["text"])))

    def get_event_timeline(self):
        """
        Get event timeline
        :Returns
            list: event timeline

        """
        out = []
        for stream in self.event_streams:
            for event in stream:
                metrics = self._get_metrics_from_event(event)
                out.append(metrics)
        return out

    def _get_metrics_from_event(self, event):
        """
        Get metrics of an event
        :Params
            event (string): event
        :Returns
            string: metrics of the event

        """
        byts = 0
        recs = 0
        errors = 0
        title_search = re.search('bytes=([0-9]*) and records=([0-9]*)', event["text"], re.IGNORECASE)
        if title_search:
            byts += int(title_search.group(1))
            if int(title_search.group(1)) == 0:
                recs += 0
            else:
                recs += int(title_search.group(2))
        # for failed source reads
        title_search = re.search('size=([0-9]*) bytes, records=([0-9]*) and Error Counts=([0-9]*)', event["text"],
                                 re.IGNORECASE)
        if title_search:
            byts += int(title_search.group(1))
            recs += int(title_search.group(2))
            errors += int(title_search.group(3))
        return {"time": str(datetime.datetime.utcfromtimestamp(event["date_happened"])), "bytes": byts, "records": recs,
                "errors": errors}

    def print_event_summary(self, stream_num=0):
        """
        Display event summary
        :Params
            stream_num (int): stream index
        :Returns
            None

        """
        now = int(time.time())
        stats = self.get_stats()
        event_count = stats["events"]
        byts = stats["bytes"]
        recs = stats["records"]
        errors = stats["failed_records"]
        last_seen_time = stats["latest_epoch"]
        oldest_seen_time = stats["oldest_epoch"]
        elapsed_seconds = stats["runtime_secs"]
        print(("\n\nSummary:\nTotal Events = %d" % event_count))
        print(("Total Bytes = %d" % byts))
        print(("Total Successful Recods = %d" % recs))
        print(("Total Failed Recods = %d" % errors))

        ago = (now - last_seen_time) / 60
        if ago > 120:
            ago = ago * 1.0 / 60.0
            print(("Most recent event seen at %s. (%d Hrs ago)" % (
                datetime.datetime.utcfromtimestamp(last_seen_time), ago)))
        else:
            print(("Most recent event seen at %s. (%d Mins ago)" % (
                datetime.datetime.utcfromtimestamp(last_seen_time), ago)))

        ago = (now - oldest_seen_time) / 60
        if ago > 120:
            ago = ago * 1.0 / 60.0
            print(("Oldest event seen at %s. (%d Hrs ago)" % (
                datetime.datetime.utcfromtimestamp(oldest_seen_time), ago)))
        else:
            print(("Oldest event seen at %s. (%d Mins ago)" % (
                datetime.datetime.utcfromtimestamp(oldest_seen_time), ago)))
        print(("Runtime = %.2f minutes" % (elapsed_seconds * 1.0 / 60)))
        if ("throughput" in stats):
            print(("Throughput = %d records/minute" % stats["throughput"]))

    def get_stats(self, stream_num=0):
        """
        Get event statistics
        :Params
            stream_num (int): stream index
        :Returns
            dict: statistics of the event

        """
        byts = 0
        recs = 0
        errors = 0
        last_seen_time = 0
        oldest_seen_time = 0
        event_count = len(self.event_streams[stream_num])
        isFirst = True
        for event in self.event_streams[stream_num]:
            if isFirst:
                last_seen_time = int(event["date_happened"])
                isFirst = False
            oldest_seen_time = int(event["date_happened"])
            title_search = re.search('bytes=([0-9]*) and records=([0-9]*)', event["text"], re.IGNORECASE)
            if title_search:
                byts += int(title_search.group(1))
                recs += int(title_search.group(2))
            # for failed source reads
            title_search = re.search('size=([null0-9]*) bytes, records=([0-9]*) and Error Counts=([0-9]*)',
                                     event["text"],
                                     re.IGNORECASE)
            if title_search:
                try:
                    byts += int(title_search.group(1))
                except:
                    byts += 0
                recs += int(title_search.group(2))
                errors += int(title_search.group(3))

        elapsed_seconds = (last_seen_time - oldest_seen_time)
        stats = {}
        stats["events"] = event_count
        stats["bytes"] = byts
        stats["records"] = recs
        stats["failed_records"] = errors
        stats["latest_datetime"] = str(datetime.datetime.utcfromtimestamp(last_seen_time))
        stats["latest_epoch"] = last_seen_time
        stats["latest_datetime"] = str(datetime.datetime.utcfromtimestamp(oldest_seen_time))
        stats["oldest_epoch"] = oldest_seen_time
        stats["runtime_secs"] = elapsed_seconds
        if (recs > 0 and elapsed_seconds > 0):
            stats["throughput"] = (recs / (elapsed_seconds * 1.0 / 60))
        return stats

    def get_oldest_event_time(self, stream_num=0):
        """
        Get time of the oldest event
        :Params
            stream_num (int): stream index
        :Returns
            datetime: timestamp of the oldest event

        """
        if len(self.event_streams[stream_num]) == 0:
            return None
        last_element = len(self.event_streams[stream_num]) - 1
        event = self.event_streams[stream_num][last_element]
        return datetime.datetime.utcfromtimestamp(event["date_happened"])

    def get_oldest_event_epoch(self, stream_num=0):
        """
        Get epoch time of the oldest event
        :Params
            stream_num (int): stream index
        :Returns
            int: time as epoch of the oldest event

        """
        if len(self.event_streams[stream_num]) == 0:
            return None
        last_element = len(self.event_streams[stream_num]) - 1
        event = self.event_streams[stream_num][last_element]
        return event["date_happened"]

    def get_latest_event_time(self, stream_num=0, ignore_zero_byte_events=False):
        """
        Get time of the latest event
        :Params
            stream_num (int): stream index
            ignore_zero_byte_events (boolean): True if zero byte events are ignored, False otherwise
        :Returns
            datetime: timestamp of the most recent event

        """
        if len(self.event_streams[stream_num]) == 0:
            return None
        event = self.event_streams[stream_num][0]
        if ignore_zero_byte_events:
            while True:
                if event["text"].find("read with bytes=0 and records=0") == -1:
                    return datetime.datetime.utcfromtimestamp(event["date_happened"])
                stream_num += 1
                if len(self.event_streams) == stream_num: return None

                event = self.event_streams[stream_num][0]
        return datetime.datetime.utcfromtimestamp(event["date_happened"])

    def get_latest_event_epoch(self, stream_num=0, ignore_zero_byte_events=False):
        """
        Get epoch time of the latest event
        :Params
            stream_num (int): stream index
            ignore_zero_byte_events (boolean): True if zero byte events are ignored, False otherwise
        :Returns
            int: time as epoch of the latest event

        """
        if len(self.event_streams[stream_num]) == 0:
            return None
        event = self.event_streams[stream_num][0]
        # print self.event_streams
        if ignore_zero_byte_events:
            while True:
                if event["text"].find("read with bytes=0 and records=0") == -1:
                    return event["date_happened"]
                stream_num += 1
                if len(self.event_streams) == stream_num: return None
                event = self.event_streams[stream_num][0]
        return event["date_happened"]

    def print_line(self, scale_start, scale_end, stream_num=0):
        COLS = 80
        start = self.get_oldest_event_epoch(stream_num=stream_num)
        end = self.get_latest_event_epoch(stream_num=stream_num)
        start_col = 80.0 / (scale_end - scale_start) * (start - scale_start)
        end_col = 80.0 / (scale_end - scale_start) * (end - scale_start)
        print(("start at %d, end at %d" % (start_col, end_col)))
'''