from nexla.log_config import log
import sys
from requests.exceptions import ConnectionError
import json
class AuthError(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises AuthError exception if api returns 401 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Authentication failed")

class ResourceNotFound(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises ResourceNotFound exception if api returns 404 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Resource not exist")

class PermissionDenied(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises ResourceNotFound exception if api returns 403 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Not having permission to access the resource")


class InternalServerError(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises ResourceNotFound exception if api returns 403 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Internal server error, check the url")

class BadGateway(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises ResourceNotFound exception if api returns 403 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Received an invalid response from an inbound server, please try again")

class ConfigError(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises AuthError exception if api returns 401 status
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Configuration file not found or invalid configuration file")

class JSONDecodeError(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises JSONDecodeError exception if api fails
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("Invalid Json file, Please check with the file")

class IOError(Exception):
    def __init__(self, *args, **kwargs):
        """
        Raises FileNotFoundError exception if api fails
        :param args:
        :param kwargs:
        """
        Exception.__init__(self, *args, **kwargs)
        log.exception("No such file or directory")

def exit_on_exception(function):
    """
    Wrapper cli function to print valid message if api fails
    :param function:
    :return:
    """
    def except_handle(argv):
        try:
            function(argv)
        except AuthError:
            print("Authentication failed: Your ACCESS_TOKEN is invalid/expired.\nPlease run 'nexla env login' command")
            sys.exit(2)
        except ResourceNotFound:
            print("ResourceNotFound: \nThis resource does not exist in Nexla environment, please check the resource id that you are trying to access")
            sys.exit(2)
        except PermissionDenied:
            print("PermissionDenied: \nYou don't have permission to access this resource, please contact Nexla Administrator or write email to support@nexla.com")
            sys.exit(2)
        except ConnectionError:
            print("ConnectionError: \nCould not establish connection, please try again or check with the configured environment")
            sys.exit(2)
        except InternalServerError:
            print("InternalServerError: \nCould not get results for this command, please check with the command")
            sys.exit(2)
        except BadGateway:
            print("BadGatewayError: \nCould not process this request, please try again")
            sys.exit(2)
        except ConfigError:
            print("Configuration file not found or invalid configuration file found: \nPlease run 'nexla env configure' command")
            sys.exit(2)
        except TimeoutError:
            print("Gateway Timeout: Gateway Timeout error")
        except ValueError:
            print("ValueError: \nInvalid value for a input")
        except json.decoder.JSONDecodeError:
            print("json.decoder.JSONDecodeError: \nInvalid Json file, Please check with the file")
            sys.exit(2)
        except FileNotFoundError:
            print("FileNotFoundError: \nInvalid flow path or file name")
            sys.exit(2)
        except KeyboardInterrupt:
            print("\nKeyboardInterrupt: Terminated..")
            sys.exit(2)

    return except_handle