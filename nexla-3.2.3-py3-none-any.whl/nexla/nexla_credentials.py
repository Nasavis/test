import json
from nexla.log_config import log


class DataCredentials(object):

    @staticmethod
    def create_credentials(auth, payload):
        """
        Create credentials using payload
        :Params
            auth (string): auth token
            payload (string): request body having credential details
        :Returns
            DataCredentials: returns credentials object

        """
        resp = auth.call_url_return_json('data_credentials', 'POST', payload)
        print(json.dumps(resp, indent=4))
        return DataCredentials(auth, payload=resp)

    @staticmethod
    def get_src_type_from_vendor_endpoint(auth, endpoint_id):
        """
        Get source type from the vendor endpoint using endpoint id
        :Params
            auth (string): auth token
            endpoint_id (string): request body having vendor endpoints id
        :Returns
            source_type: returns source type object

        """
        resp = auth.call_url_return_json("/vendor_endpoints/%s" %endpoint_id, 'GET')

    @staticmethod
    def create_s3_credentials(auth, **kwargs):
        # Code to create a source from one of many options.
        return

    @staticmethod
    def create_ftp_credentials(auth, **kwargs):
        # Code to create a source from one of many options.
        return

    @staticmethod
    def create_mysql_credentials(auth, **kwargs):
        # Code to create a source from one of many options.
        return

    @staticmethod
    def create_redshift_credentials(auth, **kwargs):
        # Code to create a source from one of many options.
        return

    @staticmethod
    def create_api_credentials(auth, **kwargs):
        # Code to create a source from one of many options.
        return

    @staticmethod
    def get_all_credentials(auth, type=None, display_name=None, access_role = None):
        """
        Get all credentials.
        :Params
            auth (string): auth token
            type (string): type of credential
        :Returns
            list: list of all credential objects

        """
        log.info("Getting all Credentials")
        creds_list = []
        if access_role == "collaborator":
            resp = auth.call_url_return_json("/data_credentials?expand=1&access_role=collaborator")
        else:
            resp = auth.call_url_return_json("/data_credentials?expand=1")
        for cred in resp:
            if (type != None):
                if (cred.get("credentials_type") == type):
                    creds_list.append(DataCredentials(auth, payload=cred))
            elif (display_name != None):
                if (cred.get("vendor") and display_name in cred.get("vendor").get("display_name")):
                    creds_list.append(DataCredentials(auth, payload=cred))
            else:
                if cred.get("credentials_type") == "data_map": continue
                creds_list.append(DataCredentials(auth, payload=cred))
        return creds_list

    def get_credential_name(auth, id=None):
        """
        Get Credential Name
        :Params
            auth (string): auth token
            id (int): credential id
        :Returns
            Name: Name of the credential

        """
        if (id != None):
            resp = auth.call_url_return_json("/data_credentials/%s?expand=1" % id)
            return resp.get("name")

    def __init__(self, auth, **kwargs):
        """
        Credential initializer.
        :Params
            auth (string): auth token
            payload (string): request body having credential details
            id (int): credential id
        :Returns
            None

        """
        self.auth = auth
        if "payload" in kwargs:
            if kwargs["payload"] == None:
                raise AttributeError("Missing payload to initialize Credentials")
            self._init_from_payload(payload=kwargs["payload"])
        elif "id" in kwargs:
            self._init_from_id(id=kwargs["id"])
        else:
            raise Exception("Unsupported Initialization of Credentials Object")

    def _init_from_id(self, id):
        """
        Credential initializer using id.
        :Params
            id (int): credential id
        :Returns
            None

        """
        resp = self.auth.call_url_return_json("data_credentials/%d?expand=1" % id)
        self._init_from_payload(payload=resp)

    def _init_from_payload(self, payload):
        """
        Credential initializer using payload.
        :Params
            payload (string): request body having credential details
        :Returns
            None

        """
        self.raw = payload
        self.attributes = {}
        self.id = self.attributes["id"] = payload.get("id")
        self.name = self.attributes["name"] = payload.get("name")
        self.description = self.attributes["description"] = payload.get("description")
        self.credentials_type = self.attributes["credentials_type"] = payload.get("credentials_type")
        self.credentials_non_secure_data = self.attributes["credentials_non_secure_data"] = payload.get("credentials_non_secure_data")

    def get(self, attr):
        """
        Get values of attributes
        :Params
            attr (string): name of the attribute
        :Returns
            string/int: value of the attribute

        """
        return self.attributes.get(attr, "")

    def probe(self):
        """
        Check validity of a credential
        :Returns
            int: response code

        """
        resp = self.auth.call_url_return_json("data_credentials/%d/probe" % self.get("id"))
        return resp

    def probe_list(self):
        """
        List the top-level folders, buckets or tables in the external resource
        :Returns
            string: response of probe call

        """
        resp = self.auth.call_url_return_json("data_credentials/%d/probe/list" % self.get("id"))
        return resp

    def probe_tree(self, payload):
        """
        Inspect the tree structure in the external resource to a particular depth
        :Params
            payload (string): details of resource to be probed and depth of tree
        :Returns
            string: response of probe call

        """
        resp = self.auth.call_url_return_json("data_credentials/%d/probe/tree" % self.get("id"), method='POST',
                                              payload=payload)
        return resp

    def get_table_probe_tree(self, payload):
        """
        Inspect the tree structure in the external resource to a particular depth
        :Params
            payload (string): details of resource to be probed and depth of tree
        :Returns
            string: response of probe call

        """
        resp = self.auth.call_url_return_json("data_credentials/%d/probe/tree" % self.get("id"), method='POST',
                                              payload=payload)
        return resp

    def probe_buckets(self, payload):
        """
        Find files in a list of top-level buckets
        :Params
            payload (string): details of buckets to be probed
        :Returns
            string: response of probe call

        """
        resp = self.auth.call_url_return_json("data_credentials/%d/probe/buckets" % self.get("id"), method='POST',
                                              payload=payload)
        return resp

    def get_export(self):
        """
        Get templatized credential details.
        :Returns
            Dict: returns templatized credential details

        """
        obj = {}
        obj["name"] = self.attributes["name"]
        obj["description"] = self.attributes["description"]
        obj["credentials_type"] = self.attributes["credentials_type"]
        obj["credentials_non_secure_data"] = self.attributes["credentials_non_secure_data"]
        return obj
